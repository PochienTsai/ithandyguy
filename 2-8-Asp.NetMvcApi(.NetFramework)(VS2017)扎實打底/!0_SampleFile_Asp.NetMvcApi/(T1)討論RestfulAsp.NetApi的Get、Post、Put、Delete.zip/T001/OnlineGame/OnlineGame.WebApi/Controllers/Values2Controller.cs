﻿using System.Collections.Generic;
using System.Web.Http;

namespace OnlineGame.WebApi.Controllers
{
    public class Values2Controller : System.Web.Http.ApiController
    {
        static List<string> _valueStrList = new List<string>
        {
            "value0", "value1", "value2"
        };

        // GET api/values
        //Get a list of value
        public IEnumerable<string> Get()
        {
            return _valueStrList;
        }

        // GET api/values/5
        //Get the value with id==1
        public string Get(int id)
        {
            return _valueStrList[id];
        }

        // POST api/values
        //insert a new value
        public void Post([FromBody]string value)
        {
            _valueStrList.Add(value);
        }

        // PUT api/values/5
        //update the value with id==5
        public void Put(int id, [FromBody]string value)
        {
            _valueStrList[id] = value;
        }

        // DELETE api/values/5
        //delete the value with id==5
        public void Delete(int id)
        {
            _valueStrList.RemoveAt(id);
        }
    }
}
