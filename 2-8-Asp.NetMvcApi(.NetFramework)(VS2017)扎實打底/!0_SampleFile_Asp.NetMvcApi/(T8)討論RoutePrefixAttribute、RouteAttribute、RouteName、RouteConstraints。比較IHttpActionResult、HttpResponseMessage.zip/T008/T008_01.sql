--1.1 ----------------------------------------------------------
--Drop Table if it exists.
IF ( EXISTS ( SELECT    *
              FROM      INFORMATION_SCHEMA.TABLES
              WHERE     TABLE_NAME = 'GamerSkill' ) )
    BEGIN
        TRUNCATE TABLE GamerSkill;
        DROP TABLE GamerSkill;
    END;
GO -- Run the previous command and begins new batch
IF ( EXISTS ( SELECT    *
              FROM      INFORMATION_SCHEMA.TABLES
              WHERE     TABLE_NAME = 'Skill' ) )
    BEGIN
        TRUNCATE TABLE Skill;
        DROP TABLE Skill;
    END;
GO -- Run the previous command and begins new batch
--IF OBJECT_ID('Gamer') IS NOT NULL
IF ( EXISTS ( SELECT    *
              FROM      INFORMATION_SCHEMA.TABLES
              WHERE     TABLE_NAME = 'Gamer' ) )
    BEGIN
        TRUNCATE TABLE Gamer;
        DROP TABLE Gamer;
    END;
GO -- Run the previous command and begins new batch
--IF OBJECT_ID('Gamer') IS NOT NULL
IF ( EXISTS ( SELECT    *
              FROM      INFORMATION_SCHEMA.TABLES
              WHERE     TABLE_NAME = 'Team' ) )
    BEGIN
        TRUNCATE TABLE Team;
        DROP TABLE Team;
    END;
GO -- Run the previous command and begins new batch

--1.2 ----------------------------------------------------------
--Drop Stored Procedure if it exists.
--IF OBJECT_ID('spSearchGamer') IS NOT NULL
IF ( EXISTS ( SELECT    *
              FROM      INFORMATION_SCHEMA.ROUTINES
              WHERE     ROUTINE_TYPE = 'PROCEDURE'
                        AND LEFT(ROUTINE_NAME, 3) NOT IN ( 'sp_', 'xp_', 'ms_' )
                        AND SPECIFIC_NAME = 'spInsertGamerSkill' ) )
    BEGIN
        DROP PROCEDURE spInsertGamerSkill;
    END;
GO -- Run the previous command and begins new batch
IF ( EXISTS ( SELECT    *
              FROM      INFORMATION_SCHEMA.ROUTINES
              WHERE     ROUTINE_TYPE = 'PROCEDURE'
                        AND LEFT(ROUTINE_NAME, 3) NOT IN ( 'sp_', 'xp_', 'ms_' )
                        AND SPECIFIC_NAME = 'spDeleteGamerSkill' ) )
    BEGIN
        DROP PROCEDURE spDeleteGamerSkill;
    END;
GO -- Run the previous command and begins new batch
IF ( EXISTS ( SELECT    *
              FROM      INFORMATION_SCHEMA.ROUTINES
              WHERE     ROUTINE_TYPE = 'PROCEDURE'
                        AND LEFT(ROUTINE_NAME, 3) NOT IN ( 'sp_', 'xp_', 'ms_' )
                        AND SPECIFIC_NAME = 'spSelectGamerSkill' ) )
    BEGIN
        DROP PROCEDURE spSelectGamerSkill;
    END;
GO -- Run the previous command and begins new batch
IF ( EXISTS ( SELECT    *
              FROM      INFORMATION_SCHEMA.ROUTINES
              WHERE     ROUTINE_TYPE = 'PROCEDURE'
                        AND LEFT(ROUTINE_NAME, 3) NOT IN ( 'sp_', 'xp_', 'ms_' )
                        AND SPECIFIC_NAME = 'spSkillsAssignToTheGamer' ) )
    BEGIN
        DROP PROCEDURE spSkillsAssignToTheGamer;
    END;
GO -- Run the previous command and begins new batch
IF ( EXISTS ( SELECT    *
              FROM      INFORMATION_SCHEMA.ROUTINES
              WHERE     ROUTINE_TYPE = 'PROCEDURE'
                        AND LEFT(ROUTINE_NAME, 3) NOT IN ( 'sp_', 'xp_', 'ms_' )
                        AND SPECIFIC_NAME = 'spSkillsNotAssignToTheGamer' ) )
    BEGIN
        DROP PROCEDURE spSkillsNotAssignToTheGamer;
    END;
GO -- Run the previous command and begins new batch



--2 ----------------------------------------------------------
CREATE TABLE Team
    (
      Id INT PRIMARY KEY
             IDENTITY(1, 1)
             NOT NULL ,
      Name NVARCHAR(50) NOT NULL
    );
GO -- Run the previous command and begins new batch
CREATE TABLE Gamer
    (
      Id INT PRIMARY KEY
             IDENTITY(1, 1)
             NOT NULL ,
      Name NVARCHAR(50) NOT NULL ,
      Gender NVARCHAR(50) NOT NULL ,
      Score INT NOT NULL ,
      TeamId INT FOREIGN KEY REFERENCES Team ( Id )
    );
GO -- Run the previous command and begins new batch
CREATE TABLE Skill
    (
      Id INT PRIMARY KEY
             IDENTITY(1, 1)
             NOT NULL ,
      Name NVARCHAR(50) NOT NULL
    );
GO -- Run the previous command and begins new batch
CREATE TABLE GamerSkill
    (
      GamerId INT FOREIGN KEY REFERENCES Gamer ( Id )
                  NOT NULL ,
      SkillId INT FOREIGN KEY REFERENCES Skill ( Id )
                  NOT NULL ,
      CreatedDate DATETIME DEFAULT ( GETUTCDATE() )
                           NOT NULL ,
      PRIMARY KEY ( GamerId, SkillId )
    );
GO -- Run the previous command and begins new batch


--3 ----------------------------------------------------------

INSERT  Team
VALUES  ( 'TeamOne' );
INSERT  Team
VALUES  ( 'TeamTwo' );
INSERT  Team
VALUES  ( 'TeamThree' );
GO -- Run the previous command and begins new batch


INSERT  INTO Gamer
VALUES  ( 'NameOne ABC', 'Male', 5000, 1 );
INSERT  INTO Gamer
VALUES  ( 'NameTwo ABCDE', 'Female', 4500, 1 );
INSERT  INTO Gamer
VALUES  ( 'NameThree EFGH', 'Male', 6500, 3 );
INSERT  INTO Gamer
VALUES  ( 'NameFour HIJKLMN', 'Female', 45000, 2 );
INSERT  INTO Gamer
VALUES  ( 'NameFive NOP', 'Male', 3000, 3 );
INSERT  INTO Gamer
VALUES  ( 'NameSix PQRSTUVW', 'Male', 4000, 3 );
INSERT  INTO Gamer
VALUES  ( 'NameSeven XYZ', 'Male', 4500, 1 );
GO -- Run the previous command and begins new batch


INSERT  INTO Skill
VALUES  ( 'SkillA Play Dead' );
INSERT  INTO Skill
VALUES  ( 'SkillB Flame Punch' );
INSERT  INTO Skill
VALUES  ( 'SkillC Steal' );
INSERT  INTO Skill
VALUES  ( 'SkillD Fly' );
INSERT  INTO Skill
VALUES  ( 'SkillE Super Speed' );
INSERT  INTO Skill
VALUES  ( 'SkillF Forzen' );
INSERT  INTO Skill
VALUES  ( 'SkillG Invisible' );
GO -- Run the previous command and begins new batch


INSERT  INTO GamerSkill
        ( GamerId, SkillId )
VALUES  ( 1, 2 );
INSERT  INTO GamerSkill
        ( GamerId, SkillId )
VALUES  ( 1, 3 );
INSERT  INTO GamerSkill
        ( GamerId, SkillId )
VALUES  ( 2, 2 );
INSERT  INTO GamerSkill
        ( GamerId, SkillId )
VALUES  ( 2, 1 );
INSERT  INTO GamerSkill
        ( GamerId, SkillId )
VALUES  ( 2, 4 );
GO -- Run the previous command and begins new batch



--4 SP ----------------------------------------------------------
CREATE PROCEDURE spInsertGamerSkill
    (
      @GamerId INT ,
      @SkillId INT 
    )
AS
    BEGIN  
        INSERT  INTO GamerSkill
                ( GamerId, SkillId )
        VALUES  ( @GamerId, -- GamerId - int
                  @SkillId  -- SkillId - int
                  );
    END;
GO -- Run the previous command and begins new batch


CREATE PROCEDURE spDeleteGamerSkill
    (
      @GamerId INT ,
      @SkillId INT 
    )
AS
    BEGIN  
        DELETE  FROM GamerSkill
        WHERE   GamerId = @GamerId
                AND SkillId = @SkillId; 
    END;
GO -- Run the previous command and begins new batch



CREATE PROCEDURE spSelectGamerSkill
AS
    BEGIN  
        SELECT  gs.GamerId ,
                g.Name ,
                g.Gender ,
                g.Score ,
                gs.SkillId ,
                s.Name
        FROM    Gamer g
                INNER JOIN GamerSkill gs ON g.Id = gs.GamerId
                INNER JOIN Skill s ON s.Id = gs.SkillId;
    END;
GO -- Run the previous command and begins new batch
--This is for test purpose
--If you want to use it in EF, you have to return a view or table function.



CREATE PROCEDURE spSkillsAssignToTheGamer ( @GamerId INT )
AS
    BEGIN  
        SELECT  *
        FROM    GamerSkill gs
                INNER JOIN Skill s ON s.Id = gs.SkillId
        WHERE   GamerId = @GamerId; 
    END;
GO -- Run the previous command and begins new batch
--This is for test purpose
--If you want to use it in EF, you have to return a view or table function.


CREATE PROCEDURE spSkillsNotAssignToTheGamer ( @GamerId INT )
AS
    BEGIN  
        SELECT  *
        FROM    Skill s
        WHERE   s.Id NOT IN (
                SELECT  s.Id
                FROM    GamerSkill gs
                        INNER JOIN Skill s ON s.Id = gs.SkillId
                WHERE   GamerId = @GamerId );
    END;
GO -- Run the previous command and begins new batch
--This is for test purpose
--If you want to use it in EF, you have to return a view or table function.


--EXEC spInsertGamerSkill @GamerId = 100, @SkillId = 1;
--EXEC spDeleteGamerSkill @GamerId = 100, @SkillId = 1;
--EXEC spSelectGamerSkill
--EXEC spSkillsAssignToTheGamer @GamerId=1
--EXEC spSkillsNotAssignToTheGamer @GamerId=1
