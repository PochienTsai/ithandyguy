﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net.Http.Formatting;
using System.Web.Http;

namespace OnlineGame.WebApi
{
    public static class WebApiConfig
    {
        public static void Register(HttpConfiguration config)
        {
            // Web API configuration and services

            // Web API routes
            config.MapHttpAttributeRoutes();
            config.Routes.MapHttpRoute(
                name: "DefaultApi",
                routeTemplate: "api/{controller}/{id}",
                defaults: new { id = RouteParameter.Optional }
            );


            //Use JSON formatter as a PreserveReferencesHandling.
            JsonMediaTypeFormatter json = config.Formatters.JsonFormatter;
            json.SerializerSettings.PreserveReferencesHandling = Newtonsoft.Json.PreserveReferencesHandling.Objects;
            //Remove Xml Formatter
            config.Formatters.Remove(config.Formatters.XmlFormatter);
        }
    }
}


/*
//JsonMediaTypeFormatter json = config.Formatters.JsonFormatter;
//json.SerializerSettings.PreserveReferencesHandling = Newtonsoft.Json.PreserveReferencesHandling.Objects;
//config.Formatters.Remove(config.Formatters.XmlFormatter);
Use JSON formatter as a PreserveReferencesHandling.
Remove Xml Formatter
Reference:
A.
https://forums.asp.net/t/1983286.aspx?Web+API+error+The+ObjectContent+1+type+failed+to+serialize+the+response+body+for+content+type+application+xml+charset+utf+8+
B.
https://stackoverflow.com/questions/23098191/failed-to-serialize-the-response-in-web-api-with-json
*/
