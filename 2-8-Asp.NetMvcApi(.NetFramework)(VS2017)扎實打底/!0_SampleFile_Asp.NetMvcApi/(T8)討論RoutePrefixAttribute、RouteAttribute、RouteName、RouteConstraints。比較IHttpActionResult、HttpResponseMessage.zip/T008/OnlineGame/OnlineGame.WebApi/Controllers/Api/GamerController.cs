﻿using System.Collections.Generic;
using System.Data.Entity;
using System.Data.Entity.Infrastructure;
using System.Linq;
using System.Threading.Tasks;
using System.Web.Http;
using System.Web.Http.Description;
using OnlineGame.WebApi.Models;

namespace OnlineGame.WebApi.Controllers.Api
{
    public class GamerController : ApiController
    {
        private OnlineGameContext _db = new OnlineGameContext();

        // GET: api/Gamer
        [HttpGet]
        public async Task<IEnumerable<Gamer>> GetGamers()
        {
            return await _db.Gamers.ToListAsync();
        }

        // GET: api/Gamer/1
        //Convention-based routing.
        [HttpGet]   
        [ResponseType(typeof(Gamer))]
        public async Task<IHttpActionResult> GetGamer(int id)
        {
            Gamer gamer = await _db.Gamers.FindAsync(id);
            if (gamer == null) return NotFound();  //404
            return Ok(gamer);   //200
        }


        [HttpGet]
        //Attribute Routing
        [Route("api/gamer/{id}/skills")]    // GET: api/gamer/1/skills
        public async Task<IHttpActionResult> GetGamerSkills(int id)
        {
            Gamer gamer = await _db.Gamers.FindAsync(id);
            if (gamer == null) return NotFound();  //404

            List<Skill> skills = await GetSkillsByGamerId(id);

            return Ok(skills);   //200
        }

        [HttpGet]
        [Route("api/gamer/skills/{id}")]    // GET: api/gamer/skills/1
        public async Task<IHttpActionResult> GetGamerSkills2(int id)
        {
            Gamer gamer = await _db.Gamers.FindAsync(id);
            if (gamer == null) return NotFound();  //404

            List<Skill> skills = await GetSkillsByGamerId(id);

            return Ok(skills);   //200
        }

        // PUT: api/Gamer/1
        [HttpPut]
        [ResponseType(typeof(void))]
        public async Task<IHttpActionResult> PutGamer(int id, Gamer gamer)
        {
            if (!ModelState.IsValid) return BadRequest(ModelState);  //400
            //if (id != gamer.Id)   return BadRequest();

            //1.
            gamer.Id = id;
            _db.Entry(gamer).State = EntityState.Modified;  //update the gamer

            //2.
            //Gamer currentGamer = await _db.Gamers.FirstOrDefaultAsync(g => g.Id == id);
            //if (currentGamer == null) return NotFound();  //404
            //currentGamer.Name = gamer.Name;
            //currentGamer.Gender = gamer.Gender;
            //currentGamer.Score = gamer.Score;
            //currentGamer.GameMoney = gamer.GameMoney;

            try
            {
                await _db.SaveChangesAsync();
                return Ok();    //200
            }
            catch (DbUpdateConcurrencyException)
            {
                if (!GamerExists(id)) return NotFound();  //404
                throw;
            }
        }

        // POST: api/Gamer
        [HttpPost]
        [ResponseType(typeof(Gamer))]
        public async Task<IHttpActionResult> PostGamer(Gamer gamer)
        {
            if (!ModelState.IsValid) return BadRequest(ModelState); //400
            _db.Gamers.Add(gamer);
            await _db.SaveChangesAsync();

            //Return Created/201.
            return CreatedAtRoute("DefaultApi", new { id = gamer.Id }, gamer);    //Created/201
        }

        // DELETE: api/Gamer/1
        [HttpDelete]
        [ResponseType(typeof(Gamer))]
        public async Task<IHttpActionResult> DeleteGamer(int id)
        {
            Gamer gamer = await _db.Gamers.FindAsync(id);
            if (gamer == null) return NotFound();   //404
            _db.Gamers.Remove(gamer);
            await _db.SaveChangesAsync();
            return Ok(gamer);   //200
        }

        private async Task<List<Skill>> GetSkillsByGamerId(int gamerId)
        {
            IQueryable<GamerSkill> gamerSkills = _db.Gamers
                .SelectMany(
                    g => g.GamerSkills, //The source of gamerSkill in second parameter
                    (g, gamerSkill) =>
                        new { GamerId = g.Id, GamerSkill = gamerSkill }) //Projection to a anonymous type
                .Where(gs => gs.GamerId == gamerId) //gamer id==gamerId
                .Select(gs => gs.GamerSkill); // Projection to GamerSkill Type

            List<Skill> skills =
                    await gamerSkills.Select(gamerSkill => _db.Skills.FirstOrDefault(s => s.Id == gamerSkill.SkillId)).ToListAsync();

            //Projection to Skill
            return skills;
        }

        protected override void Dispose(bool disposing)
        {
            if (disposing) _db.Dispose();   //Dispose DBContext
            base.Dispose(disposing);
        }

        private bool GamerExists(int id)
        {
            return _db.Gamers.Count(e => e.Id == id) > 0;
        }
    }
}


/*
1.
1.1.
By default, the HTTP verb GET maps to a method that has the name Get() or "Get" prefix.
E.g. Get(), GetGamers, GetXXX()
If you want the HTTP verb GET maps to the method name without "Get" prefix.
You can use [HttpGet] attribute.
1.2.
[HttpGet] attribute maps HTTP verb GET.
[HttpPost] attribute maps HTTP verb POST.
[HttpPut] attribute maps HTTP verb PUT.
[HttpDelete] attribute maps HTTP verb DELETE.

----------------------------
2.
[FromUri] V.S. [FromBody]
Web Api default binding parameter convention
2.1.
By default, if the parameter is a simple type,
Web Api will try to get value from uri.
E.g. int, double, bool, ...etc.
2.2.
By default, if the parameter is a complex type,
Web Api will try to get value from the request body.
E.g. Gamer
-----------------
2.3.
//[HttpPut]
//public async Task<IHttpActionResult> UpdateGamer(int id, Gamer gamer) 
By Default, the Web Api will try to get id from uri, and gamer from request body as below code.
//[HttpPut]
//public async Task<IHttpActionResult> UpdateGamer([FromUri]int id, [FromBody]Gamer gamer)
E.g.
A.
PUT
http://localhost:58302/api/Gamer/8
B.
Request Header
Host: localhost:58302
Content-Type: application/json
B.1.
Accept: application/json
means we request JSON format response.
B.2.
Content-Type: application/json
The client will post a data to the server, the data format is JSON
C.
Request Body
{
"Name":"NameEight XYZ222",
"Gender":"Male",
"Score":450,
"GameMoney":1500
}
-----------------
2.4.
//[HttpPut]
//public async Task<IHttpActionResult> UpdateGamer([FromBody]int id, [FromUri]Gamer gamer)
[FromBody] will enfroce to get id from request body
[FromUri] will enforce to get gamer from uri
E.g.
A.
PUT
http://localhost:58302/api/Gamer?Name=NameEight%20XYZ333&Gender=Male&Score=450&GameMoney=1500
B.
Request Header
Host: localhost:58302
Content-Type: application/json
B.1.
Accept: application/json
means we request JSON format response.
B.2.
Content-Type: application/json
The client will post a data to the server, the data format is JSON
C.
Request Body
8

----------------------------
6.
Attribute routing 
-----------------
6.1.
E.g.
//public async Task<IHttpActionResult> GetGamer(int id){...}
....
//[Route("api/gamer/{id}/skills")]
//public async Task<IHttpActionResult> GetGamerSkills(int id){...}
When we call "api/gamer/1" and if we don't have Route attribute,
the API will be confused, 
because both GetGamerSkills() and GetGamer() can map to "api/gamer/1".
Thus, we need Route attribute
[Route("api/gamer/{id}/skills")] will make GetGamerSkills() map to something like "api/gamer/1/skills".
Thus, GetGamer() can map to something like "api/gamer/1".
-----------------
6.2.
In this case,
GetGamer() is using Convention-based routing.
GetGamerSkills() is using Attribute Routing.
-----------------
6.3.
In
OnlineGame.WebApi/WebApiConfig.cs/WebApiConfig.cs
//config.MapHttpAttributeRoutes();
It enables Attribute Routing.
*/
