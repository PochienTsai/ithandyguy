﻿using System.Collections.Generic;
using System.Data.Entity;
using System.Linq;
using System.Threading.Tasks;
using System.Web.Http;
using System.Web.Http.Description;
using OnlineGame.WebApi.Models;

namespace OnlineGame.WebApi.Controllers.Api
{
    [RoutePrefix("api/gamer3")]
    public class GamerThreeController : ApiController
    {
        private OnlineGameContext _db = new OnlineGameContext();

        // GET: api/GamerThree
        public IQueryable<Gamer> GetGamers()
        {
            return _db.Gamers;
        }

        // GET: api/GamerThree/1
        [ResponseType(typeof(Gamer))]
        public async Task<IHttpActionResult> GetGamer(int id)
        {
            Gamer gamer = await _db.Gamers.FindAsync(id);
            if (gamer == null) return NotFound();   //404
            return Ok(gamer);
        }

        // GET: api/gamer3/GetGamerBySomething/2
        [Route("GetGamerBySomething/{gamerId:int}")]
        public async Task<IHttpActionResult> GetGamerBySomething(int gamerId)
        {
            Gamer gamer = await _db.Gamers.FindAsync(gamerId);
            if (gamer == null) return NotFound();   //404
            return Ok(gamer);
        }

        // GET: api/gamer3/GetGamerBySomething/male
        //[Route("GetGamerBySomething/{gender:string}")]    //Error, string type is not valid
        [Route("GetGamerBySomething/{gender:alpha}")]
        //alpha means uppercase or lowercase alphabet.
        public async Task<IHttpActionResult> GetGamerBySomething(string gender)
        {
            List<Gamer> gamer =
                await _db.Gamers.Where(
                    g => g.Gender.ToLower().Equals(gender.ToLower()))   //it is not case sensitive
                    .ToListAsync();
            return Ok(gamer);
        }

        [ResponseType(typeof(Gamer))]
        [Route("{gamerId}")]    // GET: api/gamer3/1
        public async Task<IHttpActionResult> GetGamer2(int gamerId)
        {
            Gamer gamer = await _db.Gamers.FindAsync(gamerId);
            if (gamer == null) return NotFound();   //404
            return Ok(gamer);
        }

        // GET: api/gamer3/getGamerById/1
        // gamerId must be int and min is 2
        [Route("getGamerById/{gamerId:int:min(2)}")]
        [ResponseType(typeof(Gamer))]
        public async Task<IHttpActionResult> GetGamerById(int gamerId)
        {
            Gamer gamer = await _db.Gamers.FindAsync(gamerId);
            if (gamer == null) return NotFound();   //404
            return Ok(gamer);
        }

        // GET: api/gamer3/getGamerById2/1
        // gamerId must be int and min is 2, max is 5
        [Route("getGamerById2/{gamerId:int:min(2):max(5)}")]
        [ResponseType(typeof(Gamer))]
        public async Task<IHttpActionResult> GetGamerById2(int gamerId)
        {
            Gamer gamer = await _db.Gamers.FindAsync(gamerId);
            if (gamer == null) return NotFound();   //404
            return Ok(gamer);
        }

        // GET: api/gamer3/getGamerById3/1
        // gamerId must be int and min is 2, max is 5
        [Route("getGamerById3/{gamerId:range(2,5)}")]
        [ResponseType(typeof(Gamer))]
        public async Task<IHttpActionResult> GetGamerById3(int gamerId)
        {
            Gamer gamer = await _db.Gamers.FindAsync(gamerId);
            if (gamer == null) return NotFound();   //404
            return Ok(gamer);
        }

        // GET: api/gamer3/getGamersByGender/female
        //[Route("getGamersByGender/{gender:string}")]    //Error, string type is not valid
        [Route("getGamersByGender/{gender:alpha}")] //alpha means uppercase or lowercase alphabet characters.
        [ResponseType(typeof(Gamer))]
        public async Task<IHttpActionResult> GetGamersByGender(string gender)
        {
            List<Gamer> gamer = 
                await _db.Gamers.Where(
                    g => g.Gender.ToLower().Equals(gender.ToLower()))   //it is not case sensitive
                    .ToListAsync();
            return Ok(gamer);
        }

        // GET: api/gamer3/getGamersByGender2/female     //will return nothing, it is case sensitive
        // GET: api/gamer3/getGamersByGender2/Female
        [Route("getGamersByGender2/{gender:alpha}")] 
        [ResponseType(typeof(Gamer))]
        public async Task<IHttpActionResult> GetGamersByGender2(string gender)
        {
            List<Gamer> gamer =
                await _db.Gamers.Where(
                    g => g.Gender.Equals(gender))   //it is case sensitive
                    .ToListAsync();
            return Ok(gamer);
        }

        // GET: api/gamer3/getGamersByGender3/female        //404
        // GET: api/gamer3/getGamersByGender3/male
        [Route("getGamersByGender3/{gender:alpha:maxlength(5)}")]
        //alpha means uppercase or lowercase alphabet characters.
        //max alpha length is 5
        [ResponseType(typeof(Gamer))]
        public async Task<IHttpActionResult> GetGamersByGender3(string gender)
        {
            List<Gamer> gamer =
                await _db.Gamers.Where(
                    g => g.Gender.ToLower().Equals(gender.ToLower()))
                    .ToListAsync();
            return Ok(gamer);
        }

        // GET: api/gamer3/getGamersByGender4/female      
        // GET: api/gamer3/getGamersByGender4/male      //404
        [Route("getGamersByGender4/{gender:alpha:minlength(5):maxlength(7)}")]
        //alpha means uppercase or lowercase alphabet characters.
        //max alpha length is 7, and min length is 5.
        [ResponseType(typeof(Gamer))]
        public async Task<IHttpActionResult> GetGamersByGender4(string gender)
        {
            List<Gamer> gamer =
                await _db.Gamers.Where(
                    g => g.Gender.ToLower().Equals(gender.ToLower()))   //it is not case sensitive
                    .ToListAsync();
            return Ok(gamer);
        }


        protected override void Dispose(bool disposing)
        {
            if (disposing) _db.Dispose();
            base.Dispose(disposing);
        }

        private bool GamerExists(int id)
        {
            return _db.Gamers.Count(e => e.Id == id) > 0;
        }
    }
}

/*
8.
attribute routing constraints
Reference:
https://docs.microsoft.com/en-us/aspnet/web-api/overview/web-api-routing-and-actions/attribute-routing-in-web-api-2#route-constraints
Routing constraints can apply to decimal, double, float, long, bool...etc. 
--------------
8.1.
//// GET: api/gamer3/GetGamerBySomething/2
//[Route("GetGamerBySomething/{gamerId:int}")]
//public async Task<IHttpActionResult> GetGamerBySomething(int gamerId)
int means integer
...
//// GET: api/gamer3/GetGamerBySomething/male
////[Route("GetGamerBySomething/{gender:string}")]    //Error, string type is not valid
//[Route("GetGamerBySomething/{gender:alpha}")]
//public async Task<IHttpActionResult> GetGamerBySomething(string gender)
alpha means uppercase or lowercase alphabet.
--------------
8.2.
//[Route("getGamerById/{gamerId:int:min(2)}")]
//public async Task<IHttpActionResult> GetGamerById(int gamerId)
GET: api/gamer3/getGamerById/1
gamerId must be int and min is 2
--------------
8.3.
//[Route("getGamerById2/{gamerId:int:min(2):max(5)}")]
//public async Task<IHttpActionResult> GetGamerById2(int gamerId)
GET: api/gamer3/getGamerById2/1
gamerId must be int and min is 2, max is 5
--------------
8.4.
//[Route("getGamerById3/{gamerId:range(2,5)}")]
//public async Task<IHttpActionResult> GetGamerById3(int gamerId)
GET: api/gamer3/getGamerById3/1
gamerId must be int and min is 2, max is 5
--------------
8.5.
////[Route("getGamersByGender/{gender:string}")]    //Error, string type is not valid
//[Route("getGamersByGender/{gender:alpha}")] 
//public async Task<IHttpActionResult> GetGamersByGender(string gender)
alpha means uppercase or lowercase alphabet characters.
GET: api/gamer3/getGamersByGender/female
--------------
8.7.
//[Route("getGamersByGender3/{gender:alpha:maxlength(5)}")]
//public async Task<IHttpActionResult> GetGamersByGender3(string gender)
GET: api/gamer3/getGamersByGender3/female        //404
GET: api/gamer3/getGamersByGender3/male
alpha means uppercase or lowercase alphabet characters.
max alpha length is 5
--------------
8.8.
//[Route("getGamersByGender3/{gender:alpha:maxlength(5)}")]
//public async Task<IHttpActionResult> GetGamersByGender3(string gender)
GET: api/gamer3/getGamersByGender3/female        //404
GET: api/gamer3/getGamersByGender3/male
alpha means uppercase or lowercase alphabet characters.
max alpha length is 5
--------------
8.9.       
//[Route("getGamersByGender4/{gender:alpha:minlength(5):maxlength(7)}")]
//public async Task<IHttpActionResult> GetGamersByGender4(string gender)
GET: api/gamer3/getGamersByGender4/female      
GET: api/gamer3/getGamersByGender4/male      //404
alpha means uppercase or lowercase alphabet characters.
max alpha length is 7, and min length is 5.
*/
