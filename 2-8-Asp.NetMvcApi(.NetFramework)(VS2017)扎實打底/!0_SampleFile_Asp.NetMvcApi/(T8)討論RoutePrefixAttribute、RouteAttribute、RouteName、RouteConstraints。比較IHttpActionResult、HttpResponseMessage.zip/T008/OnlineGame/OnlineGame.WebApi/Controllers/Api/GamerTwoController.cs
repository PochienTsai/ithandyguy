﻿using System.Collections.Generic;
using System.Data.Entity;
using System.Linq;
using System.Threading.Tasks;
using System.Web.Http;
using System.Web.Http.Description;
using OnlineGame.WebApi.Models;

namespace OnlineGame.WebApi.Controllers.Api
{
    [RoutePrefix("api/gamer2")]
    public class GamerTwoController : ApiController
    {
        private OnlineGameContext _db = new OnlineGameContext();

        // GET: api/Gamertwo
        public IQueryable<Gamer> GetGamers()
        {
            return _db.Gamers;
        }

        // GET: api/Gamer2
        [Route("")]
        public IQueryable<Gamer> GetGamers2()
        {
            return _db.Gamers;
        }

        // GET: api/gamer2/api/gamer2
        [Route("api/gamer2")]
        public IQueryable<Gamer> GetGamers3()
        {
            return _db.Gamers;
        }

        // GET: api/gamer2/api/getGamers
        [Route("api/getGamers")]
        public IQueryable<Gamer> GetGamers4()
        {
            return _db.Gamers;
        }

        // GET: api/getGamers
        [Route("~/api/getGamers")]
        public IQueryable<Gamer> GetGamers5()
        {
            return _db.Gamers;
        }

        // GET: api/gamerTwo/1
        [ResponseType(typeof(Gamer))]
        public async Task<IHttpActionResult> GetGamer(int id)
        {
            Gamer gamer = await _db.Gamers.FindAsync(id);
            if (gamer == null) return NotFound();  //404
            return Ok(gamer);   //200
        }

        // GET: api/gamer2/1
        [Route("{id}")]
        [ResponseType(typeof(Gamer))]
        public async Task<IHttpActionResult> GetGamer2(int id)
        {
            Gamer gamer = await _db.Gamers.FindAsync(id);
            if (gamer == null) return NotFound();  //404
            return Ok(gamer);   //200
        }

        // GET: api/gamer2/api/gamer2/1
        [ResponseType(typeof(Gamer))]
        [Route("api/gamer2/{id}")]
        public async Task<IHttpActionResult> GetGamer3(int id)
        {
            Gamer gamer = await _db.Gamers.FindAsync(id);
            if (gamer == null) return NotFound();  //404
            return Ok(gamer);   //200
        }

        // GET: api/gamer2GetGamerById/1
        [ResponseType(typeof(Gamer))]
        [Route("~/api/gamer2GetGamerById/{id}")]
        public async Task<IHttpActionResult> GetGamer4(int id)
        {
            Gamer gamer = await _db.Gamers.FindAsync(id);
            if (gamer == null) return NotFound();  //404
            return Ok(gamer);   //200
        }

        [HttpGet]
        [Route("api/gamer2/{gamerId}/skills")]    // GET: api/gamer2/api/gamer2/1/skills
        public async Task<IHttpActionResult> GetGamerSkills(int gamerId)
        {
            Gamer gamer = await _db.Gamers.FindAsync(gamerId);
            if (gamer == null) return NotFound();  //404

            List<Skill> skills = await GetSkillsByGamerId(gamerId);

            return Ok(skills);   //200
        }

        [HttpGet]
        [Route("api/gamer2/skills/{gamerId}")]    // GET: api/gamer2/api/gamer2/skills/1
        public async Task<IHttpActionResult> GetGamerSkills2(int gamerId)
        {
            Gamer gamer = await _db.Gamers.FindAsync(gamerId);
            if (gamer == null) return NotFound();  //404

            List<Skill> skills = await GetSkillsByGamerId(gamerId);

            return Ok(skills);   //200
        }

        [HttpGet]
        [Route("skills/{gamerId}")]    // GET: api/gamer2/skills/1
        public async Task<IHttpActionResult> GetGamerSkills3(int gamerId)
        {
            Gamer gamer = await _db.Gamers.FindAsync(gamerId);
            if (gamer == null) return NotFound();  //404

            List<Skill> skills = await GetSkillsByGamerId(gamerId);

            return Ok(skills);   //200
        }

        [HttpGet]
        [Route("~/api/getGamerSkillsByGamerId/{gamerId}")]    // GET: api/getGamerSkillsByGamerId/1
        public async Task<IHttpActionResult> GetGamerSkills4(int gamerId)
        {
            Gamer gamer = await _db.Gamers.FindAsync(gamerId);
            if (gamer == null) return NotFound();  //404

            List<Skill> skills = await GetSkillsByGamerId(gamerId);

            return Ok(skills);   //200
        }

        private async Task<List<Skill>> GetSkillsByGamerId(int gamerId)
        {
            IQueryable<GamerSkill> gamerSkills = _db.Gamers
                .SelectMany(
                    g => g.GamerSkills, //The source of gamerSkill in second parameter
                    (g, gamerSkill) =>
                        new { GamerId = g.Id, GamerSkill = gamerSkill }) //Projection to a anonymous type
                .Where(gs => gs.GamerId == gamerId) //gamer id==gamerId
                .Select(gs => gs.GamerSkill); // Projection to GamerSkill Type
            List<Skill> skills =
                    await gamerSkills.Select(gamerSkill => _db.Skills.FirstOrDefault(s => s.Id == gamerSkill.SkillId)).ToListAsync();
            //Projection to Skill
            return skills;
        }

        protected override void Dispose(bool disposing)
        {
            if (disposing) _db.Dispose();   //Dispose DBContext
            base.Dispose(disposing);
        }

        private bool GamerExists(int id)
        {
            return _db.Gamers.Count(e => e.Id == id) > 0;
        }
    }
}

/*
7.
RoutePrefix and Route attribute
//[RoutePrefix("api/gamer2")]
RoutePrefix attribute is for route prefix at the controller level.
Route attribute use that route prefix plus its own route value.
//[Route("~/api/getGamerSkillsByGamerId/{gamerId}")]
if you want to  override the route prefix,
just use ~ (tilde) symbol   
*/
