﻿using System.Linq;
using System.Net;
using System.Net.Http;
using System.Threading.Tasks;
using System.Web.Http;
using System.Web.Http.Description;
using OnlineGame.WebApi.Models;

namespace OnlineGame.WebApi.Controllers.Api
{
    [RoutePrefix("api/gamer5")]
    public class GamerFiveController : ApiController
    {
        private OnlineGameContext _db = new OnlineGameContext();

        // GET: api/gamer5
        [Route("")]
        public IQueryable<Gamer> GetGamers()
        {
            return _db.Gamers;
        }

        // GET: api/gamer5/GetGamers2
        [Route("GetGamers2")]
        public IHttpActionResult GetGamers2()
        {
            return Ok(_db.Gamers);
        }

        // GET: api/gamer5/GetGamers3
        [Route("GetGamers3")]
        public HttpResponseMessage GetGamers3()
        {
            return Request.CreateResponse(_db.Gamers);
        }

        // GET: api/gamer5/GetGamer/1
        [Route("GetGamer/{id:int}")]
        [ResponseType(typeof(Gamer))]
        public async Task<IHttpActionResult> GetGamer(int id)
        {
            Gamer gamer = await _db.Gamers.FindAsync(id);
            if (gamer == null) return NotFound();   //404
            return Ok(gamer);
        }

        // GET: api/gamer5/GetGamer2/1
        [Route("GetGamer2/{id:int}")]
        [ResponseType(typeof(Gamer))]
        public async Task<HttpResponseMessage> GetGamer2(int id)
        {
            Gamer gamer = await _db.Gamers.FindAsync(id);
            if (gamer == null)
                return Request.CreateErrorResponse(HttpStatusCode.NotFound,
                "Gamer not found"); //404
            return Request.CreateResponse(gamer);
        }

        // GET: api/gamer5/GetGamer3/1
        [Route("GetGamer3/{id:int}")]
        [ResponseType(typeof(Gamer))]
        public async Task<IHttpActionResult> GetGamer3(int id)
        {
            Gamer gamer = await _db.Gamers.FindAsync(id);
            if (gamer == null)
                return Content(HttpStatusCode.NotFound, "Gamer not found"); //404
            return Ok(gamer);
        }

        protected override void Dispose(bool disposing)
        {
            if (disposing) _db.Dispose();
            base.Dispose(disposing);
        }

        private bool GamerExists(int id)
        {
            return _db.Gamers.Count(e => e.Id == id) > 0;
        }
    }
}

/*
10.
IHttpActionResult vs HttpResponseMessage
10.1.
IHttpActionResult
10.1.1.
HttpResponseMessage is from Web API 1
IHttpActionResult is from Web API 2
10.1.2.
IHttpActionResult make code cleaner.
10.1.3.
The following type implements IHttpActionResult interface.
Unauthorized()
BadRequest()
NotFound()
Created()
OK()
InternalServerError()
*/
