﻿using System;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Threading.Tasks;
using System.Web.Http;
using System.Web.Http.Description;
using OnlineGame.WebApi.Models;

namespace OnlineGame.WebApi.Controllers.Api
{
    [RoutePrefix("api/gamer4")]
    public class GamerFourController : ApiController
    {
        private OnlineGameContext _db = new OnlineGameContext();

        // GET: api/GamerFour
        public IQueryable<Gamer> GetGamers()
        {
            return _db.Gamers;
        }

        // GET: api/GamerFour/1
        [ResponseType(typeof(Gamer))]
        public async Task<IHttpActionResult> GetGamer(int id)
        {
            Gamer gamer = await _db.Gamers.FindAsync(id);
            if (gamer == null) return NotFound();   //404
            return Ok(gamer);
        }

        // GET: api/Gamer4/1
        [ResponseType(typeof(Gamer))]
        [Route("{id:int}", Name = "GetGamerById")]
        public async Task<IHttpActionResult> GetGamerById(int id)
        {
            Gamer gamer = await _db.Gamers.FindAsync(id);
            if (gamer == null) return NotFound();   //404
            return Ok(gamer);
        }

        //IHttpActionResult is from Web API 2
        // POST: api/GamerFour
        [HttpPost]
        [ResponseType(typeof(Gamer))]
        public async Task<IHttpActionResult> PostGamer(Gamer gamer)
        {
            if (!ModelState.IsValid) return BadRequest(ModelState); //400
            _db.Gamers.Add(gamer);
            await _db.SaveChangesAsync();

            //Return Created/201.
            return CreatedAtRoute("DefaultApi", new { id = gamer.Id }, gamer);    //Created/201
        }

        // POST: api/Gamer4/AddGamer
        [HttpPost]
        [Route("AddGamer")]
        public async Task<HttpResponseMessage> AddGamer(Gamer gamer)
        {
            if (!ModelState.IsValid)
                return Request.CreateErrorResponse(HttpStatusCode.BadRequest,
                   "ModelState is invalid");    //400
        
            _db.Gamers.Add(gamer);
            await _db.SaveChangesAsync();

            //Return Created/201.
            HttpResponseMessage response = Request.CreateResponse(HttpStatusCode.Created);
            response.Headers.Location = new Uri(Request.RequestUri + "/" + gamer.Id);

            return response;    //Created/201
        }

        //IHttpActionResult is from Web API 2
        // POST: api/Gamer4/AddGamer2
        [Route("AddGamer2")]
        [HttpPost]
        [ResponseType(typeof(Gamer))]
        public async Task<IHttpActionResult> AddGamer2(Gamer gamer)
        {
            if (!ModelState.IsValid) return BadRequest(ModelState); //400
            _db.Gamers.Add(gamer);
            await _db.SaveChangesAsync();
            //Return Created/201.
            return CreatedAtRoute("DefaultApi", new { id = gamer.Id }, gamer);    //Created/201
        }

        // POST: api/Gamer4/AddGamer3
        [HttpPost]
        [Route("AddGamer3")]
        public async Task<HttpResponseMessage> AddGamer3(Gamer gamer)
        {
            if (!ModelState.IsValid)
                return Request.CreateErrorResponse(HttpStatusCode.BadRequest,
                   "ModelState is invalid");    //400

            _db.Gamers.Add(gamer);
            await _db.SaveChangesAsync();

            //Return Created/201.
            HttpResponseMessage response = Request.CreateResponse(HttpStatusCode.Created);
            response.Headers.Location = new
                        Uri(Url.Link("GetGamerById", new { id = gamer.Id }));
            return response;    //Created/201
        }

        // POST: api/Gamer4/AddGamer4
        [HttpPost]
        [Route("AddGamer4")]
        public async Task<IHttpActionResult> AddGamer4(Gamer gamer)
        {
            if (!ModelState.IsValid) return BadRequest(ModelState); //400
            _db.Gamers.Add(gamer);
            await _db.SaveChangesAsync();
            //Return Created/201.
            return CreatedAtRoute("GetGamerById", new { id = gamer.Id }, gamer);    //Created/201
        }

        protected override void Dispose(bool disposing)
        {
            if (disposing) _db.Dispose();
            base.Dispose(disposing);
        }

        private bool GamerExists(int id)
        {
            return _db.Gamers.Count(e => e.Id == id) > 0;
        }
    }
}

/*
9.
Route names
9.1.
E.g.
//[Route("{id:int}", Name = "GetGamerById")]
//public async Task<IHttpActionResult> GetGamerById(int id)
...
//HttpResponseMessage response = Request.CreateResponse(HttpStatusCode.Created);
//response.Headers.Location = new
//    Uri(Url.Link("GetGamerById", new { id = gamer.Id }));
...
//return CreatedAtRoute("GetGamerById", new { id = gamer.Id }, gamer);    //Created/201
9.2.
//return CreatedAtRoute("DefaultApi", new { id = gamer.Id }, gamer);    //Created/201
...
//HttpResponseMessage response = Request.CreateResponse(HttpStatusCode.Created);
//response.Headers.Location = new Uri(Request.RequestUri + "/" + gamer.Id);
*/
