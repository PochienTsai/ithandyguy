﻿using System.Collections.Generic;
using System.Data.Entity;
using System.Threading.Tasks;
using System.Web.Http;
using OnlineGame.WebApi.Models;

namespace OnlineGame.WebApi.Controllers.Api
{
    public class GamerTwoController : ApiController
    {
        private OnlineGameContext _db = new OnlineGameContext();

        [HttpGet]
        public async Task<IEnumerable<Gamer>> GetGamers()
        {
            ////Don't login, and call this action.
            ////Get request to  api/gamertwo

            //string userName = User.Identity.Name;   //E.g. null
            //string userAuthType = User.Identity.AuthenticationType; //E.g. null
            //bool userIsAuthenticated = User.Identity.IsAuthenticated;   //E.g. false

            //string requestContextName = RequestContext.Principal.Identity.Name; //E.g. null
            //string requestContextAuthType = RequestContext.Principal.Identity.AuthenticationType;   //E.g. null
            //bool requestContextIsAuthenticated = RequestContext.Principal.Identity.IsAuthenticated; //E.g. false

            return await _db.Gamers.ToListAsync();
        }
    }
}
