﻿using System;
using System.Collections.Generic;
using System.Data.Entity;
using System.Linq;
using System.Net;
using System.Threading.Tasks;
using System.Web;
using System.Web.Mvc;
using Microsoft.AspNet.Identity;
using Microsoft.AspNet.Identity.EntityFramework;
using OnlineGame.WebApi.Models;
using OnlineGame.WebApi.Models.User;

namespace OnlineGame.WebApi.Controllers
{
    public class UserController : Controller
    {
        private ApplicationDbContext _db = new ApplicationDbContext();

        // GET: User
        [HttpGet]
        public async Task<ActionResult> Index()
        {
            //Get userStore, userManager and List<ApplicationUser>
            var userStore = new UserStore<ApplicationUser>(_db);
            var userManager = new UserManager<ApplicationUser>(userStore);
            List<ApplicationUser> users = await userManager.Users.ToListAsync();
            return View(users);
        }


        // GET: User/Details/9d51c9c6-8433-4e5f-bbbb-b966efc133e3
        [HttpGet]
        public async Task<ActionResult> Details(string id)
        {
            if (string.IsNullOrEmpty(id))
                return new HttpStatusCodeResult(HttpStatusCode.BadRequest);

            //User Manager
            UserManager<ApplicationUser> userManager = 
                new UserManager<ApplicationUser>(new UserStore<ApplicationUser>(_db));

            //Find the User by id
            //ApplicationUser currentUser = await userManager.Users.FirstAsync(u=>u.Id.Equals(id));
            ApplicationUser currentUser = await userManager.FindByIdAsync(id);

            if (currentUser == null) return HttpNotFound();

            return View(currentUser);
        }


        //http://localhost:60626/user/AssignRoleToUserIndex?userId=1
        [HttpGet]
        public async Task<ActionResult> AssignRoleToUserIndex(string userId)
        {
            //UnassignedRoles
            //AssignedRoles
            if (string.IsNullOrEmpty(userId))
                return new HttpStatusCodeResult(HttpStatusCode.BadRequest);

            //User Manager
            UserManager<ApplicationUser> userManager =
                new UserManager<ApplicationUser>(new UserStore<ApplicationUser>(_db));

            //Role Manager
            RoleManager<IdentityRole> roleManager =
                new RoleManager<IdentityRole>(new RoleStore<IdentityRole>(_db));

            //Find the User by id
            //ApplicationUser currentUser = await userManager.Users.FirstAsync(u=>u.Id.Equals(id));
            ApplicationUser currentUser = await userManager.FindByIdAsync(userId);
            if (currentUser == null) return HttpNotFound();


            //Find the assignedRoles and unassignedRoles -------------
            //ICollection<IdentityUserRole> assignedIdentityUserRole = currentUser.Roles;
            List<IdentityRole> assignedRoles = currentUser.Roles.Select(isu => roleManager.FindByIdAsync(isu.RoleId).Result).ToList();      //P1
            List<IdentityRole> allRoles = await roleManager.Roles.ToListAsync();        //P2

            // var result = p2List.Where(p => !p1List.Any(p2 => p2.ID == p.ID));    //p2-p1
            // var result = p2List.Where(p => p1List.All(p2 => p2.ID != p.ID)); //p2-p1
            List<IdentityRole> unassignedRoles =
                allRoles
                .Where(assignedRoleItem =>
                assignedRoles.All(allRolesItem => allRolesItem.Id != assignedRoleItem.Id))
                .ToList();

            //Store the assignedRoles, unassignedRoles and current user information -------------
            AssignRoleToUserIndexViewModel assignRoleToUserIndexViewModel =
                new AssignRoleToUserIndexViewModel
                {
                    User = currentUser,
                    UnassignedRoles = unassignedRoles,
                    AssignedRoles = assignedRoles
                };

            return View(assignRoleToUserIndexViewModel);
        }


        [HttpGet]
        public async Task<ActionResult> AssignRoleToUser(string userId, string roleId)
        {
            if (string.IsNullOrEmpty(userId)|| string.IsNullOrEmpty(roleId))
                return new HttpStatusCodeResult(HttpStatusCode.BadRequest);

            //User Manager
            UserManager<ApplicationUser> userManager =
                new UserManager<ApplicationUser>(new UserStore<ApplicationUser>(_db));

            //Assign the role to user
            IdentityResult idResult = await userManager.AddToRoleAsync(userId, RoleController.GetRoleNameById(roleId));

            if (!idResult.Succeeded)
                return new HttpStatusCodeResult(HttpStatusCode.BadRequest);

            return RedirectToAction("AssignRoleToUserIndex", new { userId });
        }


        [HttpGet]
        public async Task<ActionResult> UnassignRoleToUser(string userId, string roleId)
        {
            if (string.IsNullOrEmpty(userId) || string.IsNullOrEmpty(roleId))
                return new HttpStatusCodeResult(HttpStatusCode.BadRequest);

            //User Manager
            UserManager<ApplicationUser> userManager =
                new UserManager<ApplicationUser>(new UserStore<ApplicationUser>(_db));

            //Assign the role to user
            IdentityResult idResult = await userManager.RemoveFromRoleAsync(userId, RoleController.GetRoleNameById(roleId));

            if (!idResult.Succeeded)
                return new HttpStatusCodeResult(HttpStatusCode.BadRequest);

            return RedirectToAction("AssignRoleToUserIndex", new { userId });
        }


        protected override void Dispose(bool disposing)
        {
            if (disposing) _db.Dispose();
            base.Dispose(disposing);
        }
    }
}