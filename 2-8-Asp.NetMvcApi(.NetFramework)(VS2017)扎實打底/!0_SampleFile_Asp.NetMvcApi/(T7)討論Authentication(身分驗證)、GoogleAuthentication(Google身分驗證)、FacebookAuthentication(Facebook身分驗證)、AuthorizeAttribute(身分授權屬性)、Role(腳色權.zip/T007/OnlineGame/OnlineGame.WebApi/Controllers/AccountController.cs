﻿using System.Net;
using System.Threading.Tasks;
using System.Web.Mvc;
using Microsoft.AspNet.Identity;
using Microsoft.AspNet.Identity.EntityFramework;
using OnlineGame.WebApi.Models;

namespace OnlineGame.WebApi.Controllers
{
    public class AccountController : Controller
    {
        [HttpGet]
        public ActionResult Register()
        {
            return View();
        }

        [HttpGet]
        public ActionResult Login()
        {
            return View();
        }

        [HttpGet]
        public ActionResult GenerateSampleUserAndRole()
        {
            return View();
        }

        [HttpPost]
        public async Task<ActionResult> GenerateAdminRoleAndUser()
        {
            using (var context = new ApplicationDbContext())
            {
                //Role ---------------------------
                //Create roleStore and roleManager.
                var roleStore = new RoleStore<IdentityRole>(context);
                var roleManager = new RoleManager<IdentityRole>(roleStore);

                //Create Role which name is Administrator.
                IdentityResult idResultCreateRole = await roleManager.CreateAsync(new IdentityRole { Name = "Administrator" });
                if (!idResultCreateRole.Succeeded)
                    return new HttpStatusCodeResult(HttpStatusCode.BadRequest);


                //User ---------------------------
                //Create userStore and userManager
                var userStore = new UserStore<ApplicationUser>(context);
                var userManager = new UserManager<ApplicationUser>(userStore);

                //Create applicationUser and insert to AspNetUsers
                var applicationUser = new ApplicationUser { UserName = "admin@onlinegame.com", Email = "admin@onlinegame.com" };
                IdentityResult idResult = await userManager.CreateAsync(applicationUser, "!1B2c3");
                if (!idResult.Succeeded)
                    return new HttpStatusCodeResult(HttpStatusCode.BadRequest);

                //Find the user by user name
                ApplicationUser user = await userManager.FindByNameAsync("admin@onlinegame.com");

                //Assign Administrator Role to admin@onlinegame.com
                IdentityResult idResultAssignRole = await userManager.AddToRoleAsync(user.Id, "Administrator");
                if (!idResultAssignRole.Succeeded)
                    return new HttpStatusCodeResult(HttpStatusCode.BadRequest);
            }

            return RedirectToAction("GenerateSampleUserAndRole");
        }


        [HttpPost]
        public async Task<ActionResult> GeneratePowerUserRoleAndUser()
        {
            using (var context = new ApplicationDbContext())
            {
                //Role ---------------------------
                //Create roleStore and roleManager.
                var roleStore = new RoleStore<IdentityRole>(context);
                var roleManager = new RoleManager<IdentityRole>(roleStore);

                //Create Role which name is Poweristrator.
                IdentityResult idResultCreateRole = await roleManager.CreateAsync(new IdentityRole { Name = "PowerUser" });
                if (!idResultCreateRole.Succeeded)
                    return new HttpStatusCodeResult(HttpStatusCode.BadRequest);


                //User ---------------------------
                //Create userStore and userManager
                var userStore = new UserStore<ApplicationUser>(context);
                var userManager = new UserManager<ApplicationUser>(userStore);

                //Create applicationUser and insert to AspNetUsers
                var applicationUser = new ApplicationUser { UserName = "power@onlinegame.com", Email = "power@onlinegame.com" };
                IdentityResult idResult = await userManager.CreateAsync(applicationUser, "!1B2c3");
                if (!idResult.Succeeded)
                    return new HttpStatusCodeResult(HttpStatusCode.BadRequest);

                //Find the user by user name
                ApplicationUser user = await userManager.FindByNameAsync("power@onlinegame.com");

                //Assign PowerUser Role to power@onlinegame.com
                IdentityResult idResultAssignRole = await userManager.AddToRoleAsync(user.Id, "PowerUser");
                if (!idResultAssignRole.Succeeded)
                    return new HttpStatusCodeResult(HttpStatusCode.BadRequest);
            }

            return RedirectToAction("GenerateSampleUserAndRole");
        }



        [HttpPost]
        public async Task<ActionResult> UpdatePowerUserRoleToPower()
        {
            using (var context = new ApplicationDbContext())
            {
                //Role ---------------------------
                //Create roleStore and roleManager.
                var roleStore = new RoleStore<IdentityRole>(context);
                var roleManager = new RoleManager<IdentityRole>(roleStore);

                //Find the Role
                IdentityRole currentRole = await roleManager.FindByNameAsync("PowerUser");
                if (currentRole == null) return HttpNotFound();

                //Edit Role Name
                currentRole.Name = "Power";
                IdentityResult idResultUpdateRole = await roleManager.UpdateAsync(currentRole);
                if (!idResultUpdateRole.Succeeded)
                    return new HttpStatusCodeResult(HttpStatusCode.BadRequest);
            }

            return RedirectToAction("GenerateSampleUserAndRole");
        }




        [HttpPost]
        public async Task<ActionResult> AssignPowerRoleToAdminUser()
        {
            using (var context = new ApplicationDbContext())
            {
                //User ---------------------------
                //Create userStore and userManager
                var userStore = new UserStore<ApplicationUser>(context);
                var userManager = new UserManager<ApplicationUser>(userStore);

                //Find the user by user name
                ApplicationUser user = await userManager.FindByNameAsync("admin@onlinegame.com");

                //Assign PowerUser Role to power@onlinegame.com
                IdentityResult idResultAssignRole = await userManager.AddToRoleAsync(user.Id, "Power");
                if (!idResultAssignRole.Succeeded)
                    return new HttpStatusCodeResult(HttpStatusCode.BadRequest);
            }

            return RedirectToAction("GenerateSampleUserAndRole");
        }
    }
}