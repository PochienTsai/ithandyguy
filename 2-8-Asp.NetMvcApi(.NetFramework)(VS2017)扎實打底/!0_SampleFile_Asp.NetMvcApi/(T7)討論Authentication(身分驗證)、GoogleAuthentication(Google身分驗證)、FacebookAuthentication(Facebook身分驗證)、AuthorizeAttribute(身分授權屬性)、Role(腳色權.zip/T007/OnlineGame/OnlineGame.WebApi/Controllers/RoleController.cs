﻿using System.Collections.Generic;
using System.Data.Entity;
using System.Net;
using System.Threading.Tasks;
using System.Web.Mvc;
using Microsoft.AspNet.Identity;
using Microsoft.AspNet.Identity.EntityFramework;
using OnlineGame.WebApi.Models;

namespace OnlineGame.WebApi.Controllers
{
    public class RoleController : Controller
    {
        private ApplicationDbContext _db = new ApplicationDbContext();

        // GET: Role
        [HttpGet]
        public async Task<ActionResult> Index()
        {
            //Get roleStore, roleManager and List<IdentityRole>
            var roleStore = new RoleStore<IdentityRole>(_db);
            var roleManager = new RoleManager<IdentityRole>(roleStore);
            List<IdentityRole> roles = await roleManager.Roles.ToListAsync();
            return View(roles);
        }

        // GET: Role/Details/9d51c9c6-8433-4e5f-bbbb-b966efc133e3
        [HttpGet]
        public async Task<ActionResult> Details(string id)
        {
            if (string.IsNullOrEmpty(id))
                return new HttpStatusCodeResult(HttpStatusCode.BadRequest);

            //Role Manager
            RoleManager<IdentityRole> roleManager = 
                new RoleManager<IdentityRole>(new RoleStore<IdentityRole>(_db));

            //Find the Role by id
            //IdentityRole currentRole = await roleManager.Roles.FirstAsync(r => r.Id.Equals(id));
            IdentityRole currentRole = await roleManager.FindByIdAsync(id);

            if (currentRole == null) return HttpNotFound();

            return View(currentRole);
        }


        // GET: Role/Create
        [HttpGet]
        //[Authorize]
        public ActionResult Create()
        {
            return View();
        }


        // POST: Role/Create
        // To protect from overposting attacks, please enable the specific properties you want to bind to, for
        // more details see https://go.microsoft.com/fwlink/?LinkId=317598.
        //[Authorize]
        [HttpPost]
        public async Task<ActionResult> Create(IdentityRole role)
        {
            if (!ModelState.IsValid) return View(role);

            //Role Manager
            RoleManager<IdentityRole> roleManager = 
                new RoleManager<IdentityRole>(new RoleStore<IdentityRole>(_db));

            //Create a role, Administrator.
            IdentityResult result = await roleManager.CreateAsync(role);
            if (!result.Succeeded)
                return new HttpStatusCodeResult(HttpStatusCode.BadRequest);

            return RedirectToAction("Index");
        }


        // GET: Role/Edit/9d51c9c6-8433-4e5f-bbbb-b966efc133e3
        //[Authorize]
        [HttpGet]
        public async Task<ActionResult> Edit(string id)
        {
            if (string.IsNullOrEmpty(id))
                return new HttpStatusCodeResult(HttpStatusCode.BadRequest);

            //Role Manager
            RoleManager<IdentityRole> roleManager =
                new RoleManager<IdentityRole>(new RoleStore<IdentityRole>(_db));

            //Find the Role by id
            //IdentityRole currentRole = await roleManager.Roles.FirstAsync(r => r.Id.Equals(id));
            IdentityRole currentRole = await roleManager.FindByIdAsync(id);

            if (currentRole == null) return HttpNotFound();
            return View(currentRole);
        }


        // POST: Role/Edit/9d51c9c6-8433-4e5f-bbbb-b966efc133e3
        // To protect from overposting attacks, please enable the specific properties you want to bind to, for
        // more details see https://go.microsoft.com/fwlink/?LinkId=317598.
        //[Authorize]
        [HttpPost]
        public async Task<ActionResult> Edit(IdentityRole role)
        {
            if (!ModelState.IsValid) return View(role);

            //Role Manager
            RoleManager<IdentityRole> roleManager =
                new RoleManager<IdentityRole>(new RoleStore<IdentityRole>(_db));

            //Find the Role by id
            //IdentityRole currentRole = await roleManager.FindByNameAsync(role.Name);    //Error, role.Name is the new value. 
            //IdentityRole currentRole = await roleManager.Roles.FirstAsync(r => r.Id.Equals(role.Id));
            IdentityRole currentRole = await roleManager.FindByIdAsync(role.Id);

            if (currentRole == null) return HttpNotFound();

            currentRole.Name = role.Name;
            IdentityResult idResult = await roleManager.UpdateAsync(currentRole);
            if (!idResult.Succeeded)
                return new HttpStatusCodeResult(HttpStatusCode.BadRequest);
            return RedirectToAction("Index");
        }



        // GET: Role/Delete/9d51c9c6-8433-4e5f-bbbb-b966efc133e3
        //[Authorize]
        [HttpGet]
        public async Task<ActionResult> Delete(string id)
        {
            if (string.IsNullOrEmpty(id))
                return new HttpStatusCodeResult(HttpStatusCode.BadRequest);

            //Role Manager
            RoleManager<IdentityRole> roleManager =
                new RoleManager<IdentityRole>(new RoleStore<IdentityRole>(_db));

            //Find the Role by id
            //IdentityRole currentRole = await roleManager.Roles.FirstAsync(r => r.Id.Equals(id));
            IdentityRole currentRole = await roleManager.FindByIdAsync(id);

            if (currentRole == null) return HttpNotFound();

            return View(currentRole);
        }


        // POST: Role/Delete/9d51c9c6-8433-4e5f-bbbb-b966efc133e3
        //[Authorize]
        [HttpPost, ActionName("Delete")]
        public async Task<ActionResult> DeleteConfirmed(string id)
        {
            if (string.IsNullOrEmpty(id))
                return new HttpStatusCodeResult(HttpStatusCode.BadRequest);

            //Role Manager
            RoleManager<IdentityRole> roleManager =
                new RoleManager<IdentityRole>(new RoleStore<IdentityRole>(_db));

            //Find the Role by id
            //IdentityRole currentRole = await roleManager.Roles.FirstAsync(r => r.Id.Equals(id));
            IdentityRole currentRole = await roleManager.FindByIdAsync(id);

            if (currentRole == null) return HttpNotFound();

            IdentityResult idResult = await roleManager.DeleteAsync(currentRole);
            if (!idResult.Succeeded)
                return new HttpStatusCodeResult(HttpStatusCode.BadRequest);
            return RedirectToAction("Index");
        }


        public static string GetRoleNameById(string id)
        {
            using (ApplicationDbContext db = new ApplicationDbContext())
            {
                //Role Manager
                RoleManager<IdentityRole> roleManager =
                    new RoleManager<IdentityRole>(new RoleStore<IdentityRole>(db));

                //Find the Role by id
                //IdentityRole currentRole = await roleManager.Roles.FirstAsync(r => r.Id.Equals(id));
                IdentityRole currentRole = roleManager.FindById(id);

                return currentRole?.Name;
            }
        }

        protected override void Dispose(bool disposing)
        {
            if (disposing) _db.Dispose();
            base.Dispose(disposing);
        }
    }
}