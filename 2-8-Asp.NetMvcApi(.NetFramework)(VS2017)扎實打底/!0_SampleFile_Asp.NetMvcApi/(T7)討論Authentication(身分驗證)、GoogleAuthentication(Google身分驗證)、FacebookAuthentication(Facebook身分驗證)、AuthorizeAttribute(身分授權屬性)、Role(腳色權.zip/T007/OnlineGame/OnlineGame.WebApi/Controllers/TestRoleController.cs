﻿using System.Web.Mvc;

namespace OnlineGame.WebApi.Controllers
{
    public class TestRoleController : Controller
    {
        [HttpGet]
        public ActionResult AccessByWhatever()
        {
            return View();
        }

        [HttpGet]
        [Authorize]
        public ActionResult AccessByAnyLogin()
        {
            return View();
        }

        [HttpGet]
        [Authorize(Roles="Admin, Power")]
        public ActionResult AccessByAdminAndPowerRole()
        {
            return View();
        }

        [HttpGet]
        [Authorize(Roles = "Administrator")]
        public ActionResult AccessByAdminRole()
        {
            return View();
        }

        [HttpGet]
        [Authorize(Users = "admin@onlinegame.com")]
        public ActionResult AccessByAdminUser()
        {
            return View();
        }

        [HttpGet]
        [Authorize(Roles = "Power")]
        public ActionResult AccessByPowerRole()
        {
            return View();
        }
    }
}