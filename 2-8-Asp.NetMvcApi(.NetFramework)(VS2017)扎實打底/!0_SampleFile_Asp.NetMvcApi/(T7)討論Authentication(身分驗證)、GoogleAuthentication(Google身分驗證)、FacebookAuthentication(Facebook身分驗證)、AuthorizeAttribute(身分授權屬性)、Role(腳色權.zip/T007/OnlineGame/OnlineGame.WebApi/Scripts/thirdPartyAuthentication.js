﻿/*
1.
Reference:
http://csharp-video-tutorials.blogspot.com.au/2016/12/aspnet-web-api-google-authentication.html
http://csharp-video-tutorials.blogspot.com.au/2017/02/aspnet-web-api-facebook-authentication.html
https://www.youtube.com/watch?v=j-cTQImwFCo
https://www.youtube.com/watch?v=4NvmOIQI3Dw

2.
Pre-Requirement:
2.1.
In CSHTML, Scripts.Render("~/bundles/jquery")
It will load everything regarding "jquery" from "Scripts" folder
< script src = "/Scripts/modernizr-2.6.2.js" ></script >
*/

//Get the access_token value from URL
function getAccessToken() {
    if (location.hash) {
        if (location.hash.split('access_token=')) {
            var accessToken = location.hash.split('access_token=')[1].split('&')[0];
            if (accessToken) {
                isUserRegistered(accessToken);
            }
        }
    }
}

//Check if the third party authentication user has registered our web application.
function isUserRegistered(accessToken) {

    //1.
    //GET Request
    ////http://localhost:[YourPort]/api/Account/UserInfo
    //1.1.
    //Request Header:
    ////Host: localhost: [YourPort]
    ////Authorization: Bearer 9r7oinUQmHy8hQO0XFZYnBLz9SlFgnoVVvU0CeV452dvfcTRS8amFsBfF502N4omVEVt1PFlo1W7_iTj3hvm40RpxZO3s9Zia39kduT2o8MFT3TEGvhC1wu1jyJOwuet1RV4H6oKKMiyaYuaI4ZZGJ7hN_ncPaoPRXJ - sirvhGk6xNzq8IXPZ9e9f5gQa4fA_oGhi9sHY5avKTS_KmVJjFENDE701UgNTNNgpzNXEKoKDXAQ2MygJ7uDCZW4aV6A6SFUf5zBRlE9X7orq8X8oRnVZDA1coKz5i0Z - Ya4cwG7CH_62M3yQnuMbeZjl - 54Nqvxc01pJ - 3b0FrM1mmwfhr_Lxizg - 836jD1KPkAJlg

    $.ajax({
        url: '/api/Account/UserInfo',
        method: 'GET',

        headers: {
            'content-type': 'application/JSON', //response body will be JSON format
            'Authorization': 'Bearer ' + accessToken    //Use Bearer token
        },

        success: function (response) {
            if (response.HasRegistered) {

                //2.
                //If response.HasRegistered==true, 
                //it means the user has registered our web application.
                //Response will be as the following.
                ////{"$id": "1",
                ////"Email": "lin Kevin",
                ////"HasRegistered": true,
                ////"LoginProvider": "Google"}


                ////A.
                //sessionStorage.setItem('accessToken', accessToken);
                //sessionStorage.setItem('userName', response.Email);   //"lin Kevin"
                //sessionStorage.setItem('userHasRegistered', response.HasRegistered);  //true
                //sessionStorage.setItem('userLoginProvider', response.LoginProvider); //"Google"

                //B.
                localStorage.setItem('accessToken', accessToken);
                localStorage.setItem('userName', response.Email);   //"lin Kevin"
                localStorage.setItem('userHasRegistered', response.HasRegistered);  //true
                localStorage.setItem('userLoginProvider', response.LoginProvider); //"Google"

                //alert(window.location);   //Get current full url.
                //alert(window.location.href);    //Get current full url.
                //alert(window.location.pathname);  //Get the current PathName.  E.g. /Account/Login
                //window.location.href = "/Gamer/GamerList";   //It will go to /Account/Gamer/GamerList

                //It is always better to use window.location.pathname
                window.location.pathname = "/Gamer/GamerList"; 
            }
            else {
                //3.
                //If response.HasRegistered==false, 
                //it means the user has NOT registered our web application.
                //Response will be as the following.
                ////{"$id": "1",
                ////"Email": "lin Kevin",
                ////"HasRegistered": false,
                ////"LoginProvider": "Google"}


                //If the user has NOT registered our web application,
                //Register this person as new user.
                signupExternalUser(accessToken, response.LoginProvider);
            }
        }
    });
}


//Register a new user.
//Parameters:
//accessToken
//    The value of access_token from the response after the third-party authentication.
//authenticationProvider:
//    The third-party authentication provider.  E.g. 'Google' or 'Facebook'

function signupExternalUser(accessToken, authenticationProvider) {

    //1.
    //Post Request
    ////http://localhost:[YourPort]/api/Account/RegisterExternalOnClient
    //1.1.
    //Request Header:
    ////Host: localhost: [YourPort]
    ////Authorization: Bearer 9r7oinUQmHy8hQO0XFZYnBLz9SlFgnoVVvU0CeV452dvfcTRS8amFsBfF502N4omVEVt1PFlo1W7_iTj3hvm40RpxZO3s9Zia39kduT2o8MFT3TEGvhC1wu1jyJOwuet1RV4H6oKKMiyaYuaI4ZZGJ7hN_ncPaoPRXJ - sirvhGk6xNzq8IXPZ9e9f5gQa4fA_oGhi9sHY5avKTS_KmVJjFENDE701UgNTNNgpzNXEKoKDXAQ2MygJ7uDCZW4aV6A6SFUf5zBRlE9X7orq8X8oRnVZDA1coKz5i0Z - Ya4cwG7CH_62M3yQnuMbeZjl - 54Nqvxc01pJ - 3b0FrM1mmwfhr_Lxizg - 836jD1KPkAJlg

    $.ajax({
        url: '/api/Account/RegisterExternalOnClient',
        method: 'POST',

        headers: {
            'content-type': 'application/json',
            'Authorization': 'Bearer ' + accessToken
        },

        success: function () {
            //1.
            //E.g.
            //window.location.href = "/api/Account/ExternalLogin?provider=Google&response_type=token&client_id=self&redirect_uri=http%3A%2F%2Flocalhost%3A50360%2FAccount%2FLogin&state=Rx0F0zdP-voRqOo2JO_YYBM7wI4w7D6lj_SfGIHwO8M1";
            //1.1. 
            ////redirect_uri=http%3A%2F%2Flocalhost%3A50360%2FAccount%2FLogin
            //After URL decoded, it means 
            ////redirect_uri=http://localhost:[YourPort]/Account/Login


            //window.location.href = '/api/Account/ExternalLogin?provider=' + authenticationProvider + '&response_type=token&client_id=self&redirect_uri=http%3A%2F%2Flocalhost%3A50360%2FAccount%2FLogin&state=Rx0F0zdP-voRqOo2JO_YYBM7wI4w7D6lj_SfGIHwO8M1';

            //window.location.href = "/api/Account/ExternalLogin?provider=Google&response_type=token&client_id=self&redirect_uri=https%3A%2F%2Flocalhost%3A44365%2FAccount%2FLogin&state=3hlNdWd1vluyoZUmlIbvWGkecj5ys2Lg1JbByWvdTBI1";

            window.location.href = '/api/Account/ExternalLogin?provider=' + authenticationProvider + '&response_type=token&client_id=self&redirect_uri=https%3A%2F%2Flocalhost%3A44365%2FAccount%2FLogin&state=3hlNdWd1vluyoZUmlIbvWGkecj5ys2Lg1JbByWvdTBI1';
        }
    });

}


/*

1.
function getAccessToken()
Get the access_token value from URL
1.1.
After you login with Google.
It will return the URL as the following.
http://localhost:50360/Account/Login#access_token=IfaufjJStNt0VlCXLuk3004oAr3Arac1vi2Vv1opGB_Bkuu5YfJax52K0PRkX5eEEK3DcczEbZYVkqtNPsQWuTfwBjYeEUFSB1WiKX5-MjTIKFLa1NwvyB8MeuJensTRywklb_qkyeYVhRj16YzzTVdhI-S9PovUpbFcy-_fW03aZ-LKjqe3YoR0kinluMrRdR-Tk_tdQAf7uh8--GKzWYru6pnAFOQCK0yar7TxaAnyVtaYI_ZeLKaeOCLr3bnDvPUxHvngBeej1pUjacGdYmnatbPbCiXgoX5w6JXG7KIGtL202272EbsZzshxkZqhvpqu5KgGRRVCHbUPRPTU-oWhKzK8CDbLesZ_7DQv5wE&token_type=bearer&expires_in=7200&state=Rx0F0zdP-voRqOo2JO_YYBM7wI4w7D6lj_SfGIHwO8M1
After '#', it is the access_token.
1.2.
//location.hash
it will return whatever you have after '#' in the URL.
1.3.
//if (location.hash)
If there is a hash in the URL
1.4.
//if (location.hash.split('access_token='))
It will split whatever you have after '#' by 'access_token='.
//var accessToken = location.hash.split('access_token=')[1]
It means it will return the value of access_token plus other information
E.g. access_token=XX&token_type=XXX...
//var accessToken = location.hash.split('access_token=')[1].split('&')[0];
It means split the "access_token plus other information" by '&', and then take index 0 part.
It will return the value of access_token.
1.5.
//if (accessToken)
if the accessToken is existent.
//isUserRegistered(accessToken)
Check if the user is registered.
*/