﻿using System.Net.Http.Formatting;
using System.Web.Http;
using Microsoft.Owin.Security.OAuth;
using OnlineGame.WebApi.WebShared;

namespace OnlineGame.WebApi
{
    public static class WebApiConfig
    {
        public static void Register(HttpConfiguration config)
        {
            // Web API configuration and services
            // Configure Web API to use only bearer token authentication.
            config.SuppressDefaultHostAuthentication();
            config.Filters.Add(new HostAuthenticationFilter(OAuthDefaults.AuthenticationType));

            // Web API routes
            config.MapHttpAttributeRoutes();

            config.Routes.MapHttpRoute(
                name: "DefaultApi",
                routeTemplate: "api/{controller}/{id}",
                defaults: new { id = RouteParameter.Optional }
            );

            //Use JSON formatter as a PreserveReferencesHandling.
            JsonMediaTypeFormatter json = config.Formatters.JsonFormatter;
            json.SerializerSettings.PreserveReferencesHandling = Newtonsoft.Json.PreserveReferencesHandling.Objects;
            //Remove Xml Formatter
            config.Formatters.Remove(config.Formatters.XmlFormatter);

            //-----------------------------
            //4.
            //HTTP request will redirect to HTTPS request
            config.Filters.Add(new HttpsAuthorizationFilterAttribute());
        }
    }
}

/*
1.
//JsonMediaTypeFormatter json = config.Formatters.JsonFormatter;
//json.SerializerSettings.PreserveReferencesHandling = Newtonsoft.Json.PreserveReferencesHandling.Objects;
//config.Formatters.Remove(config.Formatters.XmlFormatter);
Use JSON formatter as a PreserveReferencesHandling.
Remove Xml Formatter
Reference:
A.
https://forums.asp.net/t/1983286.aspx?Web+API+error+The+ObjectContent+1+type+failed+to+serialize+the+response+body+for+content+type+application+xml+charset+utf+8+
B.
https://stackoverflow.com/questions/23098191/failed-to-serialize-the-response-in-web-api-with-json

-------------------------------------
//4.
HTTP redirect to HTTPS
4.1.
In OnlineGame.WebApi/App_Start/WebApiConfig.cs
//config.Filters.Add(new HttpsAuthorizationFilterAttribute());
HTTP will redirect to HTTPS request.
If you add HttpsAuthorizationFilterAttribute in WebApiConfig.cs,
it will apply to the entire application.
4.2.
If you don't want to apply to the entire application,

You may apply [HttpsAuthorizationFilter] attribute at controller level or action level.
E.g.
//[HttpsAuthorizationFilter]
//public class GamerController : ApiController
...
//[HttpsAuthorizationFilter]
//public async Task<IHttpActionResult> GetGamers(string gender = "all")
*/
