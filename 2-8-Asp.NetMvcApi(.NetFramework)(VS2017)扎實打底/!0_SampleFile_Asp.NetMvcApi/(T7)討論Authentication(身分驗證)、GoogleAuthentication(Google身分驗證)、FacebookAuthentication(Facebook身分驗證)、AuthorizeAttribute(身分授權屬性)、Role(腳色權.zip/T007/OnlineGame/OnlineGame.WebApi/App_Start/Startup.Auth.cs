﻿using System;
using System.Collections.Generic;
using System.Linq;
using Microsoft.AspNet.Identity;
using Microsoft.AspNet.Identity.EntityFramework;
using Microsoft.Owin;
using Microsoft.Owin.Security.Cookies;
using Microsoft.Owin.Security.Facebook;
using Microsoft.Owin.Security.Google;
using Microsoft.Owin.Security.OAuth;
using Owin;
using OnlineGame.WebApi.Providers;
using OnlineGame.WebApi.Models;
using OnlineGame.WebApi.WebShared.Facebook;

namespace OnlineGame.WebApi
{
    public partial class Startup
    {
        public static OAuthAuthorizationServerOptions OAuthOptions { get; private set; }

        public static string PublicClientId { get; private set; }

        // For more information on configuring authentication, please visit https://go.microsoft.com/fwlink/?LinkId=301864
        public void ConfigureAuth(IAppBuilder app)
        {
            // Configure the db context and user manager to use a single instance per request
            app.CreatePerOwinContext(ApplicationDbContext.Create);
            app.CreatePerOwinContext<ApplicationUserManager>(ApplicationUserManager.Create);

            // Enable the application to use a cookie to store information for the signed in user
            // and to use a cookie to temporarily store information about a user logging in with a third party login provider
            app.UseCookieAuthentication(new CookieAuthenticationOptions());
            app.UseExternalSignInCookie(DefaultAuthenticationTypes.ExternalCookie);

            // Configure the application for OAuth based flow
            PublicClientId = "self";
            OAuthOptions = new OAuthAuthorizationServerOptions
            {
                TokenEndpointPath = new PathString("/Token"),
                //The request path. 
                //E.g. we may send a post request to /Token path
                //with the token which contains the username and password.

                Provider = new ApplicationOAuthProvider(PublicClientId),
                //ApplicationOAuthProvider.GrantResourceOwnerCredentials() method create a ticket which contains the provided username and password. 
                ////context.Validated(ticket);
                //It verifies the ticket, if the ticket is valid, then issue an access token.
                ////context.Request.Context.Authentication.SignIn(cookiesIdentity);
                //When the user has the valid access token,
                //it means the user access the application based on the permission of that token.
                //The application will issue cookies contains the signed-in user information
                //and stores it in client side.

                AuthorizeEndpointPath = new PathString("/api/Account/ExternalLogin"),
                //if you are using claim-based authentication such as Azure AD, facebook...
                //you will have to call AccountController ExternalLogin method.

                ////1.
                //AccessTokenExpireTimeSpan = TimeSpan.FromDays(14),
                ////E.g.1.
                ////The token will expire in 14 days.

                //2.
                AccessTokenExpireTimeSpan = TimeSpan.FromHours(2),
                //The token will expire in 2 hour.

                AllowInsecureHttp = true    //true is only for developerment mode.
                // In production mode set AllowInsecureHttp = false
            };

            // Enable the application to use bearer tokens to authenticate users
            app.UseOAuthBearerTokens(OAuthOptions);

            // Uncomment the following lines to enable logging in with third party login providers
            //app.UseMicrosoftAccountAuthentication(
            //    clientId: "",
            //    clientSecret: "");


            //Twitter Authentication -----------------------------
            //app.UseTwitterAuthentication(
            //    consumerKey: "",
            //    consumerSecret: "");


            //Facebook Authentication -----------------------------

            //app.UseFacebookAuthentication(
            //    appId: "",
            //    appSecret: "");

            var facebookOptions = new FacebookAuthenticationOptions()
            {
                //Reference:
                //http://csharp-video-tutorials.blogspot.com.au/2017/02/aspnet-web-api-facebook-authentication.html
                //The url of Facebook authentication v2.3 is as the following.
                //https://graph.facebook.com/v2.3/me?access_token=AAAA
                //However, the url of Facebook authentication v2.4 is as the following.
                //https://graph.facebook.com/v2.4/me?fields=id,email&access_token=AAAA
                //So we have to replace "?access_token" by "&access_token"
                //So we need our self defined FacebookBackChannelHandler to replace "?access_token" by "&access_token"
                AppId = "168252800668962",
                AppSecret = "0af34181e4503a3ffae2ffd1070a15ab",
                BackchannelHttpHandler = new FacebookBackChannelHandler(),
                UserInformationEndpoint = "https://graph.facebook.com/v2.4/me?fields=id,email"
            };
            facebookOptions.Scope.Add("email"); //v2.4 need email, so we need add scope email.
            app.UseFacebookAuthentication(facebookOptions); //Enable Facebook Authentication with options.


            //Google Authentication -----------------------------
            app.UseGoogleAuthentication(new GoogleOAuth2AuthenticationOptions()
            {
                ClientId = "550841110423-khfcucp3vdsam94vpl4o5vk16cesmvbh.apps.googleusercontent.com",
                ClientSecret = "9UfyWLg7HuXx0oSs8FHhEzzU"
            });
        }
    }
}
