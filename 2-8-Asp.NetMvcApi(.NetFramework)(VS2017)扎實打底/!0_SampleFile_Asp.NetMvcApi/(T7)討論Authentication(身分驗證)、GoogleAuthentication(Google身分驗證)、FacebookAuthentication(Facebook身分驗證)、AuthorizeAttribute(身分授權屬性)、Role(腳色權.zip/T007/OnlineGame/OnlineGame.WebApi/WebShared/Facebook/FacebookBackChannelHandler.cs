﻿using System;
using System.Net.Http;
using System.Threading;
using System.Threading.Tasks;

namespace OnlineGame.WebApi.WebShared.Facebook
{
    public class FacebookBackChannelHandler : HttpClientHandler
    {
        protected override async Task<HttpResponseMessage>
            SendAsync(HttpRequestMessage request,
                      CancellationToken cancellationToken)
        {
            //if the url does not contains "/oauth" which usually means it is third-party Authentication such as Facebook.
            //So we have to correct the url.
            if (!request.RequestUri.AbsolutePath.Contains("/oauth"))
            {
                request.RequestUri = new Uri(
                    request.RequestUri.AbsoluteUri.Replace("?access_token", "&access_token"));
            }
            //After you correct the url, then use base method to send request.
            return await base.SendAsync(request, cancellationToken);
        }
    }
}

/*
Reference:
http://csharp-video-tutorials.blogspot.com.au/2017/02/aspnet-web-api-facebook-authentication.html
The url of Facebook authentication v2.3 is as the following.
https://graph.facebook.com/v2.3/me?access_token=AAAA
However, the url of Facebook authentication v2.4 is as the following.
https://graph.facebook.com/v2.4/me?fields=id,email&access_token=AAAA
So we have to replace "?access_token" by "&access_token" 
*/
