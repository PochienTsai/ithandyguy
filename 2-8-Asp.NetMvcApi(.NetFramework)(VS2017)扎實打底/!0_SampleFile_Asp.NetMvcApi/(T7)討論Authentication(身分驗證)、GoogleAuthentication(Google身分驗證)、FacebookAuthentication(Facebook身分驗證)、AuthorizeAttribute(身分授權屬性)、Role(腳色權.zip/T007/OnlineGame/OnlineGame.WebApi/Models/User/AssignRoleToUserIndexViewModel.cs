﻿using System.Collections.Generic;
using Microsoft.AspNet.Identity.EntityFramework;

namespace OnlineGame.WebApi.Models.User
{
    public class AssignRoleToUserIndexViewModel
    {
        public ApplicationUser User { get; set; }
        public List<IdentityRole> AssignedRoles { get; set; }
        public List<IdentityRole> UnassignedRoles { get; set; }
    }
}
