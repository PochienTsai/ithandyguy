Select * from AspNetUsers
Select * from AspNetUserLogins
Select * from AspNetUserRoles
Select * from AspNetRoles
Select * from AspNetUserClaims