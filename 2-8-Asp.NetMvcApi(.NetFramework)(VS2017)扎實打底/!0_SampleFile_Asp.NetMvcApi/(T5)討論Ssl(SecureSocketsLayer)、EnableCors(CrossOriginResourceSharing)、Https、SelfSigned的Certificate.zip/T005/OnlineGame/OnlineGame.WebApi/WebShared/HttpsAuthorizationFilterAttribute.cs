﻿using System;
using System.Net;
using System.Net.Http;
using System.Text;
using System.Web.Http.Controllers;
using System.Web.Http.Filters;

namespace OnlineGame.WebApi.WebShared
{
    public class HttpsAuthorizationFilterAttribute : AuthorizationFilterAttribute
    {
        public override void OnAuthorization(HttpActionContext actionContext)
        {
            //If the request is not HTTPS request.
            if (actionContext.Request.RequestUri.Scheme != Uri.UriSchemeHttps)
            {
                //If the resourece is found, then create a response with HttpStatusCode.Found/302.
                actionContext.Response = actionContext.Request
                    .CreateResponse(HttpStatusCode.Found);
                //Create a response content that encoding is UTF8 and mediaType is html.
                actionContext.Response.Content = new StringContent
                    ("<p>HTTPS is required.</p>", Encoding.UTF8, "text/html");
                //Create a new URI by current requested URI. 
                //The new URI will redirect HTTPS. 44365 is the SSL URL port.
                UriBuilder uriBuilder = new UriBuilder(actionContext.Request.RequestUri)
                {
                    Scheme = Uri.UriSchemeHttps,
                    Port = 44365    //*************Change to your port
                };
                //Set the Response.Headers.Location to new URI,
                //It will redirect to new URI that is HTTPS URI
                actionContext.Response.Headers.Location = uriBuilder.Uri;
            }
            else
            {
                //If the request is the HTTPS request,
                //then do what it supposed to do.
                base.OnAuthorization(actionContext);
            }
        }
    }
}
