﻿using System.Web.Http;
using System.Web.Http.Cors;
using WebApiContrib.Formatting.Jsonp;

namespace OnlineGame.WebApi
{
    public static class WebApiConfig
    {
        public static void Register(HttpConfiguration config)
        {
            // Web API configuration and services

            // Web API routes
            config.MapHttpAttributeRoutes();

            config.Routes.MapHttpRoute(
                name: "DefaultApi",
                routeTemplate: "api/{controller}/{id}",
                defaults: new { id = RouteParameter.Optional }
            );

            ////1.
            ////JSONP allows Jquery AJAX may call Web API in the different origins
            ////Create a new JSON media type formatter,
            ////and insert it into first position of HttpConfiguration formatter.
            ////It will allow you to use JSONP formatter which 
            ////can wrap the JSON data in a function
            //JsonpMediaTypeFormatter jsonpFormatter = 
            //    new JsonpMediaTypeFormatter(config.Formatters.JsonFormatter);
            //config.Formatters.Insert(0, jsonpFormatter);

            ////2.
            ////WebApi Cors(Cross Origin Resource Sharing)
            ////allows Jquery AJAX may call Web API in the different origins
            ////2.1.
            ////EnableCorsAttribute(origins, headers, methods)
            ////It allows the resource to be accessed by all origins, 
            ////and it accepts any request header ("accept,content-type,origin...etc"),
            ////and it accepts all methods ("GET,POST...etc")
            //EnableCorsAttribute cors = new EnableCorsAttribute("*", "*", "*");
            //config.EnableCors(cors);


            //2.2.
            config.EnableCors();
        }
    }
}

/*
1.
JSONP allows Jquery AJAX may call Web API in the different origins
//JsonpMediaTypeFormatter jsonpFormatter = 
//    new JsonpMediaTypeFormatter(config.Formatters.JsonFormatter);
//config.Formatters.Insert(0, jsonpFormatter);
Create a new JSON media type formatter,
and insert it into first position of HttpConfiguration formatter.
It will allow you to use JSONP formatter which 
can wrap the JSON data in a function
E.g.1.1. JSON
{
    "Name":"KL",
     "Gender":"Male"
}
E.g.1.2. JSONP
CallbackFunction({
    "Name":"KL",
     "Gender":"Male"
})

-------------------------------------
3.
WebApi Cors (Cross Origin Resource Sharing) 
allows Jquery AJAX may call Web API in the different origins 
-------------------------------
3.1.
new EnableCorsAttribute(origins, headers, methods)
//EnableCorsAttribute cors = new EnableCorsAttribute("*", "*", "*");
//config.EnableCors(cors);
It allows the resource to be accessed by all origins, 
and it accepts any request header ("accept,content-type,origin...etc"),
and it accepts all methods ("GET,POST...etc")
----------------
3.1.1.
origins:
It is a Comma-separated whitelist which are allowed to access the web api by Ajax call.
E.g.3.1.1.1. 
"http://localhost:49804,https://ithandyguytutorial.blogspot.com.au"
That means only http://localhost:49804 and https://ithandyguytutorial.blogspot.com.au
can access the web api by Ajax call.
E.g.3.1.1.2. 
"*"
It means allows all origins to access the web api by Ajax call.
----------------
3.1.2.
headers:
It is a Comma-separated whitelist of request headers which are supported by the resource.
E.g.3.1.2.1.
"accept,content-type,origin" means only these 3 things can be used in request header.
E.g.3.1.2.2.
"*"
It means allows all request headers to the web api by Ajax call.
----------------
3.1.3.
methods:
It is a Comma-separated whitelist of methods which are supported by the resource.
E.g.3.1.3.1.
"GET,POST" means only these 2 methods can be used in request.
E.g.3.1.3.2.
"*"
It means allows all request methods to the web api by Ajax call.
-------------------------------
3.2.
In OnlineGame.WebApi/App_Start/WebApiConfig.cs
//config.EnableCors();
In OnlineGame.WebApi/Controllers/Api/GamerController.cs
////[EnableCors("*", "*", "*")]
////[EnableCors("https://ithandyguytutorial.blogspot.com.au", "*", "*")]
//[EnableCors("http://localhost:49804", "*", "*")]
//public class GamerController : ApiController
...
//[DisableCors]
//[HttpGet]
//public async Task<IHttpActionResult> LoadGamers(string gender = "")
3.2.1.
If you don't want to enable Cors globally, 
then you may enable Cors in api controller level or method level.
When you enable Cors, in api controller level, 
//[EnableCors("*", "*", "*")]
it will apply to all methods in that controller.
If you want to exclude any method, then you may use 
//[DisableCors]
3.2.2.
3.2.2.1.
//[EnableCors("*", "*", "*")]
EnableCorsAttribute(origins, headers, methods)
It allows the resource to be accessed by all origins, 
and it accepts any request header ("accept,content-type,origin...etc"),
and it accepts all methods ("GET,POST...etc")
3.2.2.2.
//[EnableCors("https://ithandyguytutorial.blogspot.com.au", "*", "*")]
EnableCorsAttribute(origins, headers, methods)
It allows the resource to be accessed by https://ithandyguytutorial.blogspot.com.au origins, 
and it accepts any request header ("accept,content-type,origin...etc"),
and it accepts all methods ("GET,POST...etc")
3.2.2.3.
//[EnableCors("http://localhost:49804", "*", "*")]
It allows the resource to be accessed by http://localhost:49804 origins, 
and it accepts any request header ("accept,content-type,origin...etc"),
and it accepts all methods ("GET,POST...etc")
*/
