﻿using System.Collections.Generic;
using System.Linq;
using System.Web.Http;
using OnlineGame.Data;

namespace OnlineGame.WebApiB.Controllers
{
    [RoutePrefix("api/v2/gamers")]
    public class GamerV2Controller : ApiController
    {
        List<GamerV2> _gamers = new List<GamerV2>
        {
            new GamerV2 { Id = 1, FirstName = "NameFirstOne", LastName = "NameLastOne"},
            new GamerV2 { Id = 2, FirstName = "NameFirstTwo", LastName = "NameLastTwo"},
            new GamerV2 { Id = 3, FirstName = "NameFirstThree", LastName = "NameLastThree"}
        };

        // GET: api/v2/gamers
        [Route("")]
        public IEnumerable<GamerV2> Get()
        {
            return _gamers;
        }

        // GET: api/v2/gamers/1
        [Route("{id}")]
        public GamerV2 Get(int id)
        {
            return _gamers.FirstOrDefault(s => s.Id == id);
        }
    }
}
