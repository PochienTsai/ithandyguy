﻿using System.Collections.Generic;
using System.Linq;
using System.Web.Http;
using OnlineGame.Data;

namespace OnlineGame.WebApiD.Controllers
{
    public class GamerV1Controller : ApiController
    {
        List<GamerV1> _gamers = new List<GamerV1>
        {
            new GamerV1 { Id = 1, Name = "NameOne"},
            new GamerV1 { Id = 2, Name = "NameTwo"},
            new GamerV1{ Id = 3, Name = "NameThree"},
        };

        public IEnumerable<GamerV1> Get()
        {
            return _gamers;
        }

        public GamerV1 Get(int id)
        {
            return _gamers.FirstOrDefault(s => s.Id == id);
        }
    }
}
