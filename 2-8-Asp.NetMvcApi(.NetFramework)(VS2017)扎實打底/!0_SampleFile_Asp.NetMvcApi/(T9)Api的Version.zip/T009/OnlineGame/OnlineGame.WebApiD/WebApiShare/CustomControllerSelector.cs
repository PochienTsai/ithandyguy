﻿using System.Collections.Generic;
using System.Linq;
using System.Net.Http;
using System.Web.Http;
using System.Web.Http.Controllers;
using System.Web.Http.Dispatcher;
using System.Web.Http.Routing;

namespace OnlineGame.WebApiD.WebApiShare
{
    public class CustomControllerSelector : DefaultHttpControllerSelector
    {
        private HttpConfiguration _configuration;
        public CustomControllerSelector(HttpConfiguration configuration) : base(configuration)
        {
            _configuration = configuration;
        }

        public override HttpControllerDescriptor SelectController(HttpRequestMessage request)
        {
            //1.
            //Get all API controllers
            // GetControllerMapping returns all controllers which extend ApiController
            IDictionary<string, HttpControllerDescriptor> controllers =
                GetControllerMapping();
            //request.GetRouteData() returns controller name and parameter values from the request URI
            IHttpRouteData routeData = request.GetRouteData();

            //2.
            //Get Controller Name
            // routeData.Values["controller"].ToString() returns
            // the controller name from route data.
            // In this case, the controller name is "Gamers".
            string controllerName =
                routeData.Values["controller"].ToString();

            //3.
            //Set default versionNumber
            // Default version number to 1
            string versionNumber = "1";


            //4.
            //Get the version number


            ////4.1.
            ////Get version value from QueryString value
            //NameValueCollection queryString =
            //    HttpUtility.ParseQueryString(request.RequestUri.Query);
            //if (queryString["v"] != null) versionNumber = queryString["v"];


            //4.2.
            //Get the version number from Custom version header
            //customHeader can be any string which we will use it when issuing a request.
            string customHeader = "X-Gamer-Version";
            if (request.Headers.Contains(customHeader))
                versionNumber = request.Headers.GetValues(customHeader).FirstOrDefault();

            //5.
            //Get the versionNumber from query string.
            // if versionNumber==1, then controllerName=controllerName+"V1"
            // if versionNumber==2, then controllerName=controllerName+"V2"
            controllerName =
                controllerName +
                (versionNumber == "1" ? "V1" : "V2");

            //6.
            //Find the Controller by the name
            HttpControllerDescriptor controllerDescriptor;
            if (controllers.TryGetValue(controllerName, out controllerDescriptor))
                return controllerDescriptor;

            return null;
        }
    }
}
