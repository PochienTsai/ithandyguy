﻿using System.Collections.Generic;
using System.Linq;
using System.Net.Http;
using System.Net.Http.Headers;
using System.Text.RegularExpressions;
using System.Web.Http;
using System.Web.Http.Controllers;
using System.Web.Http.Dispatcher;
using System.Web.Http.Routing;

namespace OnlineGame.WebApiF.WebApiShare
{
    public class CustomControllerSelector : DefaultHttpControllerSelector
    {
        private HttpConfiguration _configuration;
        public CustomControllerSelector(HttpConfiguration configuration) : base(configuration)
        {
            _configuration = configuration;
        }

        public override HttpControllerDescriptor SelectController(HttpRequestMessage request)
        {
            //1.
            //Get all API controllers
            // GetControllerMapping returns all controllers which extend ApiController
            IDictionary<string, HttpControllerDescriptor> controllers =
                GetControllerMapping();
            //request.GetRouteData() returns controller name and parameter values from the request URI
            IHttpRouteData routeData = request.GetRouteData();

            //2.
            //Get Controller Name
            // routeData.Values["controller"].ToString() returns
            // the controller name from route data.
            // In this case, the controller name is "Gamers".
            string controllerName =
                routeData.Values["controller"].ToString();

            //3.
            //Set default versionNumber
            // Default version number to 1
            string versionNumber = "1";


            //4. ------------------------------------
            //Get the version number


            ////4.1. ----------------
            ////Get version value from QueryString value
            //NameValueCollection queryString =
            //    HttpUtility.ParseQueryString(request.RequestUri.Query);
            //if (queryString["v"] != null) versionNumber = queryString["v"];


            ////4.2. ----------------
            ////Get the version number from Custom version header
            ////customHeader can be any string which we will use it when issuing a request.
            //string customHeader = "X-Gamer-Version";
            //if (request.Headers.Contains(customHeader))
            //    versionNumber = request.Headers.GetValues(customHeader).FirstOrDefault();


            ////4.3. ----------------
            ////Get the version number by the request header Accept property.
            ////E.g. Accept: application/json; version=2

            ////4.3.1.
            ////request.Headers.Accept returns the value of request header accept property.
            ////Request header Accept property can contains many parameters which are seperated by ";".
            ////One of parameter can be "version", and we can read its value.
            ////4.3.2.
            //////request.Headers.Accept.Where(a => a.Parameters.Count(p => p.Name.ToLower() == "version") > 0)
            ////it tells us whether the Request header Accept property has the parameter called "version".
            //IEnumerable<MediaTypeWithQualityHeaderValue> acceptHeader = 
            //    request.Headers.Accept.Where(a => a.Parameters
            //                    .Count(p => p.Name.ToLower() == "version") > 0);

            ////acceptHeader is possible to be multiple enumeration of IEnumerable, 
            ////thus, we have to convert to MediaTypeWithQualityHeaderValue[] or empty array.
            //MediaTypeWithQualityHeaderValue[] mediaTypeWithQualityHeaderValues = 
            //    acceptHeader as MediaTypeWithQualityHeaderValue[] ?? acceptHeader.ToArray();

            //// If the Request header Accept property has the parameter called "version".
            //if (mediaTypeWithQualityHeaderValues.Any())
            //{
            //    // Get the version parameter value from the Accept header
            //    versionNumber = mediaTypeWithQualityHeaderValues.First().Parameters
            //                    .First(p => p.Name.ToLower() == "version").Value;
            //}


            ////4.4. ----------------
            //Get the version number from the Custom media type


            //4.4.1.
            //In request header "Accept" property.
            //E.g. Accept: applicaiton/xml   or  Accept: applicaiton/json
            //xml and json are media type.
            //We want to use Custom media type
            //E.g. Accept: applicaiton/vnd.ithandyguy.gamer.v1+json
            //In our case, it will call GamerV1Controller and return json format.
            //E.g. Accept: applicaiton/vnd.ithandyguy.gamer.v2+json
            //In our case, it will call GamerV2Controller and return json format.
            //4.4.2.
            //"vnd" means vendor specific media type
            //"vnd.ithandyguy" means vender ithandyguy
            //4.4.3.
            ////application\/vnd\.ithandyguy\.([a-z]+)\.v(?<version>[0-9]+)\+([a-z]+)
            //It is a regular expression.
            //E.g. "applicaiton/vnd.ithandyguy.gamer.v1+json"
            //4.4.3.1.
            //"application\/vnd\.ithandyguy\." means "application.vnd.ithandyguy"
            //4.4.3.2.
            //"([a-z]+)" means from a to z. "+" means any number of characters
            //4.4.3.3.
            //"[0-9]+" means from 0 to 9. "+" means any number of characters.
            //4.4.3.4.
            //"(?<version>[0-9]+)" 
            //<version> is the group name.
            //using the group name("version") instead of ZERO based index
            //4.4.3.5.
            //versionNumber = match.Groups["version"].Value;
            //it retrieves the version number 
            string regex =
                @"application\/vnd\.ithandyguy\.([a-z]+)\.v(?<version>[0-9]+)\+([a-z]+)";

            //Request Header Accept property contains many parameters.
            //It will check if any of parameter has our custom media type 
            //by checking if there is a match with regular expression specified
            IEnumerable<MediaTypeWithQualityHeaderValue> acceptHeader = 
                request.Headers.Accept
                .Where(a => Regex.IsMatch(a.MediaType, regex, RegexOptions.IgnoreCase));

            //acceptHeader is possible to be multiple enumeration of IEnumerable, 
            //thus, we have to convert to MediaTypeWithQualityHeaderValue[] or empty array.
            MediaTypeWithQualityHeaderValue[] mediaTypeWithQualityHeaderValues =
                   acceptHeader as MediaTypeWithQualityHeaderValue[] ?? acceptHeader.ToArray();

            // If there is atleast one Accept header with our custom media type
            if (mediaTypeWithQualityHeaderValues.Any())
            {
                // Retrieve the first custom media type
                Match match = 
                    Regex.Match(mediaTypeWithQualityHeaderValues.First().MediaType,
                    regex, RegexOptions.IgnoreCase);
                // From the version group, get the version number
                versionNumber = match.Groups["version"].Value;
            }


            //5. ----------------------------------------
            //Get the versionNumber from query string.
            // if versionNumber==1, then controllerName=controllerName+"V1"
            // if versionNumber==2, then controllerName=controllerName+"V2"
            controllerName =
                controllerName +
                (versionNumber == "1" ? "V1" : "V2");

            //6.
            //Find the Controller by the name
            HttpControllerDescriptor controllerDescriptor;
            if (controllers.TryGetValue(controllerName, out controllerDescriptor))
                return controllerDescriptor;

            return null;
        }
    }
}
