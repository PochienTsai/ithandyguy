﻿using System.Net.Http.Headers;
using System.Web.Http;
using System.Web.Http.Dispatcher;
using OnlineGame.WebApiF.WebApiShare;

namespace OnlineGame.WebApiF
{
    public static class WebApiConfig
    {
        public static void Register(HttpConfiguration config)
        {
            // Web API configuration and services

            // Web API routes
            config.MapHttpAttributeRoutes();

            config.Routes.MapHttpRoute(
                name: "DefaultApi",
                routeTemplate: "api/{controller}/{id}",
                defaults: new { id = RouteParameter.Optional }
            );

            //Replace the default controller selector,IHttpControllerSelector,
            //with our custom controller selector,CustomControllerSelector.
            config.Services.Replace(typeof(IHttpControllerSelector),
                new CustomControllerSelector(config));

            //Add custom media type for JSON formatter
            config.Formatters.JsonFormatter.SupportedMediaTypes
                .Add(new MediaTypeHeaderValue("application/vnd.ithandyguy.gamer.v1+json"));
            config.Formatters.JsonFormatter.SupportedMediaTypes
                .Add(new MediaTypeHeaderValue("applicaiton/vnd.ithandyguy.gamer.v2+json"));

            //Add custom media type for XML formatter
            config.Formatters.XmlFormatter.SupportedMediaTypes
                .Add(new MediaTypeHeaderValue("application/vnd.ithandyguy.gamer.v1+xml"));
            config.Formatters.XmlFormatter.SupportedMediaTypes
                .Add(new MediaTypeHeaderValue("application/vnd.ithandyguy.gamer.v2+xml"));
        }
    }
}
