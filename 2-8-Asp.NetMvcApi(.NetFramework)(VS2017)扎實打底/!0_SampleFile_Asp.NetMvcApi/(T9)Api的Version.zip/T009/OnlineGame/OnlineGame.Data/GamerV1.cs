﻿namespace OnlineGame.Data
{
    public class GamerV1
    {
        public int Id { get; set; }
        public string Name { get; set; }
    }
}
