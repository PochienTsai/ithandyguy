﻿namespace OnlineGame.Data
{
    public class GamerV2
    {
        public int Id { get; set; }
        public string FirstName { get; set; }
        public string LastName { get; set; }
    }
}
