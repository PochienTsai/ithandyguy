﻿using System.Web;
using System.Web.Mvc;

namespace OnlineGame.WebApiC
{
    public class FilterConfig
    {
        public static void RegisterGlobalFilters(GlobalFilterCollection filters)
        {
            filters.Add(new HandleErrorAttribute());
        }
    }
}
