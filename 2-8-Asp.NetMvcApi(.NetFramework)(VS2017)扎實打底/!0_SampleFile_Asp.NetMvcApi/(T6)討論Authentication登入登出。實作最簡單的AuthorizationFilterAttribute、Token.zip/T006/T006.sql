--1 ----------------------------------------------------------
--Drop Table if it exists.
IF ( EXISTS ( SELECT    *
              FROM      INFORMATION_SCHEMA.TABLES
              WHERE     TABLE_NAME = 'GamerIdentity' ) )
    BEGIN
        TRUNCATE TABLE GamerIdentity;
        DROP TABLE GamerIdentity;
    END;
GO -- Run the previous command and begins new batch
IF ( EXISTS ( SELECT    *
              FROM      INFORMATION_SCHEMA.TABLES
              WHERE     TABLE_NAME = 'Gamer' ) )
    BEGIN
        TRUNCATE TABLE Gamer;
        DROP TABLE Gamer;
    END;
GO -- Run the previous command and begins new batch


--2 ----------------------------------------------------------
CREATE TABLE Gamer
    (
      Id INT PRIMARY KEY
             IDENTITY(1, 1)
             NOT NULL ,
      Name NVARCHAR(50) NOT NULL ,
      Gender NVARCHAR(50) NOT NULL ,
      Score INT NOT NULL ,
      GameMoney INT NOT NULL
    );
GO -- Run the previous command and begins new batch

CREATE TABLE GamerIdentity
    (
      Id INT PRIMARY KEY
             FOREIGN KEY REFERENCES Gamer ( Id ) ,
      UserName NVARCHAR(50) UNIQUE NOT NULL ,
      [Password] NVARCHAR(50) NOT NULL,
    );
GO -- Run the previous command and begins new batch


--3 ----------------------------------------------------------
INSERT  INTO Gamer
VALUES  ( 'NameOne ABC', 'Male', 5000, 550 );
INSERT  INTO Gamer
VALUES  ( 'NameTwo ABCDE', 'Female', 4500, 1200 );
INSERT  INTO Gamer
VALUES  ( 'NameThree EFGH', 'Male', 6500, 3050 );
INSERT  INTO Gamer
VALUES  ( 'NameFour HIJKLMN', 'Female', 45000, 450 );
INSERT  INTO Gamer
VALUES  ( 'NameFive NOP', 'Male', 3000, 200 );
INSERT  INTO Gamer
VALUES  ( 'NameSix PQRSTUVW', 'Male', 4000, 700 );
INSERT  INTO Gamer
VALUES  ( 'NameSeven XYZ', 'Male', 450, 1500 );
GO -- Run the previous command and begins new batch

INSERT  INTO GamerIdentity
VALUES  ( 1, 'One', '1111' );
INSERT  INTO GamerIdentity
VALUES  ( 2, 'Two', '2222' );
INSERT  INTO GamerIdentity
VALUES  ( 3, 'Three', '3333' );
INSERT  INTO GamerIdentity
VALUES  ( 4, 'Four', '4444' );
INSERT  INTO GamerIdentity
VALUES  ( 5, 'Five', '5555' );
INSERT  INTO GamerIdentity
VALUES  ( 6, 'Six', '6666' );
INSERT  INTO GamerIdentity
VALUES  ( 7, 'Seven', '7777' );
GO -- Run the previous command and begins new batch