﻿using System;
using System.Net;
using System.Net.Http;
using System.Security.Principal;
using System.Text;
using System.Threading;
using System.Web.Http.Controllers;
using System.Web.Http.Filters;
namespace OnlineGame.WebApi.Account
{
    public class BasicAuthorizationFilterAttribute : AuthorizationFilterAttribute
    {
        public override void OnAuthorization(HttpActionContext actionContext)
        {
            //if there is no userName and password parameter from actionContext.Request.Headers.Authorization,
            //then response Unauthorized/401
            if (actionContext.Request.Headers.Authorization == null)
            {
                actionContext.Response = actionContext.Request
                    .CreateResponse(HttpStatusCode.Unauthorized);
            }
            else
            {
                //if there is a parameter from actionContext.Request.Headers.Authorization.
                //the Authorization.parameter is the token Base 64 String
                //which includes user name and password and they are separate by colon(:)
                //E.g. "username:password"
                string authToken =
                    actionContext.Request.Headers.Authorization.Parameter;
                //convert the string authToken from Base64String to UTF8 string.
                string decodedAuthToken = Encoding.UTF8.GetString(
                    Convert.FromBase64String(authToken));
                string[] usernamePasswordArray = decodedAuthToken.Split(':');
                string username = usernamePasswordArray[0];
                string password = usernamePasswordArray[1];
                //if the username and password is correct, then create a GenericPrincipal.
                if (Authentication.IsAuthentic(username, password))
                {
                    //GenericPrincipal has 2 parameters.
                    //The first parameter is a user IIdentity, in this case, username.
                    //The second parameter is string[] roles, in this case, null.
                    Thread.CurrentPrincipal = new GenericPrincipal(
                        new GenericIdentity(username), null);
                }
                else
                {
                    //if the username and password is not correct
                    //then response Unauthorized/401
                    actionContext.Response = actionContext.Request
                        .CreateResponse(HttpStatusCode.Unauthorized);
                }
            }
        }
    }
}
