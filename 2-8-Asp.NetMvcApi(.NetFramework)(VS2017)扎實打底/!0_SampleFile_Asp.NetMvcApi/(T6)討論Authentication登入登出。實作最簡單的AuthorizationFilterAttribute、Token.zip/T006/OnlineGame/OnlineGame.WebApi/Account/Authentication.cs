﻿using System;
using System.Linq;
using OnlineGame.Data;
namespace OnlineGame.WebApi.Account
{
    public class Authentication
    {
        public static bool IsAuthentic(string username, string password)
        {
            using (var db = new OnlineGameContext())
            {
                return db.GamerIdentities.Any(user =>
                       user.UserName.Equals(username, StringComparison.OrdinalIgnoreCase)
                                          && user.Password == password);
            }
        }
    }
}