﻿using System.Data.Entity;
using System.Data.Entity.Infrastructure;
using System.Linq;
using System.Threading;
using System.Threading.Tasks;
using System.Web.Http;
using System.Web.Http.Description;
using OnlineGame.Data;
using OnlineGame.WebApi.Account;

//using System.Web.Http.Cors;
//using OnlineGame.WebApi.WebShared;

namespace OnlineGame.WebApi.Controllers.Api
{
    //[EnableCors("*", "*", "*")]
    //[EnableCors("https://ithandyguytutorial.blogspot.com.au", "*", "*")]
    //[EnableCors("http://localhost:49804", "*", "*")]
    //[HttpsAuthorizationFilter]
    //[BasicAuthorizationFilter]
    public class GamerController : ApiController
    {
        private OnlineGameContext _db = new OnlineGameContext();

        //// GET: api/Gamer
        //[HttpGet]
        //public IQueryable<Gamer> GetGamers()
        //{
        //    return _db.Gamers;
        //}


        //GET: api/gamer?gender=female  --> Only Female Gamer
        //GET: api/gamer? gender = male-- > Only Male Gamer
        //GET: api/gamer --> All Gamers
        //[DisableCors]
        //[HttpsAuthorizationFilter]
        [BasicAuthorizationFilter]
        [HttpGet]
        public async Task<IHttpActionResult> GetGamers()
        {
            string username = Thread.CurrentPrincipal.Identity.Name;
            if (string.IsNullOrEmpty(username))
                return BadRequest($"{username} is null or empty.");

            //1.
            GamerIdentity gamerIdentity =
                await _db.GamerIdentities
                .Where(gi => gi.UserName.Equals(username))
                .FirstOrDefaultAsync();
            if (gamerIdentity == null) return NotFound();  //404
            Gamer gamer =
                await _db.Gamers
                .Where(g => g.Id == gamerIdentity.Id)
                .FirstOrDefaultAsync();
            if (gamer == null) return NotFound();  //404
            return Ok(gamer);   //200

            ////--------------------------
            ////2.
            ////Inner Join - Lambda expression query
            //var gamerJoinGamerIdentity =
            //     _db.Gamers.ToList().Join(_db.GamerIdentities.ToList(),
            //     g => g.Id,
            //     gi => gi.Id,
            //     (gamer, gamerIdentity) => new
            //     {
            //         GamerIdentity = gamerIdentity,
            //         Gamer = gamer
            //     }).FirstOrDefault(g => g.GamerIdentity.UserName == username);
            //if (gamerJoinGamerIdentity == null) return NotFound();  //404
            //return Ok(gamerJoinGamerIdentity.Gamer);   //200

            ////--------------------------
            ////3.
            ////Inner Join - Sql like query
            //var gamerJoinGamerIdentity =
            //   (from g in _db.Gamers.ToList()
            //    join gi in _db.GamerIdentities.ToList()
            //    on g.Id equals gi.Id
            //    select new
            //    {
            //        GamerIdentity = gi,
            //        Gamer = g
            //    }).FirstOrDefault(g => g.GamerIdentity.UserName == username);
            //if (gamerJoinGamerIdentity == null) return NotFound();  //404
            //return Ok(gamerJoinGamerIdentity.Gamer);   //200
        }


        // GET: api/Gamer/5
        [HttpGet]
        [ResponseType(typeof(Gamer))]
        public async Task<IHttpActionResult> GetGamer(int id)
        {
            Gamer gamer = await _db.Gamers.FindAsync(id);
            if (gamer == null) return NotFound();  //404
            return Ok(gamer);   //200
        }

        // PUT: api/Gamer/5
        [ResponseType(typeof(void))]
        [HttpPut]
        public async Task<IHttpActionResult> PutGamer(int id, Gamer gamer)
        {
            if (!ModelState.IsValid) return BadRequest(ModelState);  //400
            //if (id != gamer.Id)   return BadRequest();

            //1.
            gamer.Id = id;
            _db.Entry(gamer).State = EntityState.Modified;  //update the gamer

            //2.
            //Gamer currentGamer = await _db.Gamers.FirstOrDefaultAsync(g => g.Id == id);
            //if (currentGamer == null) return NotFound();  //404
            //currentGamer.Name = gamer.Name;
            //currentGamer.Gender = gamer.Gender;
            //currentGamer.Score = gamer.Score;
            //currentGamer.GameMoney = gamer.GameMoney;

            try
            {
                await _db.SaveChangesAsync();
                return Ok();    //200
            }
            catch (DbUpdateConcurrencyException)
            {
                if (!GamerExists(id)) return NotFound();  //404
                throw;
            }
        }

        // POST: api/Gamer
        [ResponseType(typeof(Gamer))]
        [HttpPost]
        public async Task<IHttpActionResult> PostGamer(Gamer gamer)
        {
            if (!ModelState.IsValid) return BadRequest(ModelState); //400
            _db.Gamers.Add(gamer);
            await _db.SaveChangesAsync();

            //Return Created/201.
            //1.
            return CreatedAtRoute("DefaultApi", new { id = gamer.Id }, gamer);    //Created/201
        }

        // DELETE: api/Gamer/5
        [ResponseType(typeof(Gamer))]
        [HttpDelete]
        public async Task<IHttpActionResult> DeleteGamer(int id)
        {
            Gamer gamer = await _db.Gamers.FindAsync(id);
            if (gamer == null) return NotFound();   //404
            _db.Gamers.Remove(gamer);
            await _db.SaveChangesAsync();
            return Ok(gamer);   //200
        }

        protected override void Dispose(bool disposing)
        {
            if (disposing) _db.Dispose();   //Dispose DBContext
            base.Dispose(disposing);
        }

        private bool GamerExists(int id)
        {
            return _db.Gamers.Count(e => e.Id == id) > 0;
        }
    }
}

/*
1.
1.1.
By default, the HTTP verb GET maps to a method that has the name Get() or "Get" prefix.
E.g. Get(), GetGamers, GetXXX()
If you want the HTTP verb GET maps to the method name without "Get" prefix.
You can use [HttpGet] attribute.
1.2.
[HttpGet] attribute maps HTTP verb GET.
[HttpPost] attribute maps HTTP verb POST.
[HttpPut] attribute maps HTTP verb PUT.
[HttpDelete] attribute maps HTTP verb DELETE. 

----------------------------
2.
[FromUri] V.S. [FromBody]
Web Api default binding parameter convention
2.1.
By default, if the parameter is a simple type,
Web Api will try to get value from uri.
E.g. int, double, bool, ...etc.
2.2.
By default, if the parameter is a complex type,
Web Api will try to get value from the request body.
E.g. Gamer
-----------------
2.3.
//[HttpPut]
//public async Task<IHttpActionResult> UpdateGamer(int id, Gamer gamer)  
By Default, the Web Api will try to get id from uri, and gamer from request body as below code.
//[HttpPut]
//public async Task<IHttpActionResult> UpdateGamer([FromUri]int id, [FromBody]Gamer gamer) 
E.g.
A.
PUT
http://localhost:58302/api/Gamer/8
B.
Request Header
Host: localhost:58302
Content-Type: application/json
B.1.
Accept: application/json
means we request JSON format response.
B.2.
Content-Type: application/json
The client will post a data to the server, the data format is JSON
C.
Request Body
{
"Name":"NameEight XYZ222", 
"Gender":"Male",
"Score":450,
"GameMoney":1500
}
-----------------
2.4.
//[HttpPut]
//public async Task<IHttpActionResult> UpdateGamer([FromBody]int id, [FromUri]Gamer gamer)
[FromBody] will enfroce to get id from request body
[FromUri] will enforce to get gamer from uri
E.g.
A.
PUT
http://localhost:58302/api/Gamer?Name=NameEight%20XYZ333&Gender=Male&Score=450&GameMoney=1500
B.
Request Header
Host: localhost:58302
Content-Type: application/json
B.1.
Accept: application/json
means we request JSON format response.
B.2.
Content-Type: application/json
The client will post a data to the server, the data format is JSON
C.
Request Body
8

-------------------------------------
3.
WebApi Cors (Cross Origin Resource Sharing) 
allows Jquery AJAX may call Web API in the different origins 
-------------------------------
3.1.
new EnableCorsAttribute(origins, headers, methods)
//EnableCorsAttribute cors = new EnableCorsAttribute("*", "*", "*");
//config.EnableCors(cors);
It allows the resource to be accessed by all origins, 
and it accepts any request header ("accept,content-type,origin...etc"),
and it accepts all methods ("GET,POST...etc")
----------------
3.1.1.
origins:
It is a Comma-separated whitelist which are allowed to access the web api by Ajax call.
E.g.3.1.1.1. 
"http://localhost:49804,https://ithandyguytutorial.blogspot.com.au"
That means only http://localhost:49804 and https://ithandyguytutorial.blogspot.com.au
can access the web api by Ajax call.
E.g.3.1.1.2. 
"*"
It means allows all origins to access the web api by Ajax call.
----------------
3.1.2.
headers:
It is a Comma-separated whitelist of request headers which are supported by the resource.
E.g.3.1.2.1.
"accept,content-type,origin" means only these 3 things can be used in request header.
E.g.3.1.2.2.
"*"
It means allows all request headers to the web api by Ajax call.
----------------
3.1.3.
methods:
It is a Comma-separated whitelist of methods which are supported by the resource.
E.g.3.1.3.1.
"GET,POST" means only these 2 methods can be used in request.
E.g.3.1.3.2.
"*"
It means allows all request methods to the web api by Ajax call.
-------------------------------
3.2.
In OnlineGame.WebApi/App_Start/WebApiConfig.cs
//config.EnableCors();
In OnlineGame.WebApi/Controllers/Api/GamerController.cs
////[EnableCors("*", "*", "*")]
////[EnableCors("https://ithandyguytutorial.blogspot.com.au", "*", "*")]
//[EnableCors("http://localhost:49804", "*", "*")]
//public class GamerController : ApiController
...
//[DisableCors]
//[HttpGet]
//public async Task<IHttpActionResult> LoadGamers(string gender = "")
3.2.1.
If you don't want to enable Cors globally, 
then you may enable Cors in api controller level or method level.
When you enable Cors, in api controller level, 
//[EnableCors("*", "*", "*")]
it will apply to all methods in that controller.
If you want to exclude any method, then you may use 
//[DisableCors]
3.2.2.
3.2.2.1.
//[EnableCors("*", "*", "*")]
EnableCorsAttribute(origins, headers, methods)
It allows the resource to be accessed by all origins, 
and it accepts any request header ("accept,content-type,origin...etc"),
and it accepts all methods ("GET,POST...etc")
3.2.2.2.
//[EnableCors("https://ithandyguytutorial.blogspot.com.au", "*", "*")]
EnableCorsAttribute(origins, headers, methods)
It allows the resource to be accessed by https://ithandyguytutorial.blogspot.com.au origins, 
and it accepts any request header ("accept,content-type,origin...etc"),
and it accepts all methods ("GET,POST...etc")
3.2.2.3.
//[EnableCors("http://localhost:49804", "*", "*")]
It allows the resource to be accessed by http://localhost:49804 origins, 
and it accepts any request header ("accept,content-type,origin...etc"),
and it accepts all methods ("GET,POST...etc")

-------------------------------------
4.
HTTP redirect to HTTPS
4.1.
In OnlineGame.WebApi/App_Start/WebApiConfig.cs
//config.Filters.Add(new HttpsAuthorizationFilterAttribute());
If you add the attribute in WebApiConfig.cs,
it will apply to the entire application.
4.2.
If you don't want to apply to the entire application,
You may apply the attribute at controller level or action level.
E.g.
//[HttpsAuthorizationFilter]
//public class GamerController : ApiController
...
//[HttpsAuthorizationFilter]
//public async Task<IHttpActionResult> GetGamers(string gender = "all")

-------------------------------------
5.
Use BasicAuthorizationFilterAttribute.
It is for understanding basic concept, not for real world practice.
5.1.
In OnlineGame.WebApi/App_Start/WebApiConfig.cs
//config.Filters.Add(new BasicAuthorizationFilterAttribute());
If you add the attribute in WebApiConfig.cs,
it will apply to the entire application.
5.2.
If you don't want to apply to the entire application,
You may apply the attribute at controller level or action level.
E.g.
//[BasicAuthorizationFilter]
//public class GamerController : ApiController
...
//[BasicAuthorizationFilter]
//public async Task<IHttpActionResult> GetGamers()
*/
