﻿using System.Web.Http;
using Newtonsoft.Json.Serialization;

namespace OnlineGame.WebApi
{
    public static class WebApiConfig
    {
        public static void Register(HttpConfiguration config)
        {
            // Web API configuration and services

            // Web API routes
            config.MapHttpAttributeRoutes();

            config.Routes.MapHttpRoute(
                name: "DefaultApi",
                routeTemplate: "api/{controller}/{id}",
                defaults: new { id = RouteParameter.Optional }
            );

            //by default, the server will return the response in Json format with pascal case.
            //If the server want to return the camel case Json data,
            //you have to modify the serialization settings as shown below
            config.Formatters.JsonFormatter.SerializerSettings.Formatting =
                            Newtonsoft.Json.Formatting.Indented;
            config.Formatters.JsonFormatter.SerializerSettings.ContractResolver =
                new CamelCasePropertyNamesContractResolver();
        }
    }
}

/*
1.
Content Negotiation means the format of the response from server 
is depending on the Accept in client Request header.
When Accept in client Request is "application/json",
by default, the server will return the response in Json format with pascal case.
E.g. pascal case --> "GamerMoney"
E.g. camel case --> "gamerMoney"
If the server want to return the camel case Json data,
you have to modify the serialization settings as shown below
//config.Formatters.JsonFormatter.SerializerSettings.Formatting =
//Newtonsoft.Json.Formatting.Indented;
//config.Formatters.JsonFormatter.SerializerSettings.ContractResolver =
//new CamelCasePropertyNamesContractResolver();
*/
