﻿using System;
using System.Collections.Generic;
using System.Data.Entity;
using System.Net;
using System.Net.Http;
using System.Threading.Tasks;
using System.Web.Http;
using OnlineGame.Data;

namespace OnlineGame.WebApi.Controllers
{
    public class GamerController : ApiController
    {
        public async Task<IEnumerable<Gamer>> Get()
        {
            using (OnlineGameContext db = new OnlineGameContext())
            {
                return await db.Gamers.ToListAsync();
            }
        }

        ////GET 1.
        ////It will return 200 OK even no matter the gamer is found or not.
        ////It should return 404 Not found when the gamer is not found.
        //public async Task<Gamer> Get(int id)
        //{
        //    using (OnlineGameContext db = new OnlineGameContext())
        //    {
        //        return await db.Gamers.FirstOrDefaultAsync(g => g.Id == id);
        //    }
        //}


        //GET 2.
        //It will return 200 OK even no matter the gamer is found or not.
        //It should return 404 Not found when the gamer is not found.
        public async Task<HttpResponseMessage> Get(int id)
        {
            using (OnlineGameContext db = new OnlineGameContext())
            {
                Gamer gamer = await db.Gamers.FirstOrDefaultAsync(g => g.Id == id);
                if (gamer != null)
                {
                    return Request.CreateResponse(HttpStatusCode.OK, gamer);    //OK 200
                }
                return Request.CreateErrorResponse(HttpStatusCode.NotFound,
                    $"Gamer with Id {id} not found");   //Not Found 404
            }
        }

        ////POST 1.
        ////"void" will return 204 No Content.
        ////It should return status code 201 Item Created.
        ////If there is an exception, return status code 500 internal server error.
        //public void Post([FromBody] Gamer gamer)
        //{
        //    using (OnlineGameContext db = new OnlineGameContext())
        //    {
        //        db.Gamers.Add(gamer);
        //        db.SaveChanges();
        //    }
        //}



        //POST 2.
        //"void" will return 204 No Content.
        //It should return status code 201 Item Created.
        //If there is an exception, return status code 500 internal server error.
        //[FromBody] means the gamer data comes from the client request body.
        public async Task<HttpResponseMessage> Post([FromBody] Gamer gamer)
        {
            try
            {
                using (OnlineGameContext db = new OnlineGameContext())
                {
                    db.Gamers.Add(gamer);
                    await db.SaveChangesAsync();

                    //Create a HttpResponseMessage with status code 201 Item Created.
                    //Pass the gamer into 2nd parameter as the created value.
                    HttpResponseMessage message =
                        Request.CreateResponse(HttpStatusCode.Created, gamer);
                    //The Headers.Location should know the URI of the created item.
                    message.Headers.Location = new Uri(Request.RequestUri +
                        gamer.Id.ToString());

                    return message;
                }
            }
            catch (Exception ex)
            {
                //500 internal server error
                return Request.CreateErrorResponse(HttpStatusCode.BadRequest, ex);
            }
        }


        ////DELETE 1.
        ////"void" will return 204 No Content.
        ////It should return status code 200 OK when deleting the Item successfully.
        ////If the gamer id is not found, then return 404 Not found.
        ////If there is an exception, return status code 500 internal server error.
        //public void Delete(int id)
        //{
        //    using (OnlineGameContext db = new OnlineGameContext())
        //    {
        //        Gamer gamer = db.Gamers.FirstOrDefault(g => g.Id == id);
        //        if (gamer != null) db.Gamers.Remove(gamer);
        //        db.SaveChanges();
        //    }
        //}


        //DELETE 2.
        //"void" will return 204 No Content.
        //It should return status code 200 OK when deleting the Item successfully.
        //If the gamer id is not found, then return 404 Not found.
        //If there is an exception, return status code 500 internal server error.
        public async Task<HttpResponseMessage> Delete(int id)
        {
            try
            {
                using (OnlineGameContext db = new OnlineGameContext())
                {
                    Gamer entity = await db.Gamers.FirstOrDefaultAsync(g => g.Id == id);
                    if (entity == null)
                    {
                        return Request.CreateErrorResponse(HttpStatusCode.NotFound,
                            $"Gamer with Id = {id} not found to delete");
                    }
                    db.Gamers.Remove(entity);
                    await db.SaveChangesAsync();
                    return Request.CreateResponse(HttpStatusCode.OK);
                }
            }
            catch (Exception ex)
            {
                return Request.CreateErrorResponse(HttpStatusCode.BadRequest, ex);
            }
        }


        ////PUT 1.
        ////"void" will return 204 No Content.
        ////It should return status code 200 OK when delete the Item successfully.
        ////If the gamer by id is not found, then return 404 Not found.
        ////If there is an exception, return status code 500 internal server error.
        ////[FromBody] means the gamer data comes from the client request body.
        //public void Put(int id, [FromBody]Gamer gamer)
        //{
        //    using (OnlineGameContext db = new OnlineGameContext())
        //    {
        //        Gamer currentGamer = db.Gamers.FirstOrDefault(g => g.Id == id);
        //        if (currentGamer != null)
        //        {
        //            currentGamer.Name = gamer.Name;
        //            currentGamer.Gender = gamer.Gender;
        //            currentGamer.Score = gamer.Score;
        //            currentGamer.GameMoney = gamer.GameMoney;
        //        }
        //        db.SaveChanges();
        //    }
        //}


        //PUT 2.
        //"void" will return 204 No Content.
        //It should return status code 200 OK when delete the Item successfully.
        //If the gamer by id is not found, then return 404 Not found.
        //If there is an exception, return status code 500 internal server error.
        //[FromBody] means the gamer data comes from the client request body.
        public async Task<HttpResponseMessage> Put(int id, [FromBody]Gamer gamer)
        {
            try
            {
                using (OnlineGameContext db = new OnlineGameContext())
                {
                    Gamer currentGamer = await db.Gamers.FirstOrDefaultAsync(g => g.Id == id);
                    if (currentGamer == null)
                    {
                        return Request.CreateErrorResponse(HttpStatusCode.NotFound,
                            $"Gamer with Id {id} not found to update");
                    }
                    currentGamer.Name = gamer.Name;
                    currentGamer.Gender = gamer.Gender;
                    currentGamer.Score = gamer.Score;
                    currentGamer.GameMoney = gamer.GameMoney;
                    await db.SaveChangesAsync();
                    return Request.CreateResponse(HttpStatusCode.OK, currentGamer);
                }
            }
            catch (Exception ex)
            {
                return Request.CreateErrorResponse(HttpStatusCode.BadRequest, ex);
            }
        }
    }
}
