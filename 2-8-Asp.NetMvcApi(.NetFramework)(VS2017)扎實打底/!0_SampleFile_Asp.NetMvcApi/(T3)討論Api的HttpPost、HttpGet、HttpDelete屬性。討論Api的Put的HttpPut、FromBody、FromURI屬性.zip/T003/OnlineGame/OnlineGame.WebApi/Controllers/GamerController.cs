﻿using System;
using System.Collections.Generic;
using System.Data.Entity;
using System.Data.Entity.Infrastructure;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Threading.Tasks;
using System.Web.Http;
using System.Web.Http.Description;
using OnlineGame.Data;

namespace OnlineGame.WebApi.Controllers
{
    public class GamerController : ApiController
    {
        private OnlineGameContext _db = new OnlineGameContext();

        ////GET: api/Gamer
        //[HttpGet]
        //public IQueryable<Gamer> LoadGamers()
        ////public IQueryable<Gamer> GetGamers()
        //{
        //    return _db.Gamers;
        //}


        //GET: api/gamer?gender=female  --> Only Female Gamer
        //GET: api/gamer? gender = male-- > Only Male Gamer
        //GET: api/gamer --> All Gamers
        [HttpGet]
        public async Task<IHttpActionResult> LoadGamers(string gender = "")
        //public IQueryable<Gamer> GetGamers()
        {
            List<Gamer> gamers;
            switch (gender.ToLower())
            {
                case "male":
                    gamers = await _db.Gamers.Where(g => g.Gender.ToLower() == "male").ToListAsync();
                    break;
                case "female":
                    gamers = await _db.Gamers.Where(g => g.Gender.ToLower() == "female").ToListAsync();
                    break;
                default:
                    gamers = await _db.Gamers.ToListAsync();
                    break;
            }
            return Ok(gamers);   //200
        }

        // GET: api/Gamer/5
        [ResponseType(typeof(Gamer))]
        [HttpGet]
        public async Task<IHttpActionResult> LoadGamer(int id)
        //public async Task<IHttpActionResult> GetGamer(int id)
        {
            Gamer gamer = await _db.Gamers.FindAsync(id);
            if (gamer == null) return NotFound();  //404
            return Ok(gamer);   //200
        }


        // PUT: api/Gamer/5
        [ResponseType(typeof(void))]
        //public async Task<IHttpActionResult> PutGamer(int id, Gamer gamer)
        [HttpPut]
        //public async Task<IHttpActionResult> UpdateGamer(int id, Gamer gamer)
        public async Task<IHttpActionResult> UpdateGamer([FromUri]int id, [FromBody]Gamer gamer)    //By Default
        //public async Task<IHttpActionResult> UpdateGamer([FromBody]int id, [FromUri]Gamer gamer)
        {
            if (!ModelState.IsValid)
            {
                return BadRequest(ModelState);  //400
            }
            //if (id != gamer.Id)   return BadRequest();

            ////1.
            gamer.Id = id;
            _db.Entry(gamer).State = EntityState.Modified;  //update the gamer

            //2.
            //Gamer currentGamer = await _db.Gamers.FirstOrDefaultAsync(g => g.Id == id);
            //if (currentGamer == null) return NotFound();  //404
            //currentGamer.Name = gamer.Name;
            //currentGamer.Gender = gamer.Gender;
            //currentGamer.Score = gamer.Score;
            //currentGamer.GameMoney = gamer.GameMoney;

            try
            {
                await _db.SaveChangesAsync();
                return Ok();    //200
            }
            catch (DbUpdateConcurrencyException)
            {
                if (!GamerExists(id)) return NotFound();  //404
                throw;
            }
        }

        // POST: api/Gamer
        [ResponseType(typeof(Gamer))]
        [HttpPost]
        public async Task<IHttpActionResult> InsertGamer([FromBody]Gamer gamer)
        //public async Task<IHttpActionResult> PostGamer([FromBody]Gamer gamer)
        {
            if (!ModelState.IsValid) return BadRequest(ModelState); //400
            _db.Gamers.Add(gamer);
            await _db.SaveChangesAsync();


            //Return Created/201.
            //1.
            return CreatedAtRoute("DefaultApi", new { id = gamer.Id }, gamer);    //Created/201

            ////Return Created/201.
            ////2.
            ////If you want to return HttpResponseMessage()
            ////2.
            ////Create a HttpResponseMessage with status code 201 Item Created.
            ////Pass the gamer into 2nd parameter as the created value.
            //HttpResponseMessage message =
            //    Request.CreateResponse(HttpStatusCode.Created, gamer);
            ////The Headers.Location should know the URI of the created item.
            //message.Headers.Location = new Uri(Request.RequestUri +
            //    gamer.Id.ToString());
            //return message;   //Created/201

            ////Return OK/200.
            ////3.
            ////if you want to return OK/200 when item created.
            //return Created(new Uri(Request.RequestUri + gamer.Id.ToString()), gamer);    //OK/200
        }

        // DELETE: api/Gamer/5
        [ResponseType(typeof(Gamer))]
        //[HttpDelete]
        //public async Task<IHttpActionResult> RemoveGamer(Gamer gamer)
        public async Task<IHttpActionResult> DeleteGamer(int id)
        {
            Gamer gamer = await _db.Gamers.FindAsync(id);
            if (gamer == null) return NotFound();   //404
            _db.Gamers.Remove(gamer);
            await _db.SaveChangesAsync();
            return Ok(gamer);   //200
        }

        protected override void Dispose(bool disposing)
        {
            if (disposing) _db.Dispose();   //Dispose DBContext
            base.Dispose(disposing);
        }

        private bool GamerExists(int id)
        {
            return _db.Gamers.Count(e => e.Id == id) > 0;
        }
    }
}

/*
1.
1.1.
By default, the HTTP verb GET maps to a method that has the name Get() or "Get" prefix.
E.g. Get(), GetGamers, GetXXX()
If you want the HTTP verb GET maps to the method name without "Get" prefix.
You can use [HttpGet] attribute.
1.2.
[HttpGet] attribute maps HTTP verb GET.
[HttpPost] attribute maps HTTP verb POST.
[HttpPut] attribute maps HTTP verb PUT.
[HttpDelete] attribute maps HTTP verb DELETE. 

----------------------------
2.
Web Api default binding parameter convention
2.1.
By default, if the parameter is a simple type,
Web Api will try to get value from uri.
E.g. int, double, bool, ...etc.
2.2.
By default, if the parameter is a complex type,
Web Api will try to get value from the request body.
E.g. Gamer
-----------------
2.3.
//[HttpPut]
//public async Task<IHttpActionResult> UpdateGamer(int id, Gamer gamer)  
By Default, the Web Api will try to get id from uri, and gamer from request body as below code.
//[HttpPut]
//public async Task<IHttpActionResult> UpdateGamer([FromUri]int id, [FromBody]Gamer gamer) 
E.g.
A.
PUT
http://localhost:58302/api/Gamer/8
B.
Request Header
Host: localhost:58302
Content-Type: application/json
B.1.
Accept: application/json
means we request JSON format response.
B.2.
Content-Type: application/json
The client will post a data to the server, the data format is JSON
C.
Request Body
{
"Name":"NameEight XYZ222", 
"Gender":"Male",
"Score":450,
"GameMoney":1500
}
-----------------
2.4.
//[HttpPut]
//public async Task<IHttpActionResult> UpdateGamer([FromBody]int id, [FromUri]Gamer gamer)
[FromBody] will enfroce to get id from request body
[FromUri] will enforce to get gamer from uri
E.g.
A.
PUT
http://localhost:58302/api/Gamer?Name=NameEight%20XYZ333&Gender=Male&Score=450&GameMoney=1500
B.
Request Header
Host: localhost:58302
Content-Type: application/json
B.1.
Accept: application/json
means we request JSON format response.
B.2.
Content-Type: application/json
The client will post a data to the server, the data format is JSON
C.
Request Body
8

*/
