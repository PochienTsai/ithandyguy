-- T040_DynamicSQL_SQLInjection_SearchWebPage_AspNet ---------------------------------

/*
1.
--CREATE PROCEDURE spSearchGamer
--    @FirstName NVARCHAR(100) = NULL ,
--    @LastName NVARCHAR(100) = NULL ,
--    @Gender NVARCHAR(50) = NULL ,
--    @GameScoreGreaterThanOrEqual INT = NULL
--AS
--    BEGIN
--        SELECT  *
--        FROM    Gamer
--        WHERE   ( FirstName LIKE ( '%' + @FirstName + '%' )
--                  OR @FirstName IS NULL
--                )
--                AND ( @LastName LIKE ( '%' + @LastName + '%' )
--                      OR @LastName IS NULL
--                    )
--                AND ( Gender = @Gender
--                      OR @Gender IS NULL
--                    )
--                AND ( GameScore >= @GameScoreGreaterThanOrEqual
--                      OR @GameScoreGreaterThanOrEqual IS NULL
--                    );
--    END;
If we set the default value for the parameter,
that will make the parameter become optional.
Without the parameter default value,
the parameter will become compulsory.
Thus, in where clause we need to add the IS NULL for each parameter

---------------------------------------------
2.
2.0.
In Summary:
Building a dynamic sql queries by concatenating strings cause the vulnerability of SQL injection.
Using sp_executesql parameters is always the best dynamic sql queries.
2.1.
sp_executesql Syntax
--EXECUTE sp_executesql @statement, @params, ...user-defined parameters...
sp_executesql has 2 pre-defined parameters 
and any number of user-defined parameters.
2.1.1.
@statement
is the SQL statements to execute
2.1.2.
@params
is a optional pre-defined parameter
and it is used to declare parameters specified in @statement.
2.2.
E.g.
--DECLARE @sql1 NVARCHAR(1000)
--= 'SELECT * 
--FROM Gamer 
--WHERE FirstName LIKE ''%' + 'B' + '%'' AND ' + 'LastName LIKE ''%' + 'Y'
--    + '%''';
--EXECUTE sp_executesql @sql1;
Building a dynamic sql queries by concatenating strings 
is a bad dynamic sql queries and 
it cause the vulnerability of SQL injection.
2.3.
E.g.
--DECLARE @sq2 NVARCHAR(1000) 
--= 'SELECT * 
--FROM Gamer 
--WHERE FirstName LIKE ''%''+@FirstName+''%'' 
--AND LastName LIKE ''%''+@LastName+''%''';
--DECLARE @params NVARCHAR(1000) = '@FirstName NVARCHAR(100), @LastName NVARCHAR(100)';
--EXECUTE sp_executesql @sq2, @params, @FirstName = 'B', @LastName = 'Y';
Using sp_executesql parameters is always the best for dynamic sql queries.
*/


--=====================================================================
--T040_01_Create Sample Data
--=====================================================================

IF ( EXISTS ( SELECT    *
              FROM      INFORMATION_SCHEMA.TABLES
              WHERE     TABLE_NAME = 'Gamer' ) )
    BEGIN
        TRUNCATE TABLE dbo.Gamer;
        DROP TABLE Gamer;
    END;
GO -- Run the previous command and begins new batch
CREATE TABLE Gamer
(
  Id INT IDENTITY(1, 1)
         PRIMARY KEY ,
  FirstName NVARCHAR(50) ,
  LastName NVARCHAR(50) ,
  Gender NVARCHAR(50) ,
  GameScore INT
);
GO -- Run the previous command and begins new batch
INSERT  INTO Gamer
VALUES  ( 'AFirst01', 'XLast01', 'Female', 3500 );
INSERT  INTO Gamer
VALUES  ( 'AFirst02', 'YLast02', 'Female', 4000 );
INSERT  INTO Gamer
VALUES  ( 'BFirst03', 'YLast03', 'Male', 4600 );
INSERT  INTO Gamer
VALUES  ( 'BFirst04', 'YLast04', 'Male', 5400 );
INSERT  INTO Gamer
VALUES  ( 'BFirst05', 'ZLast05', 'Female', 2000 );
INSERT  INTO Gamer
VALUES  ( 'CFirst06', 'YLast06', 'Male', 4320 );
INSERT  INTO Gamer
VALUES  ( 'CFirst07', 'YLast07', 'Male', 4400 );
GO -- Run the previous command and begins new batch

SELECT  *
FROM    Gamer;
GO -- Run the previous command and begins new batch


--=====================================================================
--T040_02_stored procedure spSearchGamer
--=====================================================================

IF ( EXISTS ( SELECT    *
              FROM      INFORMATION_SCHEMA.ROUTINES
              WHERE     ROUTINE_TYPE = 'PROCEDURE'
                        AND LEFT(ROUTINE_NAME, 3) NOT IN ( 'sp_', 'xp_', 'ms_' )
                        AND SPECIFIC_NAME = 'spSearchGamer' ) )
    BEGIN
        DROP PROCEDURE spSearchGamer;
    END;
GO -- Run the previous command and begins new batch
CREATE PROCEDURE spSearchGamer
    @FirstName NVARCHAR(100) = NULL ,
    @LastName NVARCHAR(100) = NULL ,
    @Gender NVARCHAR(50) = NULL ,
    @GameScoreGreaterThanOrEqual INT = NULL
AS
    BEGIN

        SELECT  *
        FROM    Gamer
        WHERE   ( FirstName LIKE ( '%' + @FirstName + '%' )
                  OR @FirstName IS NULL
                )
                AND ( LastName LIKE ( '%' + @LastName + '%' )
                      OR @LastName IS NULL
                    )
                AND ( Gender = @Gender
                      OR @Gender IS NULL
                    )
                AND ( GameScore >= @GameScoreGreaterThanOrEqual
                      OR @GameScoreGreaterThanOrEqual IS NULL
                    );
    END;
GO -- Run the previous command and begins new batch

EXECUTE spSearchGamer;
EXECUTE spSearchGamer @Gender = 'Male';
EXECUTE spSearchGamer @Gender = 'Male', @LastName = 'Y';
EXECUTE spSearchGamer @Gender = 'Male', @FirstName = 'B', @LastName = 'Y';
EXECUTE spSearchGamer @Gender = 'Male', @FirstName = 'B', @LastName = 'Y',
    @GameScoreGreaterThanOrEqual = 5000;
GO -- Run the previous command and begins new batch
/*
1.
--@FirstName NVARCHAR(100) = NULL ,
...
--WHERE   ( FirstName LIKE ( '%' + @FirstName + '%' )
--    OR @FirstName IS NULL
--)
If we set the default value for the parameter,
that will make the parameter become optional.
Without the parameter default value,
the parameter will become compulsory.
Thus, in where clause we need to add the IS NULL for each parameter
2.
In this case, the stored procedure is easy to maintan,
because it only has 4 filters.
When it has more than 10 filters, 
it will contain a lof of AND, OR ... in the filters 
and this is too complex to maintain.
Thus, we need Dynamic SQL stored procedure, sp_executesql.
*/


--=====================================================================
--T040_03_Dynamic SQL stored procedure
--=====================================================================

--Dynamic SQL stored procedure
--EXECUTE sp_executesql @statement, @params, ...user-defined parameters...

--=====================================================================
--T040_03_01
SELECT  *
FROM    Gamer
WHERE   FirstName LIKE '%B%'
        AND LastName LIKE '%Y%';
GO -- Run the previous command and begins new batch

--=====================================================================
--T040_03_02
--Bad dynamic sql queries.
--Building a dynamic sql queries by concatenating strings cause the vulnerability of SQL injection.
DECLARE @sql1 NVARCHAR(1000)
= 'SELECT * 
FROM Gamer 
WHERE FirstName LIKE ''%' + 'B' + '%'' AND ' + 'LastName LIKE ''%' + 'Y'
    + '%''';
EXECUTE sp_executesql @sql1;
GO -- Run the previous command and begins new batch

--=====================================================================
--T040_03_03
--Good dynamic sql queries.
--Using sp_executesql parameters is always the best for dynamic sql queries.
DECLARE @sq2 NVARCHAR(1000) 
= 'SELECT * 
FROM Gamer 
WHERE FirstName LIKE ''%''+@FirstName+''%'' 
AND LastName LIKE ''%''+@LastName+''%''';
DECLARE @params NVARCHAR(1000) = '@FirstName NVARCHAR(100), @LastName NVARCHAR(100)';
EXECUTE sp_executesql @sq2, @params, @FirstName = 'B', @LastName = 'Y';
GO -- Run the previous command and begins new batch
/*
1.
1.0.
In Summary:
Building a dynamic sql queries by concatenating strings cause the vulnerability of SQL injection.
Using sp_executesql parameters is always the best dynamic sql queries.
1.1.
sp_executesql Syntax
--EXECUTE sp_executesql @statement, @params, ...user-defined parameters...
sp_executesql has 2 pre-defined parameters 
and any number of user-defined parameters.
1.1.1.
@statement
is the SQL statements to execute
1.1.2.
@params
is a optional pre-defined parameter
and it is used to declare parameters specified in @statement.
1.2.
E.g.
--DECLARE @sql1 NVARCHAR(1000)
--= 'SELECT * 
--FROM Gamer 
--WHERE FirstName LIKE ''%' + 'B' + '%'' AND ' + 'LastName LIKE ''%' + 'Y'
--    + '%''';
--EXECUTE sp_executesql @sql1;
Building a dynamic sql queries by concatenating strings 
is a bad dynamic sql queries and 
it cause the vulnerability of SQL injection.
1.3.
--DECLARE @sq2 NVARCHAR(1000) 
--= 'SELECT * 
--FROM Gamer 
--WHERE FirstName LIKE ''%''+@FirstName+''%'' 
--AND LastName LIKE ''%''+@LastName+''%''';
--DECLARE @params NVARCHAR(1000) = '@FirstName NVARCHAR(100), @LastName NVARCHAR(100)';
--EXECUTE sp_executesql @sq2, @params, @FirstName = 'B', @LastName = 'Y';
Using sp_executesql parameters is always the best for dynamic sql queries.
*/

--=====================================================================
--T040_04_Bad dynamic sql queries
--=====================================================================

--=====================================================================
--T040_04_01
--Drop Store Procedure if it exists then recreate.
IF ( EXISTS ( SELECT    *
              FROM      INFORMATION_SCHEMA.ROUTINES
              WHERE     ROUTINE_TYPE = 'PROCEDURE'
                        AND LEFT(ROUTINE_NAME, 3) NOT IN ( 'sp_', 'xp_', 'ms_' )
                        AND SPECIFIC_NAME = 'spSearchGamer2' ) )
    BEGIN
        DROP PROCEDURE spSearchGamer2;
    END;
GO -- Run the previous command and begins new batch
CREATE PROCEDURE spSearchGamer2
(
  @FirstName NVARCHAR(100) = NULL ,
  @LastName NVARCHAR(100) = NULL ,
  @Gender NVARCHAR(50) = NULL ,
  @GameScoreGreaterThanOrEqual INT = NULL
)
AS
    BEGIN
        DECLARE @sql NVARCHAR(MAX);
        SET @sql = 'SELECT * FROM Gamer WHERE 1 = 1';
        IF ( @FirstName IS NOT NULL )
            SET @sql = @sql + ' AND FirstName LIKE ''%' + @FirstName + '%''';
        IF ( @LastName IS NOT NULL )
            SET @sql = @sql + ' AND LastName LIKE ''%' + @LastName + '%''';
        IF ( @Gender IS NOT NULL )
            SET @sql = @sql + ' AND Gender=''' + @Gender + '''';
        IF ( @GameScoreGreaterThanOrEqual IS NOT NULL )
            SET @sql = @sql + ' AND GameScore>='''
                + CAST(@GameScoreGreaterThanOrEqual AS NVARCHAR(100)) + '''';
        EXECUTE sp_executesql @sql;
    END;
GO -- Run the previous command and begins new batch

--=====================================================================
--T040_04_02
--EXECUTE spSearchGamer2
EXECUTE spSearchGamer2;
EXECUTE spSearchGamer2 @Gender = 'Male';
EXECUTE spSearchGamer2 @Gender = 'Male', @LastName = 'Y';
EXECUTE spSearchGamer2 @Gender = 'Male', @FirstName = 'B', @LastName = 'Y';
EXECUTE spSearchGamer2 @Gender = 'Male', @FirstName = 'B', @LastName = 'Y',
    @GameScoreGreaterThanOrEqual = 5000;


--=====================================================================
--T040_05_Good dynamic sql queries
--=====================================================================

--=====================================================================
--T040_05_01
--Drop Store Procedure if it exists then recreate.
IF ( EXISTS ( SELECT    *
              FROM      INFORMATION_SCHEMA.ROUTINES
              WHERE     ROUTINE_TYPE = 'PROCEDURE'
                        AND LEFT(ROUTINE_NAME, 3) NOT IN ( 'sp_', 'xp_', 'ms_' )
                        AND SPECIFIC_NAME = 'spSearchGamer3' ) )
    BEGIN
        DROP PROCEDURE spSearchGamer3;
    END;
GO -- Run the previous command and begins new batch
CREATE PROCEDURE spSearchGamer3
    @FirstName NVARCHAR(100) = NULL ,
    @LastName NVARCHAR(100) = NULL ,
    @Gender NVARCHAR(50) = NULL ,
    @GameScoreGreaterThanOrEqual INT = NULL
AS
    BEGIN
        DECLARE @sqlParams NVARCHAR(MAX) = N'@FN NVARCHAR(100), @LN NVARCHAR(100), @Gen NVARCHAR(50), @Gsgtoe INT';
        DECLARE @sql NVARCHAR(MAX);
        SET @sql = 'SELECT * FROM Gamer WHERE 1 = 1';
        IF ( @FirstName IS NOT NULL )
            SET @sql = @sql + ' AND FirstName LIKE ''%''+@FN+''%''';
        IF ( @LastName IS NOT NULL )
            SET @sql = @sql + ' AND LastName LIKE ''%''+@LN+''%''';
        IF ( @Gender IS NOT NULL )
            SET @sql = @sql + ' AND Gender=@Gen';
        IF ( @GameScoreGreaterThanOrEqual IS NOT NULL )
            SET @sql = @sql + ' AND GameScore>=@Gsgtoe';
        EXECUTE sp_executesql @sql, @sqlParams, @FN = @FirstName,
            @LN = @LastName, @Gen = @Gender,
            @Gsgtoe = @GameScoreGreaterThanOrEqual;
    END;
GO -- Run the previous command and begins new batch

--=====================================================================
--T040_05_02
--EXECUTE spSearchGamer3
EXECUTE spSearchGamer3;
EXECUTE spSearchGamer3 @Gender = 'Male';
EXECUTE spSearchGamer3 @Gender = 'Male', @LastName = 'Y';
EXECUTE spSearchGamer3 @Gender = 'Male', @FirstName = 'B', @LastName = 'Y';
EXECUTE spSearchGamer3 @Gender = 'Male', @FirstName = 'B', @LastName = 'Y',
    @GameScoreGreaterThanOrEqual = 5000;
GO -- Run the previous command and begins new batch



--=====================================================================
--T040_06_SQL Injection
--=====================================================================

--=====================================================================
--T040_06_01
--Create Sample data
IF ( EXISTS ( SELECT    *
              FROM      INFORMATION_SCHEMA.TABLES
              WHERE     TABLE_NAME = 'Table1' ) )
    BEGIN
        TRUNCATE TABLE dbo.Table1;
        DROP TABLE Table1;
    END;
GO -- Run the previous command and begins new batch
CREATE TABLE Table1
(
  Id INT IDENTITY(1, 1)
         PRIMARY KEY ,
  [Name] NVARCHAR(50)
);
GO -- Run the previous command and begins new batch

--=====================================================================
--T040_06_02
EXECUTE sp_executesql N'SELECT * FROM Gamer WHERE 1 = 1 AND FirstName=@FirstName',
    N'@FirstName NVARCHAR(26)', @FirstName = N'AFirst01';
SELECT  *
FROM    Table1;
GO -- Run the previous command and begins new batch
/*
Display the FirstName=N'AFirst01'
*/

--=====================================================================
--T040_06_03
EXECUTE sp_executesql N'SELECT * FROM Gamer WHERE 1 = 1 AND FirstName=@FirstName',
    N'@FirstName NVARCHAR(26)', @FirstName = N'''; DROP TABLE dbo.Table1; --';
SELECT  *
FROM    Table1;
GO -- Run the previous command and begins new batch
/*
sp_executesql with parameters is parameterised queries.
Thus, it prevent SQL Injection
*/

--=====================================================================
--T040_06_04
DECLARE @sql2 NVARCHAR(1000) = N'SELECT * FROM Gamer WHERE 1 = 1 AND FirstName='''
    + '''; DROP TABLE dbo.Table1; --' + ', AND LastName=@LastName';
EXECUTE sp_executesql @sql2;
SELECT  *
FROM    Table1;
GO -- Run the previous command and begins new batch
/*
**SQL Injection
The Table1 will be dropped.
*/

--=====================================================================
--T040_06_05
--Create Sample data
IF ( EXISTS ( SELECT    *
              FROM      INFORMATION_SCHEMA.TABLES
              WHERE     TABLE_NAME = 'Table1' ) )
    BEGIN
        TRUNCATE TABLE dbo.Table1;
        DROP TABLE Table1;
    END;
GO -- Run the previous command and begins new batch
CREATE TABLE Table1
(
  Id INT IDENTITY(1, 1)
         PRIMARY KEY ,
  [Name] NVARCHAR(50)
);
GO -- Run the previous command and begins new batch

--=====================================================================
--T040_06_06
EXECUTE spSearchGamer2 @Gender = 'Male';
SELECT  *
FROM    Table1;
GO -- Run the previous command and begins new batch

--=====================================================================
--T040_06_07
EXECUTE spSearchGamer2 @Gender = N'''; DROP TABLE dbo.Table1; --';
SELECT  *
FROM    Table1;
GO -- Run the previous command and begins new batch
/*
**SQL Injection
The Table1 will be dropped.
*/

--=====================================================================
--T040_06_08
--Create Sample data
IF ( EXISTS ( SELECT    *
              FROM      INFORMATION_SCHEMA.TABLES
              WHERE     TABLE_NAME = 'Table1' ) )
    BEGIN
        TRUNCATE TABLE dbo.Table1;
        DROP TABLE Table1;
    END;
GO -- Run the previous command and begins new batch
CREATE TABLE Table1
(
  Id INT IDENTITY(1, 1)
         PRIMARY KEY ,
  [Name] NVARCHAR(50)
);
GO -- Run the previous command and begins new batch

--=====================================================================
--T040_06_09
--Bad dynamic sql queries.
--Building a dynamic sql queries by concatenating strings cause the vulnerability of SQL injection.
DECLARE @sql1 NVARCHAR(1000)
= 'SELECT * 
FROM Gamer 
WHERE FirstName LIKE ''%' + 'B' + '%'' AND ' + 'LastName LIKE ''%' + 'Y'
    + '%''';
EXECUTE sp_executesql @sql1;
GO -- Run the previous command and begins new batch
/*
Display the FirstName LIKE '%B%' AND LastName LIKE '%Y%'
*/

--=====================================================================
--T040_06_10
--Bad dynamic sql queries.
--Building a dynamic sql queries by concatenating strings cause the vulnerability of SQL injection.
DECLARE @sql1 NVARCHAR(1000)
= 'SELECT * 
FROM Gamer 
WHERE FirstName LIKE ''%' + N'''; DROP TABLE dbo.Table1; --' + '%'' AND ' + 'LastName LIKE ''%' + 'Y'
    + '%''';
EXECUTE sp_executesql @sql1;
SELECT  *
FROM    Table1;
GO -- Run the previous command and begins new batch
/*
**SQL Injection
The Table1 will be dropped.
*/

--=====================================================================
--T040_06_11
--Create Sample data
IF ( EXISTS ( SELECT    *
              FROM      INFORMATION_SCHEMA.TABLES
              WHERE     TABLE_NAME = 'Table1' ) )
    BEGIN
        TRUNCATE TABLE dbo.Table1;
        DROP TABLE Table1;
    END;
GO -- Run the previous command and begins new batch
CREATE TABLE Table1
(
  Id INT IDENTITY(1, 1)
         PRIMARY KEY ,
  [Name] NVARCHAR(50)
);
GO -- Run the previous command and begins new batch

--=====================================================================
--T040_06_12
--Good dynamic sql queries.
--Using sp_executesql parameters is always the best for dynamic sql queries.
DECLARE @sq2 NVARCHAR(1000) 
= 'SELECT * 
FROM Gamer 
WHERE FirstName LIKE ''%''+@FirstName+''%'' 
AND LastName LIKE ''%''+@LastName+''%''';
DECLARE @params NVARCHAR(1000) = '@FirstName NVARCHAR(100), @LastName NVARCHAR(100)';
EXECUTE sp_executesql @sq2, @params, @FirstName = 'B', @LastName = 'Y';
GO -- Run the previous command and begins new batch
/*
Display the FirstName LIKE '%B%' AND LastName LIKE '%Y%'
*/

--=====================================================================
--T040_06_13
--Good dynamic sql queries.
--Using sp_executesql parameters is always the best for dynamic sql queries.
DECLARE @sq2 NVARCHAR(1000) 
= 'SELECT * 
FROM Gamer 
WHERE FirstName LIKE ''%''+@FirstName+''%'' 
AND LastName LIKE ''%''+@LastName+''%''';
DECLARE @params NVARCHAR(1000) = '@FirstName NVARCHAR(100), @LastName NVARCHAR(100)';
EXECUTE sp_executesql @sq2, @params, @FirstName =  N'''; DROP TABLE dbo.Table1; --', @LastName = 'Y';
SELECT  *
FROM    Table1;
GO -- Run the previous command and begins new batch
/*
**Prevent SQL Injection
The Table1 will NOT be dropped.
*/

--=====================================================================
--T040_06_14
EXECUTE spSearchGamer3 @Gender = 'Male';
EXECUTE spSearchGamer3 @Gender = 'Male', @FirstName = 'B', @LastName = 'Y',
    @GameScoreGreaterThanOrEqual = 5000;
SELECT  *
FROM    Table1;
GO -- Run the previous command and begins new batch

--=====================================================================
--T040_06_15
EXECUTE spSearchGamer3 @Gender = N'''; DROP TABLE dbo.Table1; --';
SELECT  *
FROM    Table1;
EXECUTE spSearchGamer3 @Gender = 'Male', @FirstName = N'''; DROP TABLE dbo.Table1; --', @LastName = 'Y',
    @GameScoreGreaterThanOrEqual = 5000;
SELECT  *
FROM    Table1;
GO -- Run the previous command and begins new batch
/*
**Prevent SQL Injection
The Table1 will NOT be dropped.
*/

--=====================================================================
--T040_07_Clean up
--=====================================================================

IF ( EXISTS ( SELECT    *
              FROM      INFORMATION_SCHEMA.TABLES
              WHERE     TABLE_NAME = 'Gamer' ) )
    BEGIN
        TRUNCATE TABLE dbo.Gamer;
        DROP TABLE Gamer;
    END;
GO -- Run the previous command and begins new batch
IF ( EXISTS ( SELECT    *
              FROM      INFORMATION_SCHEMA.TABLES
              WHERE     TABLE_NAME = 'Table1' ) )
    BEGIN
        TRUNCATE TABLE dbo.Table1;
        DROP TABLE Table1;
    END;
GO -- Run the previous command and begins new batch
------------------------------------------------------------------
IF ( EXISTS ( SELECT    *
              FROM      INFORMATION_SCHEMA.ROUTINES
              WHERE     ROUTINE_TYPE = 'PROCEDURE'
                        AND LEFT(ROUTINE_NAME, 3) NOT IN ( 'sp_', 'xp_', 'ms_' )
                        AND SPECIFIC_NAME = 'spSearchGamer' ) )
    BEGIN
        DROP PROCEDURE spSearchGamer;
    END;
GO -- Run the previous command and begins new batch
IF ( EXISTS ( SELECT    *
              FROM      INFORMATION_SCHEMA.ROUTINES
              WHERE     ROUTINE_TYPE = 'PROCEDURE'
                        AND LEFT(ROUTINE_NAME, 3) NOT IN ( 'sp_', 'xp_', 'ms_' )
                        AND SPECIFIC_NAME = 'spSearchGamer2' ) )
    BEGIN
        DROP PROCEDURE spSearchGamer2;
    END;
GO -- Run the previous command and begins new batch
IF ( EXISTS ( SELECT    *
              FROM      INFORMATION_SCHEMA.ROUTINES
              WHERE     ROUTINE_TYPE = 'PROCEDURE'
                        AND LEFT(ROUTINE_NAME, 3) NOT IN ( 'sp_', 'xp_', 'ms_' )
                        AND SPECIFIC_NAME = 'spSearchGamer3' ) )
    BEGIN
        DROP PROCEDURE spSearchGamer3;
    END;
GO -- Run the previous command and begins new batch


