-- T031_Stored Procedure with TableValueType Parameter in AspNet -------------------------

/*
1.
Create Table Value Type
1.1.
Reference:
https://sqltimes.wordpress.com/2014/05/10/sql-server-how-to-check-if-a-user-define-table-type-exists-using-query-tsql/
Check if table value type exists
1.2.
Syntax
--CREATE TYPE TableName AS TABLE
--(
--	Columns...
--);
*/


--===============================================================
--T031_01_Stored Procedure with TableValueType Parameter
--===============================================================

--===============================================================
--T031_01_01
--Sample code to create a Table

--If Table exists then DROP it
IF ( EXISTS ( SELECT    *
              FROM      INFORMATION_SCHEMA.TABLES
              WHERE     TABLE_NAME = 'PersonA' ) )
    BEGIN
        TRUNCATE TABLE dbo.PersonA;
        DROP TABLE PersonA;
    END;
GO -- Run the previous command and begins new batch
CREATE TABLE PersonA
    (
      Id INT PRIMARY KEY ,
      [Name] NVARCHAR(100) ,
      Gender NVARCHAR(10)
    );
GO -- Run the previous command and begins new batch

--===============================================================
--T031_01_02
--Table Value Parameter

-----------------------------------------------------------------
--T031_01_02_01
--Create Table Type and stored procedure

--If store procedure exist
IF ( EXISTS ( SELECT    *
              FROM      INFORMATION_SCHEMA.ROUTINES
              WHERE     ROUTINE_TYPE = 'PROCEDURE'
                        AND LEFT(ROUTINE_NAME, 3) NOT IN ( 'sp_', 'xp_', 'ms_' )
                        AND SPECIFIC_NAME = 'spInsertPersonA' ) )
    BEGIN
        DROP PROCEDURE spInsertPersonA;
    END;
GO -- Run the previous command and begins new batch
--Drop Table Type if exists
IF EXISTS ( SELECT  *
            FROM    sys.types
            WHERE   is_table_type = 1
                    AND name = 'PersonType' )
    BEGIN
        DROP TYPE PersonType;
    END;
GO -- Run the previous command and begins new batch
CREATE TYPE PersonType AS TABLE
(
Id INT PRIMARY KEY,
[Name] NVARCHAR(100),
Gender NVARCHAR(10)
);
GO -- Run the previous command and begins new batch
--Pass the Table Type as parameter to Store procedure
CREATE PROCEDURE spInsertPersonA
    @PersonTableType PersonType READONLY
AS
    BEGIN
        INSERT  INTO PersonA
                SELECT  *
                FROM    @PersonTableType;
    END;
GO -- Run the previous command and begins new batch
/*
1.
Create Table Value Type
1.1.
Reference:
https://sqltimes.wordpress.com/2014/05/10/sql-server-how-to-check-if-a-user-define-table-type-exists-using-query-tsql/
Check if table value type exists
1.2.
Syntax
--CREATE TYPE TableName AS TABLE
--(
--	Columns...
--);
*/

-----------------------------------------------------------------
--T031_01_02_02
--Declare a variable as Table Type
--Insert some data to Table Type
--Pass Table type as parameter to store procedure
DECLARE @PersonTableType2 PersonType;
INSERT  INTO @PersonTableType2
VALUES  ( 1, 'Name01', 'Male' );
INSERT  INTO @PersonTableType2
VALUES  ( 2, 'Name02', 'Female' );
INSERT  INTO @PersonTableType2
VALUES  ( 3, 'Name03', 'Female' );
INSERT  INTO @PersonTableType2
VALUES  ( 4, 'Name04', 'Male' );
INSERT  INTO @PersonTableType2
VALUES  ( 5, 'Name05', 'Male' );

EXECUTE spInsertPersonA @PersonTableType2;
GO -- Run the previous command and begins new batch

SELECT  *
FROM    PersonA;
GO -- Run the previous command and begins new batch

--===============================================================
--T031_01_03
--Clean up

--Drop Table if it exists
IF ( EXISTS ( SELECT    *
              FROM      INFORMATION_SCHEMA.TABLES
              WHERE     TABLE_NAME = 'PersonA' ) )
    BEGIN
        TRUNCATE TABLE dbo.PersonA;
        DROP TABLE PersonA;
    END;
GO -- Run the previous command and begins new batch

--Drop Stored Procedure if it exists
IF ( EXISTS ( SELECT    *
              FROM      INFORMATION_SCHEMA.ROUTINES
              WHERE     ROUTINE_TYPE = 'PROCEDURE'
                        AND LEFT(ROUTINE_NAME, 3) NOT IN ( 'sp_', 'xp_', 'ms_' )
                        AND SPECIFIC_NAME = 'spInsertPersonA' ) )
    BEGIN
        DROP PROCEDURE spInsertPersonA;
    END;
GO -- Run the previous command and begins new batch

--Drop Table Type if exists
IF EXISTS ( SELECT  *
            FROM    sys.types
            WHERE   is_table_type = 1
                    AND name = 'PersonType' )
    BEGIN
        DROP TYPE PersonType;
    END;
GO -- Run the previous command and begins new batch




--===============================================================
--T031_02_Stored Procedure with TableValueType Parameter in AspNet
--===============================================================

--===============================================================
--T031_02_01
--Recreate a Table

IF ( EXISTS ( SELECT    *
              FROM      INFORMATION_SCHEMA.TABLES
              WHERE     TABLE_NAME = 'PersonA' ) )
    BEGIN
        TRUNCATE TABLE dbo.PersonA;
        DROP TABLE PersonA;
    END;
GO -- Run the previous command and begins new batch
CREATE TABLE PersonA
    (
      Id INT IDENTITY(1, 1)
             PRIMARY KEY ,
      [Name] NVARCHAR(100) ,
      Gender NVARCHAR(10)
    );
GO -- Run the previous command and begins new batch



--===============================================================
--T031_02_02
--Stored Procedure with Table Type Parameter

-----------------------------------------------------------------
--T031_02_02_01
--ReCreate Table Type and Stored Procedure with Table Type Parameter

--Drop Stored Procedure if it exists
IF ( EXISTS ( SELECT    *
              FROM      INFORMATION_SCHEMA.ROUTINES
              WHERE     ROUTINE_TYPE = 'PROCEDURE'
                        AND LEFT(ROUTINE_NAME, 3) NOT IN ( 'sp_', 'xp_', 'ms_' )
                        AND SPECIFIC_NAME = 'spInsertPersonA' ) )
    BEGIN
        DROP PROCEDURE spInsertPersonA;
    END;
GO -- Run the previous command and begins new batch
--Drop Table Type Procedure if it exists
IF EXISTS ( SELECT  *
            FROM    sys.types
            WHERE   is_table_type = 1
                    AND name = 'PersonType' )
    BEGIN
        DROP TYPE PersonType;
    END;
GO -- Run the previous command and begins new batch
--Create Table Type
CREATE TYPE PersonType AS TABLE
(
[Name] NVARCHAR(100),
Gender NVARCHAR(10)
);
GO -- Run the previous command and begins new batch
--Pass the Table Type as parameter to Store procedure
CREATE PROCEDURE spInsertPersonA
    @PersonTableType PersonType READONLY
AS
    BEGIN
        INSERT  INTO PersonA
                SELECT  *
                FROM    @PersonTableType;
    END;
GO -- Run the previous command and begins new batch

/*
1.
Create Table Value Type
1.1.
Reference:
https://sqltimes.wordpress.com/2014/05/10/sql-server-how-to-check-if-a-user-define-table-type-exists-using-query-tsql/
Check if table value type exists
1.2.
Syntax
--CREATE TYPE TableName AS TABLE
--(
--	Columns...
--);
*/

-----------------------------------------------------------------
--T031_02_02_02
--Use Stored Procedure with Table Type Parameter

--Declare a variable as Table Type
--Insert some data to Table Type
--Pass Table type as parameter to store procedure
DECLARE @PersonTableType2 PersonType;
INSERT  INTO @PersonTableType2
VALUES  ( 'Name01', 'Male' );
INSERT  INTO @PersonTableType2
VALUES  ( 'Name02', 'Female' );
INSERT  INTO @PersonTableType2
VALUES  ( 'Name03', 'Female' );
INSERT  INTO @PersonTableType2
VALUES  ( 'Name04', 'Male' );
INSERT  INTO @PersonTableType2
VALUES  ( 'Name05', 'Male' );

EXECUTE spInsertPersonA @PersonTableType2;
GO -- Run the previous command and begins new batch

SELECT  *
FROM    PersonA;
GO -- Run the previous command and begins new batch



--===============================================================
--T031_02_03
--spSearchPersonA

-----------------------------------------------------------------
--T031_02_03_01
--Create spSearchPersonA

IF ( EXISTS ( SELECT    *
              FROM      INFORMATION_SCHEMA.ROUTINES
              WHERE     ROUTINE_TYPE = 'PROCEDURE'
                        AND Left(ROUTINE_NAME, 3) NOT IN ( 'sp_', 'xp_', 'ms_' )
                        AND SPECIFIC_NAME = 'spSearchPersonA' ) )
    BEGIN
        DROP PROCEDURE spSearchPersonA;
    END;
GO -- Run the previous command and begins new batch
CREATE PROC spSearchPersonA
    (
      @NameLike NVARCHAR(100) = NULL ,
      @Gender NVARCHAR(10) = NULL
	)
AS
    BEGIN
        SELECT  *
        FROM    PersonA p
        WHERE   ( p.[Name] LIKE ('%' +  @NameLike + '%')
                  OR @NameLike IS NULL
                )
                AND 
				( p.Gender = @Gender
                  OR @Gender IS NULL
                )
    END;
GO -- Run the previous command and begins new batch

-----------------------------------------------------------------
--T031_02_03_02
--Test spSearchPersonA
EXECUTE spSearchPersonA 
EXECUTE spSearchPersonA @Gender='Male'
EXECUTE spSearchPersonA @NameLike='04', @Gender='Male'


--===============================================================
--T031_03_Clean up
--===============================================================

--Drop Table if it exists.
IF ( EXISTS ( SELECT    *
              FROM      INFORMATION_SCHEMA.TABLES
              WHERE     TABLE_NAME = 'PersonA' ) )
    BEGIN
        TRUNCATE TABLE dbo.PersonA;
        DROP TABLE PersonA;
    END;
GO -- Run the previous command and begins new batch
---------------------------------------------
--Drop Stored Procedure if it exists.
IF ( EXISTS ( SELECT    *
              FROM      INFORMATION_SCHEMA.ROUTINES
              WHERE     ROUTINE_TYPE = 'PROCEDURE'
                        AND LEFT(ROUTINE_NAME, 3) NOT IN ( 'sp_', 'xp_', 'ms_' )
                        AND SPECIFIC_NAME = 'spInsertPersonA' ) )
    BEGIN
        DROP PROCEDURE spInsertPersonA;
    END;
GO -- Run the previous command and begins new batch
---------------------------------------------
--Drop Table Type if it exists.
IF EXISTS ( SELECT  *
            FROM    sys.types
            WHERE   is_table_type = 1
                    AND name = 'PersonType' )
    BEGIN
        DROP TYPE PersonType;
    END;
GO -- Run the previous command and begins new batch
---------------------------------------------
--Drop Stored Procedure if it exists.
IF ( EXISTS ( SELECT    *
              FROM      INFORMATION_SCHEMA.ROUTINES
              WHERE     ROUTINE_TYPE = 'PROCEDURE'
                        AND Left(ROUTINE_NAME, 3) NOT IN ( 'sp_', 'xp_', 'ms_' )
                        AND SPECIFIC_NAME = 'spSearchPersonA' ) )
    BEGIN
        DROP PROCEDURE spSearchPersonA;
    END;
GO -- Run the previous command and begins new batch


