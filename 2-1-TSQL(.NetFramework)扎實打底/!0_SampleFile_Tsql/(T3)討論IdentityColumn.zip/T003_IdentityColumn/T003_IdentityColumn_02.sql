-- T003_IdentityColumn -----------------------------------------------------


--===================================================================================
--T003_03

/*
What to learn
- SCOPE_IDENTITY();
- @@IDENTITY;
- IDENT_CURRENT('TableA');
- IDENT_CURRENT('TableB');
*/

----------------------------------------------------------------------------------
--T003_03_01

-- Ch08_02_01
SELECT  SCOPE_IDENTITY();
--NULL
SELECT  @@IDENTITY;
--NULL
SELECT  IDENT_CURRENT('TableA');
--3
SELECT  IDENT_CURRENT('TableB');
--1
GO -- Run the prvious command and begins new batch
/*
1.
1.1.
In brief:
* SCOPE_IDENTITY()
returns the last identity value that is created in the same session and in the same scope.
* @@IDENTITY
returns the last identity value that is created in the same session and across any scope.
@@IDENTITY stored the Identity Column Value from last affected scope in the same session.
* IDENT_CURRENT('tblPerson')
returns the last identity value that is created for a specific table across any session and any scope.
1.2.
In the same Seccion (Connection):
Every comand in current sql query edit window is 
ONE CONNECTION to SQL server.
ONE CONNECTION means in the ONE session in this case.
1.3.
In the same Scope:
Same Scope means every sql command in ONE Stored procedure or ONE function, or ONE trigger.

2.
SCOPE_IDENTITY() return NULL
@@IDENTITY return NULL
IDENT_CURRENT('TableA') return 3
IDENT_CURRENT('TableB') return 1
*/


----------------------------------------------------------------------------------
--T003_03_02
SELECT  SCOPE_IDENTITY();
--NULL
SELECT  @@IDENTITY;
--NULL
SELECT  IDENT_CURRENT('TableA');
--3
SELECT  IDENT_CURRENT('TableB');
--1

SELECT  *
FROM    TableA;
SELECT  *
FROM    TableB;
--Table A have (ID=1,Value='x1'), (ID=2,Value='x2'), (ID=3,Value='x3')
--Table B have (ID=3,Value='x3').

INSERT  INTO TableB
VALUES  ( 'x2' );

SELECT  SCOPE_IDENTITY();
--2
SELECT  @@IDENTITY;
--2
SELECT  IDENT_CURRENT('TableA');
--3
SELECT  IDENT_CURRENT('TableB');
--2

SELECT  *
FROM    TableA;
SELECT  *
FROM    TableB;
--Table A have (ID=1,Value='x1'), (ID=2,Value='x2'), (ID=3,Value='x3')
--Table B have (ID=3,Value='x3'), (ID=2,Value='x2')
GO -- Run the prvious command and begins new batch
/*
1.
Originally, 
Table A will have (ID=1,Value='x1'), (ID=2,Value='x2'), (ID=3,Value='x3')
Table B will have (ID=1,Value='x3')
SCOPE_IDENTITY()  return NULL
@@IDENTITY  return NULL
IDENT_CURRENT('TableA') return 3
IDENT_CURRENT('TableB')  return 1

2.
After insert (ID=2,Value='x2') into TableB
Table A will have (ID=1,Value='x1'), (ID=2,Value='x2'), (ID=3,Value='x3')
Table B will have (ID=1,Value='x3'), (ID=2,Value='x2')
SCOPE_IDENTITY()  return 2
@@IDENTITY  return 2
IDENT_CURRENT('TableA') return 3
IDENT_CURRENT('TableB')  return 2

2.1.
SCOPE_IDENTITY()  return 2   
because this number is from that 
We have inserted 2 times to TableB
in the same session and in the same scope.
2.2.
@@IDENTITY  return 2
because this number is from that 
We have inserted 2 times to TableB
in the same session and in the same scope.
@@IDENTITY stored the Identity Column Value from last affected scope in the same session.
Same Scope means every sql command in ONE Stored procedure or ONE function, or ONE trigger.
Same session(CONNECTION) means every sql command in ONE sql query edit window.
2.3.
IDENT_CURRENT('TableA') return 3
IDENT_CURRENT('TableB')  return 2
Both return the last identity value
across any session and any scope.
This is the safest way to get the last identity column value.
*/


----------------------------------------------------------------------------------
--T003_03_03
SELECT  SCOPE_IDENTITY();
--2
SELECT  @@IDENTITY;
--2
SELECT  IDENT_CURRENT('TableA');
--3
SELECT  IDENT_CURRENT('TableB');
--2

SELECT  *
FROM    TableA;
SELECT  *
FROM    TableB;
--Table A have (ID=1,Value='x1'), (ID=2,Value='x2'), (ID=3,Value='x3')
--Table B have (ID=3,Value='x3'), (ID=2,Value='x2')

INSERT  INTO TableA
VALUES  ( 'x4' );

SELECT  SCOPE_IDENTITY();
--4
SELECT  @@IDENTITY;
--3
SELECT  IDENT_CURRENT('TableA');
--4
SELECT  IDENT_CURRENT('TableB');
--3

SELECT  *
FROM    TableA;
SELECT  *
FROM    TableB;
--Table A have (ID=1,Value='x1'), (ID=2,Value='x2'), (ID=3,Value='x3'), (ID=4,Value='x4')
--Table B have (ID=3,Value='x3'), (ID=2,Value='x2'), (ID=3,Value='x4')


/*
1.
Originally, 
--Table A have (ID=1,Value='x1'), (ID=2,Value='x2'), (ID=3,Value='x3')
--Table B have (ID=3,Value='x3'), (ID=2,Value='x2')
SCOPE_IDENTITY()  return 2
@@IDENTITY  return 2
IDENT_CURRENT('TableA') return 3
IDENT_CURRENT('TableB')  return 2

2.
After We insert (ID=4,Value='x4') into TableA
The TableA Trigger "tgForInsert" will insert (ID=3,Value='x4') into TableB
Thus,
Table A will have (ID=1,Value='x1'), (ID=2,Value='x2'), (ID=3,Value='x3'), (ID=4,Value='x4')
Table B will have (ID=1,Value='x3'), (ID=2,Value='x2'), (ID=3,Value='x4')
SCOPE_IDENTITY()  return 4
@@IDENTITY  return 3
IDENT_CURRENT('TableA') return 4
IDENT_CURRENT('TableB')  return 3

2.1.
SCOPE_IDENTITY()  return 4
because this number is from that 
We have inserted 4 times to TableA
in the same session and in the same scope.
2.2.
@@IDENTITY  return 3
because this number is from that 
We have inserted 3 times to TableB
in the same session and in the same scope.
@@IDENTITY stored the Identity Column Value from last affected scope in the same session.
Same Scope means every sql command in ONE Stored procedure or ONE function, or ONE trigger.
Same session(CONNECTION) means every sql command in ONE sql query edit window.
2.3.
IDENT_CURRENT('TableA') return 4
IDENT_CURRENT('TableB')  return 3
Both return the last identity value
across any session and any scope.
This is the safest way to get the last identity column value.
*/



--===================================================================================
--T003_04
--Clean up
IF EXISTS ( SELECT  *
            FROM    sys.objects
            WHERE   [name] = N'tgForInsert'
                    AND [type] = 'TR' )
    BEGIN
        DROP TRIGGER tgForInsert;
    END;
GO -- Run the previous command and begins new batch
IF ( EXISTS ( SELECT    *
              FROM      INFORMATION_SCHEMA.TABLES
              WHERE     TABLE_NAME = 'TableA' ) )
    BEGIN
        TRUNCATE TABLE TableA;
        DROP TABLE TableA;
    END;
GO -- Run the previous command and begins new batch
IF ( EXISTS ( SELECT    *
              FROM      INFORMATION_SCHEMA.TABLES
              WHERE     TABLE_NAME = 'TableB' ) )
    BEGIN
        TRUNCATE TABLE TableB;
        DROP TABLE TableB;
    END;
GO -- Run the previous command and begins new batch
