--1 ----------------------------------------------------------
--Drop Table if it exists.
--IF OBJECT_ID('Gamer') IS NOT NULL
IF ( EXISTS ( SELECT    *
              FROM      INFORMATION_SCHEMA.TABLES
              WHERE     TABLE_NAME = 'Gamer' ) )
    BEGIN
        TRUNCATE TABLE Gamer;
        DROP TABLE Gamer;
    END;
GO -- Run the previous command and begins new batch
CREATE TABLE Gamer
    (
      Id INT PRIMARY KEY
             IDENTITY ,
      Name NVARCHAR(50) ,
      Gender NVARCHAR(50) ,
      Score INT ,
	  Type NVARCHAR(50) ,
	  CombatPower INT,
	  MagicPower INT
    );
GO -- Run the previous command and begins new batch


--2 ----------------------------------------------------------
INSERT  INTO Gamer
VALUES  ( 'Name1 ABC', 'Male', 5000, 'Warrior', 500, NULL );
INSERT  INTO Gamer
VALUES  ( 'Name2 ABCDE', 'Female', 4500, 'Warrior', 350, NULL );
INSERT  INTO Gamer
VALUES  ( 'Name3 EFGH', 'Male', 6500, 'Magician', NULL, 600 );
INSERT  INTO Gamer
VALUES  ( 'Name4 HIJKLMN', 'Female', 45000, 'Magician', NULL, 650 );
INSERT  INTO Gamer
VALUES  ( 'Name5 NOP', 'Male', 3000, 'Magician', NULL, 700 );
INSERT  INTO Gamer
VALUES  ( 'Name6 PQRSTUVW', 'Male', 4000, 'Warrior', 450, NULL );
INSERT  INTO Gamer
VALUES  ( 'Name7 XYZ', 'Male', 4500, 'Warrior', 550, NULL );
GO -- Run the previous command and begins new batch
