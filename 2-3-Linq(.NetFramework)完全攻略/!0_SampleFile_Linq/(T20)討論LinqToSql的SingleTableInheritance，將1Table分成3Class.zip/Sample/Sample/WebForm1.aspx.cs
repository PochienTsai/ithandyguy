﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.Linq;
using System.Linq;

namespace Sample
{
    public partial class WebForm1 : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {

        }

        private DataTable ConvertGamersForDisplay(List<Gamer> gamers)
        {
            DataTable dt = new DataTable();
            dt.Columns.Add("Id");
            dt.Columns.Add("Name");
            dt.Columns.Add("Gender");
            dt.Columns.Add("Score");
            dt.Columns.Add("Type");
            dt.Columns.Add("CombatPower");
            dt.Columns.Add("MagicPower");

            foreach (Gamer gamer in gamers)
            {
                DataRow dr = dt.NewRow();
                dr["Id"] = gamer.Id;
                dr["Name"] = gamer.Name;
                dr["Gender"] = gamer.Gender;
                dr["Score"] = gamer.Score;

                //Because Gamer is an abstract class,
                //No one can create Gamer instance.
                //So gamer is actually an object of "Warrior" or "Magician"
                //If gamer is Warrior, 
                //then add [CombatPower] column to DataRow
                //and set dr["Type"] = "Warrior".
                //If gamer is Magician, 
                //then add [MagicPower] column to DataRow
                //and set dr["Type"] = "Magician".
                Warrior warrior = gamer as Warrior;
                if (warrior != null)
                {
                    dr["CombatPower"] = warrior.CombatPower;
                    dr["Type"] = "Warrior";
                }

                Magician magician = gamer as Magician;
                if (magician != null)
                {
                    dr["MagicPower"] = magician.MagicPower;
                    dr["Type"] = "Magician";
                }
                dt.Rows.Add(dr);
            }
            return dt;
        }

        private void GetAllGamers()
        {
            using (SampleDataContext dbContext = new SampleDataContext())
            {
                // Write the generated sql query to the webform
                dbContext.Log = Response.Output;

                Table<Gamer> gamers = dbContext.Gamers;
                //GridView1.DataSource =
                //    dbContext.Gamers.ToList();
                GridView1.DataSource =
                    ConvertGamersForDisplay(dbContext.Gamers.ToList());
                GridView1.DataBind();
            }
        }

        protected void btnGetAllGamers_Click(object sender, EventArgs e)
        {
            GetAllGamers();
        }

        protected void btnGetAllWarriors_Click(object sender, EventArgs e)
        {
            using (SampleDataContext dbContext = new SampleDataContext())
            {
                // Write the generated sql query to the webform
                dbContext.Log = Response.Output;

                IQueryable<Warrior> warriors = dbContext.Gamers.OfType<Warrior>();
                GridView1.DataSource =
                        dbContext.Gamers.OfType<Warrior>().ToList();
                GridView1.DataBind();
            }
        }

        protected void btnGetAllMagicians_Click(object sender, EventArgs e)
        {
            using (SampleDataContext dbContext = new SampleDataContext())
            {
                // Write the generated sql query to the webform
                dbContext.Log = Response.Output;

                IQueryable<Magician> magicians = dbContext.Gamers.OfType<Magician>();
                GridView1.DataSource =
                        dbContext.Gamers.OfType<Magician>().ToList();
                GridView1.DataBind();
            }
        }

        protected void btnAddGamers_Click(object sender, EventArgs e)
        {
            using (SampleDataContext dbContext = new SampleDataContext())
            {
                Warrior warrior = new Warrior
                {
                    Name = "warriorName",
                    Gender = "Female",
                    Score = 3000,
                    CombatPower = 100
                };

                Magician magician = new Magician
                {
                    Name = "magicianName",
                    Gender = "Female",
                    Score = 3000,
                    MagicPower = 101
                };

                dbContext.Gamers.InsertOnSubmit(warrior);
                dbContext.Gamers.InsertOnSubmit(magician);
                dbContext.SubmitChanges();
                GetAllGamers();
            }
        }
    }
}