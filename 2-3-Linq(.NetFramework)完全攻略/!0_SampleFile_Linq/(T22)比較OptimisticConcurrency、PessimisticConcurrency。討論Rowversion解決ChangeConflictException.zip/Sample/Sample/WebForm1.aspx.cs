﻿using System;
using System.Data.Linq;
using System.Linq;
using System.Threading;

namespace Sample
{
    public partial class WebForm1 : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            //if (!IsPostBack)  means first time to load this page.
            if (!IsPostBack)
            {
                getGamerData();
            }
        }

        private void getGamerData()
        {
            using (SampleDataContext dbContext = new SampleDataContext())
            {
                Gamer gamer = dbContext.Gamers.First(g => g.Id == 1);
                lblId.Text = gamer.Id.ToString();
                lblName.Text = gamer.Name;
                lblScore.Text = gamer.Score.ToString();
            }
        }

        //1. ====================================
        //KeepCurrentValues
        //Wait N for N millisecond, then update
        //dbContext.ChangeConflicts.ResolveAll(RefreshMode.KeepCurrentValues);
        protected void btnAdd1000KeepCurrentValues_Click(object sender, EventArgs e)
        {
            // 2.1.
            // KeepCurrentValues
            // E.g.
            // //dbContext.ChangeConflicts.ResolveAll(RefreshMode.KeepCurrentValues);
            // KeepCurrentValues means keep all the new values from the current user.
            // dbContextA is used by current user 
            // and tries to update the Column1.
            // In the mean time, dbContextB is used by other user 
            // and tries to update the Column1, and Column2.
            // The new value of Column1 from dbContextA will be saved into Database.
            // The old value of Column2 from dbContextA will be saved into Database.

            using (SampleDataContext dbContext = new SampleDataContext())
            {
                try
                {
                    ScoreAdd1000(dbContext);
                }
                catch (ChangeConflictException ex)
                {
                    dbContext.ChangeConflicts.ResolveAll(RefreshMode.KeepCurrentValues);

                    DisplayChangeConflict(dbContext);
                }
                catch (Exception ex)
                {
                    Console.WriteLine(ex);
                }
            }
        }

        private void DisplayChangeConflict(SampleDataContext dbContext)
        {

            // 3.
            // When ChangeConflictException happens,
            // we can access the following values. 
            // 3.1.
            // //memberChangeConflict.Member.Name
            // This will show you the property Name which contains change conflict data.
            // The property name is normally same as Column Name from database.
            // 3.2.
            // //memberChangeConflict.CurrentValue
            // The will show you the current value of the property which contains change conflict data.
            // This is the new value which updated from the current user.
            // 3.3.
            // //memberChangeConflict.OriginalValue
            // The will show you the original value of the property which contains change conflict data.
            // This is the old value which has not been updated from the current user yet.
            // 3.4.
            // //memberChangeConflict.DatabaseValue
            // The will show you the current value of the corresponding column in the database table.


            foreach (ObjectChangeConflict objectChangeConflict
                in dbContext.ChangeConflicts)
            {
                foreach (MemberChangeConflict memberChangeConflict
                    in objectChangeConflict.MemberConflicts)
                {
                    Response.Write($"memberChangeConflict.Member.Name=={memberChangeConflict.Member.Name}<br/>");
                    Response.Write($"memberChangeConflict.CurrentValue=={memberChangeConflict.CurrentValue}<br/>");
                    Response.Write($"memberChangeConflict.OriginalValue=={memberChangeConflict.OriginalValue}<br/>");
                    Response.Write($"memberChangeConflict.DatabaseValue=={memberChangeConflict.DatabaseValue}<br/>");
                }
            }
            dbContext.SubmitChanges();
            getGamerData();
        }

        private void ScoreAdd1000(SampleDataContext dbContext)
        {
            Gamer gamer = dbContext.Gamers.First(g => g.Id == 1);
            gamer.Score += 1000;
            Thread.Sleep(2000); // sleep for N millisecond.
            dbContext.SubmitChanges();

            getGamerData();
        }

        //2. ====================================
        //KeepChanges
        //Wait N for N millisecond, then update
        //dbContext.ChangeConflicts.ResolveAll(RefreshMode.KeepChanges);
        protected void btnAdd1000KeepChanges_Click(object sender, EventArgs e)
        {
            //2.2.
            // KeepChanges
            // E.g.
            // //dbContext.ChangeConflicts.ResolveAll(RefreshMode.KeepChanges);
            // KeepChanges means keep all the changes from all the users.
            // If any conflict, then keep the new values from the current user.
            // dbContextA is used by current user 
            // and tries to update the Column1.
            // In the mean time, dbContextB is used by other user 
            // and tries to update the Column1, and Column2.
            // The new value of Column1 from dbContextA will be saved into Database.
            // The new value of Column2 from dbContextB will be saved into Database.

            using (SampleDataContext dbContext = new SampleDataContext())
            {
                try
                {
                    ScoreAdd1000(dbContext);
                }
                catch (ChangeConflictException ex)
                {
                    dbContext.ChangeConflicts.ResolveAll(RefreshMode.KeepChanges);

                    DisplayChangeConflict(dbContext);
                }
                catch (Exception ex)
                {
                    Console.WriteLine(ex);
                }
            }
        }

        //3. ====================================
        //OverwriteCurrentValues
        //Wait N for N millisecond, then update
        //dbContext.ChangeConflicts.ResolveAll(RefreshMode.OverwriteCurrentValues);
        protected void btnAdd1000OverwriteCurrentValues_Click(object sender, EventArgs e)
        {
            //2.3.
            // OverwriteCurrentValues
            // E.g.
            // //dbContext.ChangeConflicts.ResolveAll(RefreshMode.OverwriteCurrentValues);
            // OverwriteCurrentValues means discard all the changes from the current user.
            // dbContextA is used by current user 
            // and tries to update the Column1.
            // In the mean time, dbContextB is used by other user 
            // and tries to update the Column1, and Column2.
            // The new value of Column1 from dbContextB will be saved into Database.
            // The new value of Column2 from dbContextB will be saved into Database.
            // Because OverwriteCurrentValues means discard all the changes from dbContextA.

            using (SampleDataContext dbContext = new SampleDataContext())
            {
                try
                {
                    ScoreAdd1000(dbContext);
                }
                catch (ChangeConflictException ex)
                {
                    dbContext.ChangeConflicts.ResolveAll(RefreshMode.OverwriteCurrentValues);

                    DisplayChangeConflict(dbContext);
                }
                catch (Exception ex)
                {
                    Console.WriteLine(ex);
                }
            }
        }


        // 4. Update straight away. ====================================
        protected void btnDeduct500_Click(object sender, EventArgs e)
        {
            using (SampleDataContext dbContext = new SampleDataContext())
            {
                Gamer gamer = dbContext.Gamers.First(g => g.Id == 1);
                gamer.Name += "X";
                gamer.Score -= 500;
                dbContext.SubmitChanges();

                getGamerData();
            }
        }
    }
}