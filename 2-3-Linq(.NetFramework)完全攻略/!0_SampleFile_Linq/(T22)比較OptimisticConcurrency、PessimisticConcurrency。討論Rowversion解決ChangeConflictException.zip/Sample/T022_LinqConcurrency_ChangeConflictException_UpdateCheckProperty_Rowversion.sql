--1 ----------------------------------------------------------
--Drop Table if it exists.
--IF OBJECT_ID('Gamer') IS NOT NULL
IF ( EXISTS ( SELECT    *
              FROM      INFORMATION_SCHEMA.TABLES
              WHERE     TABLE_NAME = 'Gamer' ) )
    BEGIN
        TRUNCATE TABLE Gamer;
        DROP TABLE Gamer;
    END;
GO -- Run the previous command and begins new batch
CREATE TABLE Gamer
    (
      Id INT PRIMARY KEY
             IDENTITY ,
      Name NVARCHAR(50) ,
      Score INT ,
    );
GO -- Run the previous command and begins new batch


--2 ----------------------------------------------------------
INSERT  INTO Gamer
VALUES  ( 'Name1 ABC', 5000 );
GO -- Run the previous command and begins new batch
