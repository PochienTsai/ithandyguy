﻿using System;
using System.Linq;

namespace Sample
{
    public partial class WebForm1 : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            //GetData();
        }

        protected void btnGetMaleData_Click(object sender, EventArgs e)
        {
            using (SampleDataContext dbContext = new SampleDataContext())
            {
                // Write the generated sql query to the webform
                dbContext.Log = Response.Output;

                //// Write the generated sql query to the Console window
                //dbContext.Log = Console.Out;

                //dbContext.Log = Response.Output;  and   
                //dbContext.Log = Console.Out;
                //You may only choose one to use.

                IOrderedQueryable<Gamer> gamerQueryable = from gamer in dbContext.Gamers
                    where gamer.Gender == "Male"
                    orderby gamer.Score descending
                    select gamer;

                GridView1.DataSource =
                    gamerQueryable;

                Response.Write($"<br/>gamerQueryable.ToString()<br/>{gamerQueryable.ToString()}<br/><br/>");
                Response.Write($"<br/>dbContext.GetCommand(gamerQueryable).CommandText<br/>{dbContext.GetCommand(gamerQueryable).CommandText}<br/><br/>");
                Response.Write($"<br/>dbContext.GetCommand(gamerQueryable).CommandType<br/>{dbContext.GetCommand(gamerQueryable).CommandType}<br/><br/>");

                GridView1.DataBind();
            }
        }

        private void GetData()
        {
            using (SampleDataContext dbContext = new SampleDataContext())
            {
                IQueryable<Gamer> gamerQueryable =
                    from gamer in dbContext.Gamers
                    select gamer;
                GridView1.DataSource = gamerQueryable;
                GridView1.DataBind();
            }
        }

        protected void btnGetData_Click(object sender, EventArgs e)
        {
            GetData();
        }

        protected void btnInsert_Click(object sender, EventArgs e)
        {
            using (SampleDataContext dbContext = new SampleDataContext())
            {
                Gamer newGamer = new Gamer
                {
                    Name = "newGamer",
                    Gender = "Male",
                    Score = 4000,
                    Type = "Fire",
                    TeamId = 1
                };

                dbContext.Gamers.InsertOnSubmit(newGamer);  //insert into dbContext
                dbContext.SubmitChanges();  //Submit dbContext into Database
            }
            GetData();
        }

        protected void btnUpdate_Click(object sender, EventArgs e)
        {
            using (SampleDataContext dbContext = new SampleDataContext())
            {
                //Get the last gamer
                int lastId = dbContext.Gamers.Count();
                Gamer gamer = dbContext.Gamers.SingleOrDefault(
                    x => x.Id == lastId);
                if (gamer != null) gamer.Score = 5555;
                dbContext.SubmitChanges();
            }
            GetData();
        }

        protected void btnDelete_Click(object sender, EventArgs e)
        {
            using (SampleDataContext dbContext = new SampleDataContext())
            {
                //Get the last gamer
                int lastId = dbContext.Gamers.Count();
                Gamer gamer = dbContext.Gamers.SingleOrDefault(
                    x => x.Id == lastId);
                //delete the last gamer from dbContext
                if (gamer != null) dbContext.Gamers.DeleteOnSubmit(gamer);
                dbContext.SubmitChanges();  // Save dbContext into Database.
            }
            GetData();
        }

    }
}