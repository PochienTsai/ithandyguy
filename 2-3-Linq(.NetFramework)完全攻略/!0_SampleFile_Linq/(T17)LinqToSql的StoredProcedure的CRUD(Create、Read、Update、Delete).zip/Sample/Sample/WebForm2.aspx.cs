﻿using System;
using System.Linq;

namespace Sample
{
    public partial class WebForm2 : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {

        }

        private void GetData()
        {
            using (SampleDataContext dbContext = new SampleDataContext())
            {
                IQueryable<Gamer> gamerQueryable =
                    from gamer in dbContext.Gamers
                    select gamer;
                GridView1.DataSource = gamerQueryable;
                GridView1.DataBind();
            }
        }

        protected void btnGetAllGamer_Click(object sender, EventArgs e)
        {
            GetData();
        }

        protected void btnInsertGamer_Click(object sender, EventArgs e)
        {
            using (SampleDataContext dbContext = new SampleDataContext())
            {
                Gamer newGamer = new Gamer
                {
                    Name = "newGamer",
                    Gender = "Male",
                    Score = 4000,
                    Type = "Fire",
                    TeamId = 1
                };

                dbContext.Gamers.InsertOnSubmit(newGamer);  //insert into dbContext
                dbContext.SubmitChanges();  //Submit dbContext into Database
            }
            GetData();
        }

        protected void btnUpdateLastGamer_Click(object sender, EventArgs e)
        {
            using (SampleDataContext dbContext = new SampleDataContext())
            {
                //Get the last gamer
                //1.
                //Gamer gamer = dbContext.Gamers.Last();  
                //// Error! Last is not support..
                //2.
                //int lastId = dbContext.Gamers.Count();
                //Gamer gamer = dbContext.Gamers.SingleOrDefault(
                //    x => x.Id == lastId); 
                //// Wrong logic, sometimes Id=1,2,4.. (3 is missing, because someone delete it)
                Gamer gamer = 
                    dbContext.Gamers
                    .OrderByDescending(g => g.Id)
                    .FirstOrDefault();

                if (gamer != null) gamer.Score = 5555;
                dbContext.SubmitChanges();
            }
            GetData();
        }

        protected void btnDeleteLastGamer_Click(object sender, EventArgs e)
        {
            using (SampleDataContext dbContext = new SampleDataContext())
            {
                //Get the last gamer
                //1.
                //Gamer gamer = dbContext.Gamers.Last();  
                //// Error! Last is not support..
                //2.
                //int lastId = dbContext.Gamers.Count();
                //Gamer gamer = dbContext.Gamers.SingleOrDefault(
                //    x => x.Id == lastId); 
                //// Wrong logic, sometimes Id=1,2,4.. (3 is missing, because someone delete it)
                Gamer gamer =
                    dbContext.Gamers
                    .OrderByDescending(g => g.Id)
                    .FirstOrDefault();

                //delete the last gamer from dbContext
                if (gamer != null) dbContext.Gamers.DeleteOnSubmit(gamer);
                dbContext.SubmitChanges();  // Save dbContext into Database.
            }
            GetData();
        }

        protected void btnGamersByTeam1_Click(object sender, EventArgs e)
        {
            using (SampleDataContext dbContext = new SampleDataContext())
            {
                string teamName = string.Empty;
                GridView1.DataSource = dbContext.spGetGamerByTeam(1, ref teamName);
                GridView1.DataBind();

                lblTeamName.Text = $"TeamName=={teamName}";
            }
        }
    }
}