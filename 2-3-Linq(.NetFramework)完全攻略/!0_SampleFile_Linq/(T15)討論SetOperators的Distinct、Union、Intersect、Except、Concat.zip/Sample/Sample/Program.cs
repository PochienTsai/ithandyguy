﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using OnLieGame;

namespace Sample
{
    class Program
    {
        static void Main(string[] args)
        {
            // 1. ==================================
            //DistinctSample()
            Console.WriteLine("1. DistinctSample ==================");
            DistinctSample();

            // 2. ==================================
            //UnionAndConcatSample()
            Console.WriteLine("2. UnionAndConcatSample ==================");
            UnionAndConcatSample();

            // 3. ==================================
            //IntersectSample()
            Console.WriteLine("3. IntersectSample ==================");
            IntersectSample();

            // 4. ==================================
            //ExceptSample()
            Console.WriteLine("4. ExceptSample ==================");
            ExceptSample();

            


            Console.ReadLine();
        }


        // 1. ==================================
        //DistinctSample()
        static void DistinctSample()
        {
            Console.WriteLine("1.1. strArr.Distinct() ------------------------------ ");
            string[] strArr = { "Name1", "name1", "Name2", "Name2", "Name3" };
            IEnumerable<string> strArrDistinct = strArr.Distinct();
            foreach (string strArrDistinctItem in strArrDistinct)
            {
                Console.WriteLine($"strArrDistinctItem=={strArrDistinctItem}");
            }
            // strArrDistinctItem==Name1
            // strArrDistinctItem==name1
            // strArrDistinctItem==Name2
            // strArrDistinctItem==Name3


            Console.WriteLine("1.2. strArr2.Distinct(StringComparer.OrdinalIgnoreCase) -------------------- ");
            string[] strArr2 = { "Name1", "name1", "Name2", "Name2", "Name3" };
            IEnumerable<string> strArr2Distinct = strArr2.Distinct(StringComparer.OrdinalIgnoreCase);
            foreach (string strArr2DistinctItem in strArr2Distinct)
            {
                Console.WriteLine($"strArr2DistinctItem=={strArr2DistinctItem}");
            }
            // strArr2DistinctItem==Name1
            // strArr2DistinctItem==Name2
            // strArr2DistinctItem==Name3
        }


        // 2. ==================================
        //UnionAndConcatSample()
        static void UnionAndConcatSample()
        {
            //Concat operator concatenates two sequences into one sequence.
            //Union combines two collections into one collection 
            //and remove the duplicate elements.

            // 2.1. -------------------------------------
            //intArrA1.Concat(intArrA2)
            Console.WriteLine("2.1. intArrA1.Concat(intArrA2) -------------- ");
            int[] intArrA1 = { 1, 2, 3, 4, 5 };
            int[] intArrA2 = { 1, 3, 5, 7, 9 };
            IEnumerable<int> intArrA1ConcatintArrA2 =
                intArrA1.Concat(intArrA2);
            foreach (int item in intArrA1ConcatintArrA2)
            {
                Console.Write($" [ {item} ] ");
            }
            Console.WriteLine();
            //  [ 1 ]  [ 2 ]  [ 3 ]  [ 4 ]  [ 5 ]  [ 1 ]  [ 3 ]  [ 5 ]  [ 7 ]  [ 9 ]


            // 2.2. -------------------------------------
            //intArrA1.Union(intArrA2)
            Console.WriteLine("2.2. intArrA1.Union(intArrA2) -------------- ");
            IEnumerable<int> intArrA1UnionintArrA2 =
                intArrA1.Union(intArrA2);
            foreach (int item in intArrA1UnionintArrA2)
            {
                Console.Write($" [ {item} ] ");
            }
            Console.WriteLine();
            //  [ 1 ]  [ 2 ]  [ 3 ]  [ 4 ]  [ 5 ]  [ 7 ]  [ 9 ]


            // 2.3. -------------------------------------
            //gamerList1.Concat(gamerList2)
            Console.WriteLine("2.3. gamerList1.Concat(gamerList2) -------------- ");
            List<Gamer> gamerList1 = new List<Gamer>
            {
                new Gamer { Id = 1, Name = "Name1", TeamId = 1 },
                new Gamer { Id = 2, Name = "Name2", TeamId = 2 },
                new Gamer { Id = 5, Name = "Name9", TeamId = 2 }
            };
            List<Gamer> gamerList2 = new List<Gamer>
            {
                new Gamer { Id = 1, Name = "Name1", TeamId = 1 },
                new Gamer { Id = 3, Name = "Name3", TeamId = 1 },
                new Gamer { Id = 4, Name = "Name4", TeamId = 1 },
                new Gamer { Id = 5, Name = "Name9", TeamId = 2 }
            };
            IEnumerable<Gamer> gamerList1ConcatgamerList2 =
                gamerList1.Concat(gamerList2);
            foreach (Gamer gamer in gamerList1ConcatgamerList2)
            {
                Console.WriteLine($"{gamer}");
            }
            // GamerId==1,GamerName=Name1,TeamId=1
            // GamerId==2,GamerName=Name2,TeamId=2
            // GamerId==5,GamerName=Name9,TeamId=2
            // GamerId==1,GamerName=Name1,TeamId=1
            // GamerId==3,GamerName=Name3,TeamId=1
            // GamerId==4,GamerName=Name4,TeamId=1
            // GamerId==5,GamerName=Name9,TeamId=2


            // 2.4. -------------------------------------
            //gamerList1.Union(gamerList2)
            Console.WriteLine("2.4. gamerList1.Union(gamerList2) -------------- ");
            IEnumerable<Gamer> gamerList1UniongamerList2 =
                gamerList1.Union(gamerList2);
            foreach (Gamer gamer in gamerList1UniongamerList2)
            {
                Console.WriteLine($"{gamer}");
            }
            // GamerId==1,GamerName=Name1,TeamId=1
            // GamerId==2,GamerName=Name2,TeamId=2
            // GamerId==5,GamerName=Name9,TeamId=2
            // GamerId==1,GamerName=Name1,TeamId=1
            // GamerId==3,GamerName=Name3,TeamId=1
            // GamerId==4,GamerName=Name4,TeamId=1
            // GamerId==5,GamerName=Name9,TeamId=2



            // 2.5. -------------------------------------
            //gamerList1.Union(gamerList2, new GamerHelper())
            Console.WriteLine("2.5. gamerList1.Union(gamerList2, new GamerHelper()).OrderBy(g => g.Id) -------------- ");
            IEnumerable<Gamer> gamerList1UniongamerList2V2 =
                gamerList1.Union(gamerList2, new GamerHelper())
                .OrderBy(g => g.Id);
            ////IEnumerable<Gamer> gamerList1ConcatgamerList2V2 =
            ////    gamerList1.Concat(gamerList2, new GamerHelper())
            ////Concat with IEqualityComparer is not possible.
            ////because Union without IEqualityComparer can do the same thing.

            foreach (Gamer gamer in gamerList1UniongamerList2V2)
            {
                Console.WriteLine($"{gamer}");
            }
            // GamerId==1,GamerName=Name1,TeamId=1
            // GamerId==2,GamerName=Name2,TeamId=2
            // GamerId==3,GamerName=Name3,TeamId=1
            // GamerId==4,GamerName=Name4,TeamId=1
            // GamerId==5,GamerName=Name9,TeamId=2

        }



        // 3. ==================================
        //IntersectSample()
        static void IntersectSample()
        {
            //Intersect() returns the elements which both collections have.

            // 3.1. -------------------------------------
            //intArrA1.Intersect(intArrA2)
            Console.WriteLine("3.1. intArrA1.Intersect(intArrA2) ------------------ ");
            int[] intArrA1 = { 1, 2, 3, 4, 5 };
            int[] intArrA2 = { 1, 3, 5, 7, 9 };
            IEnumerable<int> intArrA1IntersectintArrA2 = intArrA1.Intersect(intArrA2);
            foreach (int item in intArrA1IntersectintArrA2)
            {
                Console.Write($" [ {item} ] ");
            }
            Console.WriteLine();
            // [ 1 ]  [ 3 ]  [ 5 ]


            // 3.2. -------------------------------------
            //gamerList1.Intersect(gamerList2)
            Console.WriteLine("3.2. gamerList1.Intersect(gamerList2).OrderBy(g => g.Id) -------------- ");
            List<Gamer> gamerList1 = new List<Gamer>
            {
                new Gamer { Id = 1, Name = "Name1", TeamId = 1 },
                new Gamer { Id = 2, Name = "Name2", TeamId = 2 },
                new Gamer { Id = 5, Name = "Name9", TeamId = 2 }
            };
            List<Gamer> gamerList2 = new List<Gamer>
            {
                new Gamer { Id = 1, Name = "Name1", TeamId = 1 },
                new Gamer { Id = 3, Name = "Name3", TeamId = 1 },
                new Gamer { Id = 4, Name = "Name4", TeamId = 1 },
                new Gamer { Id = 5, Name = "Name9", TeamId = 2 }
            };
            IEnumerable<Gamer> gamerList1IntersectgamerList2 =
                gamerList1.Intersect(gamerList2)
                .OrderBy(g => g.Id);
            foreach (Gamer gamer in gamerList1IntersectgamerList2)
            {
                Console.WriteLine($"{gamer}");
            }
            // Return nothing, 
            //because the default Equals() and GetHashCode() 
            //of Gamer is not good enough to let Gamer to compare its properties.


            // 3.3. -------------------------------------
            //gamerList1.Intersect(gamerList2)
            Console.WriteLine("3.3. gamerList1.Intersect(gamerList2, new GamerHelper()).OrderBy(g => g.Id) -------------- ");
            IEnumerable<Gamer> gamerList1IntersectgamerList2V2 =
                gamerList1.Intersect(gamerList2, new GamerHelper())
                .OrderBy(g => g.Id);
            foreach (Gamer gamer in gamerList1IntersectgamerList2V2)
            {
                Console.WriteLine($"{gamer}");
            }
            // GamerId==1,GamerName=Name1,TeamId=1
            // GamerId==5,GamerName=Name9,TeamId=2
        }

        // 4. ==================================
        //ExceptSample()
        static void ExceptSample()
        {
            //Except() returns the elements 
            //that are in the first collection 
            //but not in the second collection.

            // 4.1. -------------------------------------
            //intArrA1.Except(intArrA2)
            Console.WriteLine("4.1. intArrA1.Except(intArrA2) ------------------ ");
            int[] intArrA1 = { 1, 2, 3, 4, 5 };
            int[] intArrA2 = { 1, 3, 5, 7, 9 };
            IEnumerable<int> intArrA1ExceptintArrA2 = intArrA1.Except(intArrA2);
            foreach (int item in intArrA1ExceptintArrA2)
            {
                Console.Write($" [ {item} ] ");
            }
            Console.WriteLine();
            // [ 2 ]  [ 4 ]


            // 4.2. -------------------------------------
            //gamerList1.Except(gamerList2)
            Console.WriteLine("4.2. gamerList1.Except(gamerList2) -------------- ");
            List<Gamer> gamerList1 = new List<Gamer>
            {
                new Gamer { Id = 1, Name = "Name1", TeamId = 1 },
                new Gamer { Id = 2, Name = "Name2", TeamId = 2 },
                new Gamer { Id = 5, Name = "Name9", TeamId = 2 }
            };
            List<Gamer> gamerList2 = new List<Gamer>
            {
                new Gamer { Id = 1, Name = "Name1", TeamId = 1 },
                new Gamer { Id = 3, Name = "Name3", TeamId = 1 },
                new Gamer { Id = 4, Name = "Name4", TeamId = 1 },
                new Gamer { Id = 5, Name = "Name9", TeamId = 2 }
            };
            IEnumerable<Gamer> gamerList1ExceptgamerList2 =
                gamerList1.Except(gamerList2);
            foreach (Gamer gamer in gamerList1ExceptgamerList2)
            {
                Console.WriteLine($"{gamer}");
            }
            // GamerId==1,GamerName=Name1,TeamId=1
            // GamerId==2,GamerName=Name2,TeamId=2
            // GamerId==5,GamerName=Name9,TeamId=2


            // 4.3. -------------------------------------
            //gamerList1.Except(gamerList2)
            Console.WriteLine("4.3. gamerList1.Except(gamerList2, new GamerHelper()).OrderBy(g => g.Id) -------------- ");
            IEnumerable<Gamer> gamerList1ExceptgamerList2V2 =
                gamerList1.Except(gamerList2, new GamerHelper())
                .OrderBy(g => g.Id);
            foreach (Gamer gamer in gamerList1ExceptgamerList2V2)
            {
                Console.WriteLine($"{gamer}");
            }
            // GamerId==2,GamerName=Name2,TeamId=2
        }

    }
}


namespace OnLieGame
{
    public class Team
    {
        public int Id { get; set; }
        public string Name { get; set; }
        public override string ToString()
        {
            return $"TeamId=={Id},TeamName={Name}";
        }
    }

    public class TeamHelper
    {
        public static List<Team> GetSampleTeam()
        {
            return new List<Team>
            {
                new Team { Id = 1, Name = "Team1"},
                new Team { Id = 2, Name = "Team2"},
                new Team { Id = 3, Name = "Team3"},
            };
        }
    }

    public class Gamer
    {
        public int Id { get; set; }
        public string Name { get; set; }
        public int TeamId { get; set; }
        public override string ToString()
        {
            return $"GamerId=={Id},GamerName={Name},TeamId={TeamId}";
        }
    }

    public class GamerHelper : IEqualityComparer<Gamer>
    {
        public static List<Gamer> GetSampleGamer()
        {
            return new List<Gamer>
            {
                new Gamer { Id = 1, Name = "Name1", TeamId = 1 },
                new Gamer { Id = 2, Name = "Name2", TeamId = 2 },
                new Gamer { Id = 3, Name = "Name3", TeamId = 1 },
                new Gamer { Id = 4, Name = "Name4", TeamId = 1 },
                new Gamer { Id = 5, Name = "Name9", TeamId = 2 },
                new Gamer { Id = 6, Name = "Name10"}
            };
        }

        public bool Equals(Gamer x, Gamer y)
        {
            return y != null && x != null &&
                x.Id == y.Id &&
                x.Name == y.Name &&
                x.TeamId == y.TeamId;
        }

        public int GetHashCode(Gamer obj)
        {
            return obj.Id.GetHashCode() ^
                obj.TeamId.GetHashCode() ^
                obj.Name.GetHashCode();
        }
    }

}