Create Table Gamer
(
     Id int primary key IDENTITY(1,1),
     Name nvarchar(100),
     Gender nvarchar(50)
)
GO

Insert into Gamer values ('Name01', 'Male')
Insert into Gamer values ('Name02', 'Female')
Insert into Gamer values ('Name03', 'Male')
Insert into Gamer values ('Name04', 'Female')
Insert into Gamer values ('Name05', 'Female')
GO