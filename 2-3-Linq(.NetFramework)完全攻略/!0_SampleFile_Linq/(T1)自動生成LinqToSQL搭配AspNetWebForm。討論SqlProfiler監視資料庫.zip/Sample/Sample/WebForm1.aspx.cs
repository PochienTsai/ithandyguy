﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data.SqlClient;

namespace Sample
{
    public partial class WebForm1 : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            string cs = ConfigurationManager.ConnectionStrings["SampleConnectionString"].ConnectionString;
            SqlConnection sqlConnection = new SqlConnection(cs);
            SqlCommand sqlCommand = new SqlCommand
                ("Select Id, Name, Gender from Gamer where Gender='Female'", sqlConnection);
            List<GamerA> listGamers = new List<GamerA>();
            sqlConnection.Open();
            SqlDataReader sqlDataReader = sqlCommand.ExecuteReader();
            while (sqlDataReader.Read())
            {
                GamerA gamerItem = new GamerA();
                gamerItem.Id = Convert.ToInt32(sqlDataReader["Id"]);
                gamerItem.Name = sqlDataReader["Name"].ToString();
                gamerItem.Gender = sqlDataReader["Gender"].ToString();

                listGamers.Add(gamerItem);
            }
            sqlConnection.Close();

            GridView1.DataSource = listGamers;
            GridView1.DataBind();
        }
    }

    public class GamerA
    {
        public int Id { get; set; }
        public string Name { get; set; }
        public string Gender { get; set; }
    }
}