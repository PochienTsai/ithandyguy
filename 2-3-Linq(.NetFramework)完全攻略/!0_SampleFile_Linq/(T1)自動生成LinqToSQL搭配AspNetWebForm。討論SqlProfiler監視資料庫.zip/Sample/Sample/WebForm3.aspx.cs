﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace Sample
{
    public partial class WebForm3 : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            SampleDataContext dataContext = new SampleDataContext();
            int[] intArr = {10, 9, 8, 7, 6, 5, 4, 3, 2, 1};
            GridView1.DataSource = from intItem in intArr
                                   where intItem >= 5
                                   select intItem;
            //GridView1.DataSource = intArr.Where(intItem => intItem >= 5);
            GridView1.DataBind();
        }
    }
}