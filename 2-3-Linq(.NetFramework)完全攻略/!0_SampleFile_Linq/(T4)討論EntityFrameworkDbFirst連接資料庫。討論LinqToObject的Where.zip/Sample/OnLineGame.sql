--Drop Table if it exists.
--IF OBJECT_ID('Gamer') IS NOT NULL
IF ( EXISTS ( SELECT    *
              FROM      INFORMATION_SCHEMA.TABLES
              WHERE     TABLE_NAME = 'Gamer' ) )
    BEGIN
        TRUNCATE TABLE Gamer;
        DROP TABLE Gamer;
    END;
GO -- Run the previous command and begins new batch
--IF OBJECT_ID('Team') IS NOT NULL
IF ( EXISTS ( SELECT    *
              FROM      INFORMATION_SCHEMA.TABLES
              WHERE     TABLE_NAME = 'Team' ) )
    BEGIN
        TRUNCATE TABLE Team;
        DROP TABLE Team;
    END;
GO -- Run the previous command and begins new batch



CREATE TABLE Team
    (
      Id INT PRIMARY KEY
             IDENTITY(1, 1) ,
      Name NVARCHAR(50) ,
    );
GO -- Run the previous command and begins new batch
INSERT  INTO Team
VALUES  ( 'Team01');
INSERT  INTO Team
VALUES  ( 'Team02');
INSERT  INTO Team
VALUES  ( 'Team03');
GO -- Run the previous command and begins new batch

CREATE TABLE Gamer
    (
      Id INT PRIMARY KEY
             IDENTITY(1, 1) ,
      [Name] NVARCHAR(100) ,
      Gender NVARCHAR(50) ,
      GameScore INT ,
      TeamId INT FOREIGN KEY REFERENCES Team ( Id )
    );
GO -- Run the previous command and begins new batch
INSERT  INTO Gamer
VALUES  ( 'Name01', 'Male', 5000, 1 );
INSERT  INTO Gamer
VALUES  ( 'Name02', 'Female', 4500, 2 );
INSERT  INTO Gamer
VALUES  ( 'Name03', 'Male', 6000, 1 );
INSERT  INTO Gamer
VALUES  ( 'Name04', 'Male', 3500, 2 );
INSERT  INTO Gamer
VALUES  ( 'Name05', 'Male', 4700, 2 );
INSERT  INTO Gamer
VALUES  ( 'Name06', 'Male', 4800, 1 );
GO -- Run the previous command and begins new batch

