﻿using System;
using System.Data.Entity;
using System.Linq;

namespace Sample
{
    class Program
    {
        static void Main(string[] args)
        {
            // 1. ============================================
            Console.WriteLine("1. ADO.NET with Entity Framework 6 Sample");
            AdoNetWithEntityFramework6Sample();

            Console.ReadLine();
        }

        private static void AdoNetWithEntityFramework6Sample()
        {
            SampleEntities context = new SampleEntities();

            //1.1. teamDbSet -------------------------------
            Console.WriteLine("1.1. teamDbSet ------------");
            DbSet<Team> teamDbSet = context.Teams;
            foreach (Team teamDbSetItem in teamDbSet)
            {
                Console.WriteLine($"teamDbSetItem.Id=={teamDbSetItem.Id}, teamDbSetItem.Name=={teamDbSetItem.Name}");
            }

            //1.2. gamersDbSet -------------------------------
            Console.WriteLine("1.2. gamersDbSet ------------");
            DbSet<Gamer> gamersDbSet = context.Gamers;
            foreach (Gamer gamersDbSetItem in gamersDbSet)
            {
                Console.WriteLine($"gamersDbSetItem.Id=={gamersDbSetItem.Id}, gamersDbSetItem.Name=={gamersDbSetItem.Name}, gamersDbSetItem.Gender=={gamersDbSetItem.Gender}, gamersDbSetItem.GameScore=={gamersDbSetItem.GameScore}, gamersDbSetItem.TeamId=={gamersDbSetItem.TeamId}, gamersDbSetItem.Team.Name=={gamersDbSetItem.Team.Name}");
            }

            //1.3. team01AndTeam02Queryable -------------------------------
            Console.WriteLine("1.3. team01AndTeam02Queryable ------------");
            IQueryable<Team> team01AndTeam02Queryable = context.Teams.Where(t => t.Name.Equals("Team01") || t.Name.Equals("Team02"));
            foreach (Team team01AndTeam02QueryableItem in team01AndTeam02Queryable)
            {
                Console.WriteLine($"team01AndTeam02QueryableItem.Id=={team01AndTeam02QueryableItem.Id}, team01AndTeam02QueryableItem.Name=={team01AndTeam02QueryableItem.Name}");
            }

            //1.4. maleGamersInTeam01Item -------------------------------
            Console.WriteLine("1.4. maleGamersInTeam01Item ------------");
            IQueryable<Gamer> maleGamersInTeam01 = context.Gamers.Where(g => g.Team.Name.Equals("Team01") && g.Gender.Equals("Male"));
            foreach (Gamer maleGamersInTeam01Item in maleGamersInTeam01)
            {
                Console.WriteLine($"maleGamersInTeam01Item.Id=={maleGamersInTeam01Item.Id}, maleGamersInTeam01Item.Name=={maleGamersInTeam01Item.Name}, maleGamersInTeam01Item.Gender=={maleGamersInTeam01Item.Gender}, maleGamersInTeam01Item.Team.Name=={maleGamersInTeam01Item.Team.Name}");
            }

        }
    }
}
