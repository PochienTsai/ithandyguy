﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Xml.Linq;
using OnlineGamer;

namespace Sample
{
    internal class Program
    {

        private static void Main(string[] args)
        {
            // 1. ===========================
            //CreateXml();
            Console.WriteLine("1. CreateXml() ==================== ");
            CreateXml();

            // 2. ===========================
            //CreateXml2();
            Console.WriteLine("2. CreateXml2() ==================== ");
            CreateXml2();

            // 3. ===========================
            //XmlToCsv();
            Console.WriteLine("3. XmlToCsv() ==================== ");
            XmlToCsv();

            // 4. ===========================
            //XmlToHtml();
            Console.WriteLine("4. XmlToHtml() ==================== ");
            XmlToHtml();

            // 5. ===========================
            //XmlToXml();
            Console.WriteLine("5. XmlToXml() ==================== ");
            XmlToXml();

            Console.ReadLine();
        }



        // 1. ===========================
        //CreateXml();
        private static void CreateXml()
        {
            XDocument xDocument = new XDocument(
                new XDeclaration("1.0", "utf-8", "yes"),
                new XComment("Linq to XML"),
                new XElement("Gamers",
                    new XElement("Gamer", new XAttribute("Type", "Magician"),
                        new XElement("Id", 1),
                        new XElement("Name", "Name1 ABC"),
                        new XElement("Gender", "Male"),
                        new XElement("Score", 5000)),
                    new XElement("Gamer", new XAttribute("Type", "Warrior"),
                        new XElement("Id", 2),
                        new XElement("Name", "Name2 ABCDE"),
                        new XElement("Gender", "Female"),
                        new XElement("Score", 4500)),
                    new XElement("Gamer", new XAttribute("Type", "Magician"),
                        new XElement("Id", 3),
                        new XElement("Name", "Name3 EFGH"),
                        new XElement("Gender", "Male"),
                        new XElement("Score", 6500)),
                    new XElement("Gamer", new XAttribute("Type", "Warrior"),
                        new XElement("Id", 4),
                        new XElement("Name", "Name4 HIJKLMN"),
                        new XElement("Gender", "Female"),
                        new XElement("Score", 4500))));

            xDocument.Save(@"C:\Xmls\Gamers1.xml");
        }
        //<?xml version = "1.0" encoding="utf-8" standalone="yes"?>
        //<!--Linq to XML-->
        //<Gamers>
        //  <Gamer Type = "Magician" >
        //    < Id > 1 </ Id >
        //    < Name > Name1 ABC</Name>
        //    <Gender>Male</Gender>
        //    <Score>5000</Score>
        //  </Gamer>
        //  <Gamer Type = "Warrior" >
        //    < Id > 2 </ Id >
        //    < Name > Name2 ABCDE</Name>
        //    <Gender>Female</Gender>
        //    <Score>4500</Score>
        //  </Gamer>
        //  <Gamer Type = "Magician" >
        //    < Id > 3 </ Id >
        //    < Name > Name3 EFGH</Name>
        //    <Gender>Male</Gender>
        //    <Score>6500</Score>
        //  </Gamer>
        //  <Gamer Type = "Warrior" >
        //    < Id > 4 </ Id >
        //    < Name > Name4 HIJKLMN</Name>
        //    <Gender>Female</Gender>
        //    <Score>4500</Score>
        //  </Gamer>
        //</Gamers>



        // 2. ===========================
        //CreateXml2();
        private static void CreateXml2()
        {
            List<Gamer> gamersList = GamerHelper.GetAllGamers();

            XDocument xDocument = new XDocument(
                new XDeclaration("1.0", "utf-8", "yes"),
                new XComment("Linq to XML"),
                new XElement("Gamers",
                    from gamer in gamersList
                    select new XElement("Gamer", new XAttribute("Type", gamer.Type),
                        new XElement("Name", gamer.Id),
                        new XElement("Name", gamer.Name),
                        new XElement("Gender", gamer.Gender),
                        new XElement("Score", gamer.Score))
                ));

            //SaveOptions.DisableFormatting will disable formatting the XML document 
            //The following xml will be stored in one single line.
            xDocument.Save(@"C:\Xmls\Gamers2.xml", SaveOptions.DisableFormatting);
        }
        //<?xml version = "1.0" encoding="utf-8" standalone="yes"?>
        //<!--Linq to XML-->
        //<Gamers>
        //  <Gamer Type = "Magician" >
        //    < Id > 1 </ Id >
        //    < Name > Name1 ABC</Name>
        //    <Gender>Male</Gender>
        //    <Score>5000</Score>
        //  </Gamer>
        //  <Gamer Type = "Warrior" >
        //    < Id > 2 </ Id >
        //    < Name > Name2 ABCDE</Name>
        //    <Gender>Female</Gender>
        //    <Score>4500</Score>
        //  </Gamer>
        //  <Gamer Type = "Magician" >
        //    < Id > 3 </ Id >
        //    < Name > Name3 EFGH</Name>
        //    <Gender>Male</Gender>
        //    <Score>6500</Score>
        //  </Gamer>
        //  <Gamer Type = "Warrior" >
        //    < Id > 4 </ Id >
        //    < Name > Name4 HIJKLMN</Name>
        //    <Gender>Female</Gender>
        //    <Score>4500</Score>
        //  </Gamer>
        //</Gamers>



        // 3. ===========================
        //XmlToCsv();
        private static void XmlToCsv()
        {
            var sb = new StringBuilder();
            var delimiter = ",";

            XDocument.Load(@"C:\Xmls\Gamers1.xml").Descendants("Gamer")
                .ToList().ForEach(gamerElement =>
                {
                    XAttribute xAttributeType = gamerElement.Attribute("Type");
                    if (xAttributeType == null) return;
                    XElement xElementId = gamerElement.Element("Id");
                    if (xElementId == null) return;
                    XElement xElementName = gamerElement.Element("Name");
                    if (xElementName == null) return;
                    XElement xElementGender = gamerElement.Element("Gender");
                    if (xElementGender == null) return;
                    XElement xElementScore = gamerElement.Element("Score");
                    if (xElementScore != null)
                        sb.Append($"{xAttributeType.Value}{delimiter}" +
                                  $"{xElementId.Value}{delimiter}" +
                                  $"{xElementName.Value}{delimiter}" +
                                  $"{xElementGender.Value}{delimiter}" +
                                  $"{xElementScore.Value}{delimiter}\r\n");
                });
            var sw = new StreamWriter(@"C:\Xmls\Gamers1.csv");
            sw.WriteLine(sb.ToString());
            sw.Close();
        }
        // Magician,1,Name1 ABC,Male,5000,
        // Warrior,2,Name2 ABCDE,Female,4500,
        // Magician,3,Name3 EFGH,Male,6500,
        // Warrior,4,Name4 HIJKLMN,Female,4500,



        // 4. ===========================
        //XmlToHtml();
        private static void XmlToHtml()
        {
            XDocument xDocument = XDocument.Load(@"C:\Xmls\Gamers1.xml");

            var xDocumentHtml =
                new XDocument
                (new XElement("table", new XAttribute("border", 1),
                    new XElement("thead",
                        new XElement("tr",
                            new XElement("th", "Type"),
                            new XElement("th", "Id"),
                            new XElement("th", "Name"),
                            new XElement("th", "Gender"),
                            new XElement("th", "Score"))),
                    new XElement("tbody",
                        from gamer in xDocument.Descendants("Gamer")
                        let xAttributeType = gamer.Attribute("Type")
                        where xAttributeType != null
                        let xElementId = gamer.Element("Id")
                        where xElementId != null
                        let xElementName = gamer.Element("Name")
                        where xElementName != null
                        let xElementGender = gamer.Element("Gender")
                        where xElementGender != null
                        let xElementScore = gamer.Element("Score")
                        where xElementScore != null
                        select new XElement("tr",
                            new XElement("td", xAttributeType.Value),
                            new XElement("td", xElementId.Value),
                            new XElement("td", xElementName.Value),
                            new XElement("td", xElementGender.Value),
                            new XElement("td", xElementScore.Value)))));
            xDocumentHtml.Save(@"C:\Xmls\Gamers1.html");
        }
        //<?xml version = "1.0" encoding="utf-8"?>
        //<table border = "1" >
        //  < thead >
        //    < tr >
        //      < th > Type </ th >
        //      < th > Id </ th >
        //      < th > Name </ th >
        //      < th > Gender </ th >
        //      < th > Score </ th >
        //    </ tr >
        //  </ thead >
        //  < tbody >
        //    < tr >
        //      < td > Magician </ td >
        //      < td > 1 </ td >
        //      < td > Name1 ABC</td>
        //      <td>Male</td>
        //      <td>5000</td>
        //    </tr>
        //    <tr>
        //      <td>Warrior</td>
        //      <td>2</td>
        //      <td>Name2 ABCDE</td>
        //      <td>Female</td>
        //      <td>4500</td>
        //    </tr>
        //    <tr>
        //      <td>Magician</td>
        //      <td>3</td>
        //      <td>Name3 EFGH</td>
        //      <td>Male</td>
        //      <td>6500</td>
        //    </tr>
        //    <tr>
        //      <td>Warrior</td>
        //      <td>4</td>
        //      <td>Name4 HIJKLMN</td>
        //      <td>Female</td>
        //      <td>4500</td>
        //    </tr>
        //  </tbody>
        //</table>



        // 5. ===========================
        //XmlToXml();
        private static void XmlToXml()
        {
            XDocument xDocumentGamer = XDocument.Load(@"C:\Xmls\Gamers1.xml");

            var xDocumentXml = new XDocument(
                new XElement("Gamers",
                    new XElement("Magician",
                        from gamer in xDocumentGamer.Descendants("Gamer")
                        let xAttributeType = gamer.Attribute("Type")
                        where xAttributeType != null && xAttributeType.Value == "Magician"
                        let xElementId = gamer.Element("Id")
                        where xElementId != null
                        let xElementName = gamer.Element("Name")
                        where xElementName != null
                        let xElementGender = gamer.Element("Gender")
                        where xElementGender != null
                        let xElementScore = gamer.Element("Score")
                        where xElementScore != null
                        select new XElement("Gamer",
                            new XElement("Id", xElementId.Value),
                            new XElement("Name", xElementName.Value),
                            new XElement("Gender", xElementGender.Value),
                            new XElement("Score", xElementScore.Value))),
                    new XElement("Warrior",
                        from gamer in xDocumentGamer.Descendants("Gamer")
                        let xAttributeWarriorType = gamer.Attribute("Type")
                        where xAttributeWarriorType != null && xAttributeWarriorType.Value == "Warrior"
                        let xElementWarriorId = gamer.Element("Id")
                        where xElementWarriorId != null
                        let xElementWarriorName = gamer.Element("Name")
                        where xElementWarriorName != null
                        let xElementWarriorGender = gamer.Element("Gender")
                        where xElementWarriorGender != null
                        let xElementWarriorScore = gamer.Element("Score")
                        where xElementWarriorScore != null
                        select new XElement("Gamer",
                            new XElement("Id", xElementWarriorId.Value),
                            new XElement("Name", xElementWarriorName.Value),
                            new XElement("Gender", xElementWarriorGender.Value),
                            new XElement("Score", xElementWarriorScore.Value)))));
            xDocumentXml.Save(@"C:\Xmls\Gamers1A.xml");
        }
    }
}

namespace OnlineGamer
{
    // 2. ===========================
    public class Gamer
    {
        public int Id { get; set; }
        public string Name { get; set; }
        public string Gender { get; set; }
        public int Score { get; set; }
        public string Type { get; set; }

        public override string ToString()
        {
            return $"Id=={Id},Name=={Name},Gender=={Gender},Score=={Score},Type=={Type}";
        }
    }

    public class GamerHelper
    {
        public static List<Gamer> GetAllGamers()
        {
            return new List<Gamer>
            {
                new Gamer {Id = 1, Name = "Name1 ABC", Gender = "Male", Score = 5000, Type = "Magician"},
                new Gamer {Id = 2, Name = "Name2 ABCDE", Gender = "Female", Score = 4500, Type = "Warrior"},
                new Gamer {Id = 3, Name = "Name3 EFGH", Gender = "Male", Score = 6500, Type = "Magician"},
                new Gamer {Id = 4, Name = "Name4 HIJKLMN", Gender = "Female", Score = 4500, Type = "Warrior"}
            };
        }
    }
}