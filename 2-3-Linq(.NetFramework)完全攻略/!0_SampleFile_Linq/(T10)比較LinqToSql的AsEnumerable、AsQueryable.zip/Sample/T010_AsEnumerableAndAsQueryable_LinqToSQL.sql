Create Table Gamer
(
     Id int primary key IDENTITY(1,1),
     Name nvarchar(100),
     Gender nvarchar(50),
	 Score int
)
GO
Insert into Gamer values ('Name1', 'Male', 3500)
Insert into Gamer values ('Name2', 'Female', 4000)
Insert into Gamer values ('Name3', 'Male', 5000)
Insert into Gamer values ('Name4', 'Female', 7000)
Insert into Gamer values ('Name5', 'Female', 3000)
Insert into Gamer values ('Name6', 'Male', 4500)
Insert into Gamer values ('Name7', 'Male', 4000)
Insert into Gamer values ('Name8', 'Male', 5500)
Insert into Gamer values ('Name9', 'Female', 6500)
Insert into Gamer values ('Name10', 'Female', 3500)
GO




