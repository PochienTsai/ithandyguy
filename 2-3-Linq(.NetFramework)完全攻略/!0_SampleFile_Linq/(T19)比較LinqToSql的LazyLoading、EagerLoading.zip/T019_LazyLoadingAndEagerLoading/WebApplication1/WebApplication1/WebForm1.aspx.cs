﻿using System;
using System.Data.Linq;
using System.Linq;

namespace WebApplication1
{
    public partial class WebForm1 : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            // 1. ===================================
            LazyLoading();
            // 2. ===================================
            EagerLoading();
            // 3. ===================================
            EagerLoading2();
        }

        // 1. ===================================
        private void LazyLoading()
        {
            using (SampleDataContext dbContext = new SampleDataContext())
            {

                ////Write the generated sql query to the Console window
                //dbContext.Log = Console.Out;

                //Write the generated sql query to the webform
                dbContext.Log = Response.Output;

                //IQueryable<Team> linqQuery = 
                //    from team in dbContext.Teams
                //    select team;
                //Response.Write($"<br/>dbContext.GetCommand(linqQuery).CommandText<br/>{dbContext.GetCommand(linqQuery).CommandText}<br/><br/>");

                gvTeams.DataSource = dbContext.Teams;
                gvTeams.DataBind();
            }
        }

        // 2. ===================================
        private void EagerLoading()
        {
            using (SampleDataContext dbContext = new SampleDataContext())
            {
                Response.Write("<br/><br/>gvTeams2==========================<br/>");
                //Write the generated sql query to the webform
                dbContext.Log = Response.Output;

                DataLoadOptions loadOptions = new DataLoadOptions();
                loadOptions.LoadWith<Team>(t => t.Gamers);
                dbContext.LoadOptions = loadOptions;

                gvTeams2.DataSource = dbContext.Teams;
                gvTeams2.DataBind();
            }

        }

        // 3. ===================================
        private void EagerLoading2()
        {
            using (SampleDataContext dbContext = new SampleDataContext())
            {
                var linqQuery = from team in dbContext.Teams
                                select new { Id = team.Id, Name=team.Name, Type=team.Type, Gamers = team.Gamers };
                lbl3.Text = $"<br/>dbContext.GetCommand(linqQuery).CommandText<br/>{dbContext.GetCommand(linqQuery).CommandText}<br/><br/>";
  
                gvTeams3.DataSource = linqQuery;
                gvTeams3.DataBind();
            }

        }
    }
}