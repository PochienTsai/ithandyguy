﻿using System;
using System.Collections.Generic;
using System.Data.Linq;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Sample
{
    class Program
    {
        static void Main(string[] args)
        {
            // 1. ===================================
            //LazyLoading()
            Console.WriteLine("1. LazyLoading() ================== ");
            LazyLoading();

            // 2. ===================================
            //EagerLoading()
            Console.WriteLine("2. EagerLoading() ================== ");
            EagerLoading();

            // 3. ===================================
            //EagerLoading2()
            Console.WriteLine("3. EagerLoading2() ================== ");
            EagerLoading2();

            Console.ReadLine();
        }

        // 1. ===================================
        //LazyLoading()
        static void LazyLoading()
        {
            using (SampleDataContext dbContext = new SampleDataContext())
            {
                //Write the generated sql query to the Console window
                dbContext.Log = Console.Out;
                foreach (Team team in dbContext.Teams)
                {
                    Console.WriteLine("Team -------------------------");
                    Console.WriteLine(team);
                    foreach (Gamer gamer in team.Gamers)
                    {
                        Console.WriteLine("Gamer -----------");
                        Console.WriteLine(gamer);
                    }
                    Console.WriteLine();
                }
            }
        }


        // 2. ===================================
        //EagerLoading()
        static void EagerLoading()
        {
            using (SampleDataContext dbContext = new SampleDataContext())
            {
                //Write the generated sql query to the Console window
                dbContext.Log = Console.Out;

                // Load related Employee entities along with the Department entity
                DataLoadOptions loadOptions = new DataLoadOptions();
                loadOptions.LoadWith<Team>(t => t.Gamers);
                dbContext.LoadOptions = loadOptions;

                foreach (Team team in dbContext.Teams)
                {
                    Console.WriteLine("Team -------------------------");
                    Console.WriteLine(team);
                    foreach (Gamer gamer in team.Gamers)
                    {
                        Console.WriteLine("Gamer -----------");
                        Console.WriteLine(gamer);
                    }
                    Console.WriteLine();
                }
            }
        }


        // 3. ===================================
        //EagerLoading2()
        static void EagerLoading2()
        {
            using (SampleDataContext dbContext = new SampleDataContext())
            {
                //Write the generated sql query to the Console window
                dbContext.Log = Console.Out;

                var linqQuery = from team in dbContext.Teams
                                select new { Team = team, Gamers = team.Gamers };

                foreach (var linqQueryItem in linqQuery)
                {
                    Console.WriteLine("Team -------------------------");
                    Console.WriteLine(linqQueryItem.Team);
                    foreach (Gamer gamer in linqQueryItem.Gamers)
                    {
                        Console.WriteLine("Gamer -----------");
                        Console.WriteLine(gamer);
                    }
                    Console.WriteLine();
                }
            }
        }
    }

    public partial class Gamer
    {
        public override string ToString()
        {
            return $"Id=={Id},Name=={Name},Gender=={Gender},Score=={Score},Type=={Type},TeamId=={TeamId}";
        }
    }

    public partial class Team
    {
        public override string ToString()
        {
            return $"Id=={Id},Name=={Name},Type=={Type}";
        }
    }
}
