﻿using System;
using System.Xml.Linq;
using System.Xml.Schema;

namespace Sample
{
    class Program
    {
        static void Main(string[] args)
        {
            string xsdPathGamers = @"Gamers.xsd"; //load from bin/debug
            string xsdPathBookstore = @"Bookstore.xsd"; //load from bin/debug

            // 1. ====================================
            // Test Gamers.xml by Gamers.xsd
            Console.WriteLine("1. Test Gamers.xml by Gamers.xsd ================= ");
            XmlValidateByXsd(xsdPathGamers, @"Gamers.xml");
            // xsdPath==Gamers.xsd,xmlPath==Gamers.xml,validation==Passed



            // 2. ====================================
            // Test Gamers2.xml by Gamers.xsd
            Console.WriteLine("2. Test Gamers2.xml by Gamers.xsd ================= ");
            XmlValidateByXsd(xsdPathGamers, @"Gamers2.xml");
            Console.WriteLine("Fail because more than 4 Gamers");
            // The element 'Gamers' has invalid child element 'Gamer'.
            // xsdPath==Gamers.xsd,xmlPath==Gamers2.xml,validation==Failed
            // Fail because more than 4 Gamers

            

            // 3. ====================================
            // Test Gamers3.xml by Gamers.xsd
            Console.WriteLine("3. Test Gamers3.xml by Gamers.xsd ================= ");
            XmlValidateByXsd(xsdPathGamers, @"Gamers3.xml");
            Console.WriteLine("Fail because less than 2 Gamers");
            // The element 'Gamers' has incomplete content. List of possible elements expected: 'Gamer'.
            // xsdPath==Gamers.xsd,xmlPath==Gamers3.xml,validation==Failed
            // Fail because less than 2 Gamers



            // 4. ====================================
            // Test Gamers4.xml by Gamers.xsd
            Console.WriteLine("4. Test Gamers4.xml by Gamers.xsd ================= ");
            XmlValidateByXsd(xsdPathGamers, @"Gamers4.xml");
            Console.WriteLine("The Score and Id is not in the right position.");
            // 4. Test Gamers4.xml by Gamers.xsd =================
            // The element 'Gamer' has invalid child element 'Score'. List of possible elements expected: 'Id'.
            // xsdPath==Gamers.xsd,xmlPath==Gamers4.xml,validation==Failed
            // The Score and Id is not in the right position.



            // 5. ====================================
            // Test Bookstore.xml by Bookstore.xsd
            Console.WriteLine("5. Test Bookstore.xml by Bookstore.xsd ================= ");
            XmlValidateByXsd(xsdPathBookstore, @"Bookstore.xml");
            Console.WriteLine("Genre and lang attributes can be in any order.");
            // xsdPath==Bookstore.xsd,xmlPath==Bookstore.xml,validation==Passed
            // Genre and lang attributes can be in any order.



            // 6. ====================================
            // Test Bookstore2.xml by Bookstore.xsd
            Console.WriteLine("6. Test Bookstore2.xml by Bookstore.xsd ================= ");
            XmlValidateByXsd(xsdPathBookstore, @"Bookstore2.xml");
            Console.WriteLine("The first book has no title and no price.");
            // The element 'book' in namespace 'urn:bookstore-schema' has invalid child element 'author' in namespace 'urn:bookstore-schema'. List of possible elements expected: 'title' in namespace 'urn:bookstore-schema'.
            // xsdPath==Bookstore.xsd,xmlPath==Bookstore2.xml,validation==Failed
            // The first book has no title and no price.
            



            // 7. ====================================
            // Test Bookstore3.xml by Bookstore.xsd
            Console.WriteLine("7. Test Bookstore3.xml by Bookstore.xsd ================= ");
            XmlValidateByXsd(xsdPathBookstore, @"Bookstore3.xml");
            Console.WriteLine("The last book author has no first name and last name.");
            // The element 'author' in namespace 'urn:bookstore-schema' has invalid child element 'name' in namespace 'urn:bookstore-schema'. List of possible elements expected: 'first-name' in namespace 'urn:bookstore-schema'.
            // xsdPath==Bookstore.xsd,xmlPath==Bookstore3.xml,validation==Failed
            // The last book author has no first name and last name.
            


            // 8. ====================================
            // Test Bookstore4.xml by Bookstore.xsd
            Console.WriteLine("8. Test Bookstore4.xml by Bookstore.xsd ================= ");
            XmlValidateByXsd(xsdPathBookstore, @"Bookstore4.xml");
            Console.WriteLine("The bookStore must contain at least 2 books");
            // The element 'bookstore' in namespace 'urn:bookstore-schema' has incomplete content. List of possible elements expected: 'book' in namespace 'urn:bookstore-schema'.
            // xsdPath==Bookstore.xsd,xmlPath==Bookstore4.xml,validation==Failed
            // The bookStore must contain at least 2 books
            


            // 9. ====================================
            // Test Bookstore5.xml by Bookstore.xsd
            Console.WriteLine("9. Test Bookstore5.xml by Bookstore.xsd ================= ");
            XmlValidateByXsd(xsdPathBookstore, @"Bookstore5.xml");
            Console.WriteLine("The lang must be EnglishUK or EnglishUSA");
            // The 'lang' attribute is invalid - The value 'Japanese' is invalid according to its datatype 'String' - The Pattern constraint failed.
            // xsdPath==Bookstore.xsd,xmlPath==Bookstore5.xml,validation==Failed
            // The lang must be EnglishUK or EnglishUSA
            

            // 10. ====================================
            // Test Bookstore6.xml by Bookstore.xsd
            Console.WriteLine("10. Test Bookstore6.xml by Bookstore.xsd ================= ");
            XmlValidateByXsd(xsdPathBookstore, @"Bookstore6.xml");
            Console.WriteLine("The last book sub-elements must be in right order.");
            // The element 'book' in namespace 'urn:bookstore-schema' has invalid child element 'price' in namespace 'urn:bookstore-schema'. List of possible elements expected: 'title' in namespace 'urn:bookstore-schema'.
            // xsdPath==Bookstore.xsd,xmlPath==Bookstore6.xml,validation==Failed
            // The last book sub-elements must be in right order.



            Console.ReadLine();
        }

        private static void XmlValidateByXsd(string xsdPath, string xmlPath)
        {
            //Load xsd
            XmlSchemaSet xmlSchemaSet = new XmlSchemaSet();
            xmlSchemaSet.Add(null, xsdPath);

            //Load xml
            XDocument xmlDocument = XDocument.Load(xmlPath);

            //Validate Error
            bool validationErrors = false;
            xmlDocument.Validate(xmlSchemaSet, (sender, eventArgs) =>
            {
                Console.WriteLine(eventArgs.Message);
                validationErrors = true;
            });
            // if xmlDocument does NOT pass the validation of xmlSchemaSet,
            // then it will run the anonymous methods.
            string validationStr = validationErrors? "Failed": "Passed";
            Console.WriteLine($"xsdPath=={xsdPath},xmlPath=={xmlPath},validation=={validationStr}");
        }
    }
}

