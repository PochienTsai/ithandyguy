/*
1.
One Team can have many Gamers
One Gamer can have One Team.
This is One to Many Relationship.
2.
Team Id==4 has no Gamer.
Gamer Id==7 has no Team.
*/

--1 ----------------------------------------------------------
--Drop Table if it exists.
--IF OBJECT_ID('Gamer') IS NOT NULL
IF ( EXISTS ( SELECT    *
              FROM      INFORMATION_SCHEMA.TABLES
              WHERE     TABLE_NAME = 'Gamer' ) )
    BEGIN
        TRUNCATE TABLE Gamer;
        DROP TABLE Gamer;
    END;
GO -- Run the previous command and begins new batch
--Drop Table if it exists.
--IF OBJECT_ID('Team') IS NOT NULL
IF ( EXISTS ( SELECT    *
              FROM      INFORMATION_SCHEMA.TABLES
              WHERE     TABLE_NAME = 'Team' ) )
    BEGIN
        TRUNCATE TABLE Team;
        DROP TABLE Team;
    END;
GO -- Run the previous command and begins new batch
--Create Tables
CREATE TABLE Team
    (
      Id INT PRIMARY KEY
             IDENTITY ,
      Name NVARCHAR(100) ,
      Type NVARCHAR(100)
    );
GO -- Run the previous command and begins new batch
CREATE TABLE Gamer
    (
      Id INT PRIMARY KEY
             IDENTITY ,
      Name NVARCHAR(50) ,
      Gender NVARCHAR(50) ,
      Score INT ,
      Type NVARCHAR(50) ,
      TeamId INT FOREIGN KEY REFERENCES Team ( Id )
    );
GO -- Run the previous command and begins new batch


--2 ----------------------------------------------------------
--Insert Data
INSERT  INTO Team
VALUES  ( 'Team1_Guardian', 'Guardian' );
INSERT  INTO Team
VALUES  ( 'Team2_Assassinator', 'Assassinator' );
INSERT  INTO Team
VALUES  ( 'Team3_Soldier', 'Soldier' );
INSERT  INTO Team
VALUES  ( 'Team4_Civilian', 'Civilian' );
GO -- Run the previous command and begins new batch
INSERT  INTO Gamer
VALUES  ( 'Name1 ABC', 'Male', 5000, 'Water', 1 );
INSERT  INTO Gamer
VALUES  ( 'Name2 ABCDE', 'Female', 4500, 'Fire', 3 );
INSERT  INTO Gamer
VALUES  ( 'Name3 EFGH', 'Male', 6500, 'Fire', 2 );
INSERT  INTO Gamer
VALUES  ( 'Name4 HIJKLMN', 'Female', 45000, 'Water', 2 );
INSERT  INTO Gamer
VALUES  ( 'Name5 NOP', 'Male', 3000, 'Wood', 1 );
INSERT  INTO Gamer
VALUES  ( 'Name6 PQRSTUVW', 'Male', 4000, 'Earth', 3 );
INSERT  INTO Gamer
VALUES  ( 'Name7 XYZ', 'Male', 4500, 'Metal', NULL );
GO -- Run the previous command and begins new batch


--3 ----------------------------------------------------------

--3.1. --------------------------------
--Drop Stored Procedure if it exists.
--IF OBJECT_ID('spGetGamers') IS NOT NULL
IF ( EXISTS ( SELECT    *
              FROM      INFORMATION_SCHEMA.ROUTINES
              WHERE     ROUTINE_TYPE = 'PROCEDURE'
                        AND LEFT(ROUTINE_NAME, 3) NOT IN ( 'sp_', 'xp_', 'ms_' )
                        AND SPECIFIC_NAME = 'spGetGamers' ) )
    BEGIN
        DROP PROCEDURE spGetGamers;
    END;
GO -- Run the previous command and begins new batch
CREATE PROCEDURE spGetGamers
AS
    BEGIN
        SELECT  Id ,
                Name ,
                Gender ,
                Score ,
                Type ,
                TeamId
        FROM    Gamer;
    END;
GO -- Run the previous command and begins new batch


--3.2. --------------------------------
-- Update Stored Procedure
--Drop Stored Procedure if it exists.
--IF OBJECT_ID('spInsertGamer') IS NOT NULL
IF ( EXISTS ( SELECT    *
              FROM      INFORMATION_SCHEMA.ROUTINES
              WHERE     ROUTINE_TYPE = 'PROCEDURE'
                        AND LEFT(ROUTINE_NAME, 3) NOT IN ( 'sp_', 'xp_', 'ms_' )
                        AND SPECIFIC_NAME = 'spInsertGamer' ) )
    BEGIN
        DROP PROCEDURE spInsertGamer;
    END;
GO -- Run the previous command and begins new batch
CREATE PROCEDURE spInsertGamer
    @name NVARCHAR(50) ,
    @gender NVARCHAR(50) ,
    @score INT ,
    @type NVARCHAR ,
    @teamId int
AS
    BEGIN
        INSERT  INTO Gamer
        VALUES  ( @name, @gender, @score, @type, @teamId );
    END;
GO


--3.3. --------------------------------
-- Update Stored Procedure
--Drop Stored Procedure if it exists.
--IF OBJECT_ID('spUpdateGamer') IS NOT NULL
IF ( EXISTS ( SELECT    *
              FROM      INFORMATION_SCHEMA.ROUTINES
              WHERE     ROUTINE_TYPE = 'PROCEDURE'
                        AND LEFT(ROUTINE_NAME, 3) NOT IN ( 'sp_', 'xp_', 'ms_' )
                        AND SPECIFIC_NAME = 'spUpdateGamer' ) )
    BEGIN
        DROP PROCEDURE spUpdateGamer;
    END;
GO -- Run the previous command and begins new batch
CREATE PROCEDURE spUpdateGamer
    @id INT ,
    @name NVARCHAR(50) ,
    @gender NVARCHAR(50) ,
    @score INT ,
    @type NVARCHAR ,
    @teamId int
AS
    BEGIN
        UPDATE  Gamer
        SET     Name = @name ,
                Gender = @gender ,
                Score = @score ,
                Type = @type ,
                TeamId = @teamId
        WHERE   Id = @id;
    END;
GO -- Run the previous command and begins new batch


--3.4. --------------------------------
-- Delete Stored Procedure
--Drop Stored Procedure if it exists.
--IF OBJECT_ID('spDeleteGamer') IS NOT NULL
IF ( EXISTS ( SELECT    *
              FROM      INFORMATION_SCHEMA.ROUTINES
              WHERE     ROUTINE_TYPE = 'PROCEDURE'
                        AND LEFT(ROUTINE_NAME, 3) NOT IN ( 'sp_', 'xp_', 'ms_' )
                        AND SPECIFIC_NAME = 'spDeleteGamer' ) )
    BEGIN
        DROP PROCEDURE spDeleteGamer;
    END;
GO -- Run the previous command and begins new batch
CREATE PROCEDURE spDeleteGamer @Id int
AS
    BEGIN
        DELETE  FROM dbo.Gamer
        WHERE   Id = @Id;
    END;
GO


--3.5. --------------------------------

--3.5.1. --------------------------------
-- Delete Stored Procedure
--Drop Stored Procedure if it exists.
--IF OBJECT_ID('spGetGamerByTeam') IS NOT NULL
IF ( EXISTS ( SELECT    *
              FROM      INFORMATION_SCHEMA.ROUTINES
              WHERE     ROUTINE_TYPE = 'PROCEDURE'
                        AND LEFT(ROUTINE_NAME, 3) NOT IN ( 'sp_', 'xp_', 'ms_' )
                        AND SPECIFIC_NAME = 'spGetGamerByTeam' ) )
    BEGIN
        DROP PROCEDURE spGetGamerByTeam;
    END;
GO -- Run the previous command and begins new batch
CREATE PROCEDURE spGetGamerByTeam
    @teamId INT ,
    @teamName NVARCHAR(100) OUT
AS
    BEGIN
        SELECT  @teamName = Name
        FROM    dbo.Team
        WHERE   Id = @teamId;

        SELECT  *
        FROM    dbo.Gamer
        WHERE   TeamId = @teamId;
    END;
GO

--3.5.2. --------------------------------
--Test
DECLARE @teamName NVARCHAR(50);
EXECUTE spGetGamerByTeam 1, @teamName OUT;
SELECT  @teamName;


