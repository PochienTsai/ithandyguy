﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace Sample
{
    public partial class WebForm1 : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            GetData();
        }

        private void GetData()
        {
            string cs = ConfigurationManager.
               ConnectionStrings["SampleConnectionString"].ConnectionString;

            using (SampleDataContext dbContext = new SampleDataContext(cs))
            {
                IQueryable<Gamer> gamerQueryable =
                    from gamer in dbContext.Gamer
                    select gamer;
                GridView1.DataSource = gamerQueryable;
                GridView1.DataBind();
            }
        }

    }
}