﻿namespace OnlineGame.Web.Models
{
    public class TeamTotals
    {
        public string Name { get; set; }
        public int Total { get; set; }
    }
}
