﻿using System;
using System.Collections.Generic;
using System.Data.Entity;
using System.Globalization;
using System.Linq;
using System.Threading.Tasks;
using System.Net;
using System.Web.Mvc;
using System.Web.UI;
using OnlineGame.Web.Models;
using OnlineGame.Web.WebShared;
using PagedList;

namespace OnlineGame.Web.Controllers
{
    public class GamerController : Controller
    {
        private OnlineGameContext db = new OnlineGameContext();

        // GET: Gamer
        [HttpGet]
        public async Task<ActionResult> Index()
        {
            return View(await db.Gamers.ToListAsync());
        }

        // GET: Gamer
        [HttpGet]
        [OutputCache(Duration = 10)]
        //[OutputCache(Duration = 10, VaryByParam = "None", Location = OutputCacheLocation.ServerAndClient)]
        //[OutputCache(Duration = 10, VaryByParam = "None", Location = OutputCacheLocation.Client)]
        public async Task<ActionResult> Index2()
        {
            System.Threading.Thread.Sleep(3000);
            ViewBag.ServerTime = DateTime.Now.ToString(CultureInfo.InvariantCulture);
            return View(await db.Gamers.ToListAsync());
        }

        // GET: Gamer
        [HttpGet]
        public async Task<ActionResult> Index3()
        {
            ViewBag.ServerTime = DateTime.Now.ToString(CultureInfo.InvariantCulture);
            return View(await db.Gamers.ToListAsync());
        }

        // GET: Gamer
        [HttpGet]
        public async Task<ActionResult> Index3V2()
        {
            ViewBag.ServerTime = DateTime.Now.ToString(CultureInfo.InvariantCulture);
            return View(await db.Gamers.ToListAsync());
        }

        //[ChildActionOnly] make the action to be accessible only by a child request,
        //so no one can make a direct URL request to this action.
        [ChildActionOnly]
        [HttpGet]
        [OutputCache(Duration = 10)]
        public string GetGamerCount()
        {
            System.Threading.Thread.Sleep(3000);
            return $"Gamer Count = {db.Gamers.Count()} At {DateTime.Now}";
        }
        

        [HttpGet]
        //[OutputCache(Duration = 60)]
        [OutputCache(CacheProfile = "outputCacheProfile1")]
        public async Task<ActionResult> Index4()
        {
            ViewBag.ServerTime = DateTime.Now.ToString(CultureInfo.InvariantCulture);
            return View(await db.Gamers.ToListAsync());
        }

        //[ChildActionOnly] make the action to be accessible only by a child request,
        //so no one can make a direct URL request to this action.
        [ChildActionOnly]
        [HttpGet]
        //[OutputCache(Duration = 60)]
        //[OutputCache(CacheProfile = "outputCacheProfile1")]   //This will thrwo exception
        [CustomizeCache("outputCacheProfile1")]
        public string GetGamerCount2()
        {
            System.Threading.Thread.Sleep(3000);
            return $"Gamer Count = {db.Gamers.Count()} At {DateTime.Now}";
        }

        //[OutputCache(Duration = 5, VaryByParam = "none")]
        [OutputCache(Duration = 60, VaryByParam = "gamerName")]
        public ActionResult Index5(string gamerName)
        {
            ViewBag.GamerName = gamerName ?? string.Empty;
            ViewBag.ServerTime = DateTime.Now.ToString(CultureInfo.InvariantCulture);
            return View();
        }

        //From T013
        // GET: Gamer
        [HttpGet]
        ////1.
        //[OutputCache(Duration = 5, VaryByParam = "none")] 
        ////It means always cache the same contents.
        ////2.
        //[OutputCache(Duration = 60, VaryByParam = "*")]
        ////It means for cache for every parameters, 
        ////this is dangerous becuase of the view might have too many parameters.
        ////3.
        [OutputCache(Duration = 60, VaryByParam = "searchBy;searchText;pageNumber;sortBy")]
        public async Task<ActionResult> Index6(string searchBy, string searchText, int? pageNumber, string sortBy)
        {
            ViewBag.NameSort = String.IsNullOrEmpty(sortBy) ? "Name desc" : "";
            ViewBag.GenderSort = sortBy == "Gender" ? "Gender desc" : "Gender";

            List<Gamer> gamers = await db.Gamers.ToListAsync();
            if (searchBy == "Gender")
            {
                gamers = await db.Gamers
                    .Where(x => x.Gender == searchText || searchText == null)
                    .ToListAsync();
            }
            if (searchBy == "Name")
            {
                gamers = await db.Gamers
                    .Where(x => x.Name.Contains(searchText) || searchText == null)
                    .ToListAsync();
            }

            IOrderedEnumerable<Gamer> gamersOrderedEnumerable;
            switch (sortBy)
            {
                case "Name desc":
                    gamersOrderedEnumerable = gamers.OrderByDescending(x => x.Name);
                    break;
                case "Gender desc":
                    gamersOrderedEnumerable = gamers.OrderByDescending(x => x.Gender);
                    break;
                case "Gender":
                    gamersOrderedEnumerable = gamers.OrderBy(x => x.Gender);
                    break;
                default:
                    gamersOrderedEnumerable = gamers.OrderBy(x => x.Name);
                    break;
            }

            //1.
            //The first parameter is pagenumber
            //pageNumber ?? 1 means if the pageNumber==null, then pageNumber==1
            //2.
            //The 2nd parameter is page size.
            //We set page size is 5.

            //IPagedList<Gamer> gamerPagedList = gamers.ToPagedList(pageNumber ?? 1, 5);
            IPagedList<Gamer> gamerPagedList = gamersOrderedEnumerable.ToPagedList(pageNumber ?? 1, 5);

            ViewBag.ServerTime = DateTime.Now.ToString(CultureInfo.InvariantCulture);
            return View(gamerPagedList);
        }

        //From T013
        [HttpPost]
        public async Task<ActionResult> DeleteMultiple(IEnumerable<int> GamerIdsToDelete, string searchBy, string searchText, int? pageNumber, string sortBy)
        {
            //Delete a list of gamers
            List<Gamer> gamers = await db.Gamers.Where(g => GamerIdsToDelete.Contains(g.Id)).ToListAsync();
            gamers.ForEach(g => db.Gamers.Remove(g));
            await db.SaveChangesAsync();


            //Remove OutputCache
            //Reference:
            //http://www.c-sharpcorner.com/code/1994/how-to-clear-output-cache-in-asp-net-mvc.aspx
            //https://forums.asp.net/t/2077235.aspx?How+to+clear+OutPutCache+Asp+net+Mvc
            //1. Get the url for the action method:
            string staleItem = Url.Action("Index6", "Gamer");
            //2. Remove the item from cache
            if (staleItem != null) Response.RemoveOutputCacheItem(staleItem);

            return RedirectToAction("Index6", new { searchBy, searchText, pageNumber, sortBy });
        }


        [HttpGet]
        //[OutputCache(Duration = 10, VaryByParam = "None", Location = OutputCacheLocation.None)]
        //[OutputCache(Duration = 10, VaryByParam = "None", Location= OutputCacheLocation.Server)]
        [OutputCache(Duration = 10, VaryByParam = "None", Location = OutputCacheLocation.ServerAndClient)]
        public ActionResult Index7()
        {
            ViewBag.ServerTime = DateTime.Now.ToString(CultureInfo.InvariantCulture);
            return View();
        }


        // GET: Gamer/Details/5
        [HttpGet]
        public async Task<ActionResult> Details(int? id)
        {
            if (id == null)
            {
                return new HttpStatusCodeResult(HttpStatusCode.BadRequest);
            }
            Gamer gamer = await db.Gamers.FindAsync(id);
            if (gamer == null)
            {
                return HttpNotFound();
            }
            return View(gamer);
        }

        // GET: Gamer/Create
        [HttpGet]
        public ActionResult Create()
        {
            return View();
        }

        // POST: Gamer/Create
        // To protect from overposting attacks, please enable the specific properties you want to bind to, for 
        // more details see https://go.microsoft.com/fwlink/?LinkId=317598.
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<ActionResult> Create([Bind(Include = "Id,Name,Gender,EmailAddress")] Gamer gamer)
        {
            if (ModelState.IsValid)
            {
                db.Gamers.Add(gamer);
                await db.SaveChangesAsync();
                return RedirectToAction("Index");
            }

            return View(gamer);
        }

        // GET: Gamer/Edit/5
        [HttpGet]
        public async Task<ActionResult> Edit(int? id)
        {
            if (id == null)
            {
                return new HttpStatusCodeResult(HttpStatusCode.BadRequest);
            }
            Gamer gamer = await db.Gamers.FindAsync(id);
            if (gamer == null)
            {
                return HttpNotFound();
            }
            return View(gamer);
        }

        // POST: Gamer/Edit/5
        // To protect from overposting attacks, please enable the specific properties you want to bind to, for 
        // more details see https://go.microsoft.com/fwlink/?LinkId=317598.
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<ActionResult> Edit([Bind(Include = "Id,Name,Gender,EmailAddress")] Gamer gamer)
        {
            if (ModelState.IsValid)
            {
                db.Entry(gamer).State = EntityState.Modified;
                await db.SaveChangesAsync();
                return RedirectToAction("Index");
            }
            return View(gamer);
        }

        // GET: Gamer/Delete/5
        [HttpGet]
        public async Task<ActionResult> Delete(int? id)
        {
            if (id == null)
            {
                return new HttpStatusCodeResult(HttpStatusCode.BadRequest);
            }
            Gamer gamer = await db.Gamers.FindAsync(id);
            if (gamer == null)
            {
                return HttpNotFound();
            }
            return View(gamer);
        }

        // POST: Gamer/Delete/5
        [HttpPost, ActionName("Delete")]
        [ValidateAntiForgeryToken]
        public async Task<ActionResult> DeleteConfirmed(int id)
        {
            Gamer gamer = await db.Gamers.FindAsync(id);
            db.Gamers.Remove(gamer);
            await db.SaveChangesAsync();
            return RedirectToAction("Index");
        }

        protected override void Dispose(bool disposing)
        {
            if (disposing)
            {
                db.Dispose();
            }
            base.Dispose(disposing);
        }
    }
}

/*
1.
//[HttpGet]
//[OutputCache(Duration = 10)]
//public async Task<ActionResult> Index2()
//{
//    System.Threading.Thread.Sleep(3000);
//    return View(await db.Gamers.ToListAsync());
//}
1.1.
When we first time navigate to /Gamer/Index2,
It will take 3 seconds to retrieve the list of data.
The view output cache will remain for 10 seconds.
If we refresh the view during that 10 seconds, 
we will get the data from cached response.
After that 10 seconds, the cache will be expired.
If you navigate to /Gamer/Index2 again, 
The view output cache will remain for another 10 seconds again.

------------------------------------------
2.
// GET: Gamer
//[HttpGet]
//public async Task<ActionResult> Index3()
//{
//    return View(await db.Gamers.ToListAsync());
//}
...
//[HttpGet]
//[ChildActionOnly]
//[OutputCache(Duration = 10)]
//public string GetGamerCount()
//{
//    System.Threading.Thread.Sleep(3000);
//    return $"Gamer Count = {db.Gamers.Count()} At {DateTime.Now}";
//}
2.1.
[ChildActionOnly] make the action to be accessible only by a child request,
so no one can make a direct URL request to this action.
2.2.
In the Views/Gamer/Index3.cshtml
//@Html.Action("GetGamerCount")
This action will store the result in the cache for 10 seconds.
If we refresh the view during that 10 seconds, 
we will get the data from cached response.
After that 10 seconds, the cache will be expired.
This action will store the result in the cache for another 10 seconds again.
2.3.
In the Views/Gamer/Index3.cshtml
and the In the Views/Gamer/Index3V2.cshtml.
It takes 3 seconds load Gamer/Index3 for the first time.
Now, navigate to Gamer/Index3V2 and notice it loads instantly.
We notice that the server time of the GetGamerCount action in both views is the same.
It proves that both views are sharing the same cached response of the GetGamerCount action.

------------------------------------------
3.
////[OutputCache(Duration = 5, VaryByParam = "none")]
//[OutputCache(Duration = 60, VaryByParam = "gamerName")]
//public ActionResult Index5(string gamerName)
//{
//    ViewBag.GamerName = gamerName ?? string.Empty;
//    return View();
//}
3.1.
When the action has no [HttpGet] or [HttpPost],
that means it can be booth [HttpGet] and [HttpPost] action.
3.2.
In the Views/Gamer/Index3.cshtml
//<b>@ViewBag.GamerName</b>.
//<input type="text" name="gamerName"/>
the ViewBag.GamerName will display whatever you type in the textbox.
3.3.
//[OutputCache(Duration = 5, VaryByParam = "none")]
When we first time navigate to /Gamer/Index5,
The view output cache will remain for 5 seconds.
In the Views/Gamer/Index3.cshtml
//<b>@ViewBag.GamerName</b>.
//<input type="text" name="gamerName"/>
the ViewBag.GamerName will display whatever you type in the textbox for the first time.
During that 5 seconds, no matter what you input to that text textbox,
ViewBag.GamerName will remain the same as you input for the first time.
After that 5 seconds, the cache will be expired.
the ViewBag.GamerName will display whatever you type in the textbox again.
The way to fix this issue is using
//[OutputCache(Duration = 60, VaryByParam = "gamerName")]
3.4.
//[OutputCache(Duration = 60, VaryByParam = "gamerName")]
In the Views/Gamer/Index3.cshtml
//<b>@ViewBag.GamerName</b>.
//<input type="text" name="gamerName"/>
the ViewBag.GamerName will display whatever you type in the textbox.
Since "VaryByParam" is set to "gamerName",
All different responses will be cached for this Web form

------------------------------------------
4.
//[OutputCache(Duration = 10, VaryByParam = "None", Location = OutputCacheLocation.ServerAndClient)]
//public ActionResult Index7()
4.1.
There are 3 locations option can store the cached response, Server, Client, and Proxy server.
4.1.1.
//OutputCacheLocation.Any
By default, cached response is at any available locations.
4.1.2.
//OutputCacheLocation.Client
4.1.3.
OutputCacheLocation.Downstream
Any HTTP 1.1 devices which includes proxy servers.
4.1.4.
//OutputCacheLocation.None
Do not store cache.
4.1.5.
//OutputCacheLocation.Server
4.1.6.
//OutputCacheLocation.ServerAndClient
*/
