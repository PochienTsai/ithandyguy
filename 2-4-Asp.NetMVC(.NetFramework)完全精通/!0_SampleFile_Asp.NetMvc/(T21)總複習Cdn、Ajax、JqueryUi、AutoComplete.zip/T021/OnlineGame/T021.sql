--1. Drop if it exists
--Drop Table if it exists.
IF ( EXISTS ( SELECT    *
              FROM      INFORMATION_SCHEMA.TABLES
              WHERE     TABLE_NAME = 'Gamer' ) )
    BEGIN
        TRUNCATE TABLE Gamer;
        DROP TABLE Gamer;
    END;
GO -- Run the previous command and begins new batch


--2. Create Tables
CREATE TABLE Gamer
    (
      Id INT PRIMARY KEY
             IDENTITY(1, 1)
             NOT NULL ,
      [Name] NVARCHAR(100) NOT NULL ,
      Gender NVARCHAR(10) NOT NULL ,
      Score INT NOT NULL ,
      GameMoney INT NOT NULL,
    );
GO -- Run the previous command and begins new batch


--3. Insert Data
INSERT  Gamer
VALUES  ( N'NameOne ABB', N'Male', 3500, 1000 );
INSERT  Gamer
VALUES  ( N'NameTwo CDDE', N'Female', 1500, 3500 );
INSERT  Gamer
VALUES  ( N'NameThree FIJK', N'Female', 4000, 2500 );
INSERT  Gamer
VALUES  ( N'NameFour LMOPPQ', N'Male', 2500, 2500 );
INSERT  Gamer
VALUES  ( N'NameFive QRSTT', N'Male', 3500, 2500 );
INSERT  Gamer
VALUES  ( N'NameSix TUVVX', N'Female', 2500, 3500 );
INSERT  Gamer
VALUES  ( N'NameSeven XYZZXX', N'Female', 4550, 4000 );
INSERT  Gamer
VALUES  ( N'NameEight ABBCDE', N'Male', 3550, 2500 );
INSERT  Gamer
VALUES  ( N'NameNine QRSTTUVXX', N'Male', 2510, 3500 );
INSERT  Gamer
VALUES  ( N'NameTen AASSVV', N'Male', 3560, 2600 );
INSERT  Gamer
VALUES  ( N'NameEleven TTBBDD', N'Female', 2650, 1500 );
INSERT  Gamer
VALUES  ( N'NameTwelve GHSDSWE', N'Male', 4580, 1234 );
INSERT  Gamer
VALUES  ( N'NameThirteen FSWC', N'Male', 5800, 3500 );
INSERT  Gamer
VALUES  ( N'NameFourteen QWDEC', N'Male', 1200, 6500 );
INSERT  Gamer
VALUES  ( N'NameFifteen SSDBV', N'Male', 2300, 4200 );
INSERT  Gamer
VALUES  ( N'NameSixteen TTNSD', N'Male', 44500, 3500 );
INSERT  Gamer
VALUES  ( N'NameSeventeen MGFD', N'Female', 2100, 1200 );
INSERT  Gamer
VALUES  ( N'NameEighteen MGFD', N'Female', 2100, 1200 );
INSERT  Gamer
VALUES  ( N'NameNineteen DBTC', N'Female', 2600, 3500 );
INSERT  Gamer
VALUES  ( N'NameTwenty YUKFD', N'Male', 3600, 2600 );
GO -- Run the previous command and begins new batch
