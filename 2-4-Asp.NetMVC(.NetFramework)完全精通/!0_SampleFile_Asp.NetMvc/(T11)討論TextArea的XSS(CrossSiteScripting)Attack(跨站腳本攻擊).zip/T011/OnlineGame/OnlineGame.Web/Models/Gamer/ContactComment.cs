﻿using System.ComponentModel.DataAnnotations;

namespace OnlineGame.Web.Models
{
    [MetadataType(typeof(ContactCommentMetaData))]
    public partial class ContactComment
    {
    }
}

