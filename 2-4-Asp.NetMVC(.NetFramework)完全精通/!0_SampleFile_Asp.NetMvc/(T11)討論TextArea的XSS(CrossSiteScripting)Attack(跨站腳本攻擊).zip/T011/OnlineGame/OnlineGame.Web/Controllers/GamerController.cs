﻿using System.Data.Entity;
using System.Threading.Tasks;
using System.Net;
using System.Text;
using System.Web;
using System.Web.Mvc;
using OnlineGame.Web.Models;

namespace OnlineGame.Web.Controllers
{
    public class GamerController : Controller
    {
        private OnlineGameContext db = new OnlineGameContext();

        // GET: Gamer
        public async Task<ActionResult> Index()
        {
            return View(await db.ContactComments.ToListAsync());
        }

        // GET: Gamer/Details/5
        public async Task<ActionResult> Details(int? id)
        {
            if (id == null)
            {
                return new HttpStatusCodeResult(HttpStatusCode.BadRequest);
            }
            ContactComment contactComment = await db.ContactComments.FindAsync(id);
            if (contactComment == null)
            {
                return HttpNotFound();
            }
            return View(contactComment);
        }

        // GET: Gamer/Create
        public ActionResult Create()
        {
            return View();
        }

        // POST: Gamer/Create
        // To protect from overposting attacks, please enable the specific properties you want to bind to, for 
        // more details see https://go.microsoft.com/fwlink/?LinkId=317598.
        [HttpPost]
        [ValidateAntiForgeryToken]
        [ValidateInput(false)]
        public async Task<ActionResult> Create([Bind(Include = "Id,Name,CommentText")] ContactComment contactComment)
        {
            if (!ModelState.IsValid)
                return View(contactComment);

            StringBuilder sbCommentText = new StringBuilder();

            // HTML Encode the CommentText
            sbCommentText.Append(HttpUtility.HtmlEncode(contactComment.CommentText));

            // Decode <b> and <u>
            sbCommentText.Replace("&lt;b&gt;", "<b>");
            sbCommentText.Replace("&lt;/b&gt;", "</b>");
            sbCommentText.Replace("&lt;u&gt;", "<u>");
            sbCommentText.Replace("&lt;/u&gt;", "</u>");
            contactComment.CommentText = sbCommentText.ToString();

            // HTML Encode the Name
            string strEncodedName = HttpUtility.HtmlEncode(contactComment.Name);
            contactComment.Name = strEncodedName;

            db.ContactComments.Add(contactComment);
            await db.SaveChangesAsync();
            return RedirectToAction("Index");
        }

        // GET: Gamer/Edit/5
        public async Task<ActionResult> Edit(int? id)
        {
            if (id == null)
            {
                return new HttpStatusCodeResult(HttpStatusCode.BadRequest);
            }
            ContactComment contactComment = await db.ContactComments.FindAsync(id);
            if (contactComment == null)
            {
                return HttpNotFound();
            }
            return View(contactComment);
        }

        // POST: Gamer/Edit/5
        // To protect from overposting attacks, please enable the specific properties you want to bind to, for 
        // more details see https://go.microsoft.com/fwlink/?LinkId=317598.
        [HttpPost]
        [ValidateAntiForgeryToken]
        [ValidateInput(false)]
        public async Task<ActionResult> Edit([Bind(Include = "Id,Name,CommentText")] ContactComment contactComment)
        {
            if (!ModelState.IsValid)
                return View(contactComment);

            StringBuilder sbCommentText = new StringBuilder();

            // HTML Encode the CommentText
            sbCommentText.Append(HttpUtility.HtmlEncode(contactComment.CommentText));

            // Decode <b> and <u>
            sbCommentText.Replace("&lt;b&gt;", "<b>");
            sbCommentText.Replace("&lt;/b&gt;", "</b>");
            sbCommentText.Replace("&lt;u&gt;", "<u>");
            sbCommentText.Replace("&lt;/u&gt;", "</u>");
            contactComment.CommentText = sbCommentText.ToString();

            // HTML Encode the Name
            string strEncodedName = HttpUtility.HtmlEncode(contactComment.Name);
            contactComment.Name = strEncodedName;

            db.Entry(contactComment).State = EntityState.Modified;
            await db.SaveChangesAsync();
            return RedirectToAction("Index");
        }

        // GET: Gamer/Delete/5
        public async Task<ActionResult> Delete(int? id)
        {
            if (id == null)
            {
                return new HttpStatusCodeResult(HttpStatusCode.BadRequest);
            }
            ContactComment contactComment = await db.ContactComments.FindAsync(id);
            if (contactComment == null)
            {
                return HttpNotFound();
            }
            return View(contactComment);
        }

        // POST: Gamer/Delete/5
        [HttpPost, ActionName("Delete")]
        [ValidateAntiForgeryToken]
        public async Task<ActionResult> DeleteConfirmed(int id)
        {
            ContactComment contactComment = await db.ContactComments.FindAsync(id);
            db.ContactComments.Remove(contactComment);
            await db.SaveChangesAsync();
            return RedirectToAction("Index");
        }

        protected override void Dispose(bool disposing)
        {
            if (disposing)
            {
                db.Dispose();
            }
            base.Dispose(disposing);
        }
    }
}
