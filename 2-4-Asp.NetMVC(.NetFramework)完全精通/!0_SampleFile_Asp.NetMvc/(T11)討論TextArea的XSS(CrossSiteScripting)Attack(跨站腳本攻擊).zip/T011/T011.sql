--1. Drop if it exists
--Drop Table if it exists.
IF ( EXISTS ( SELECT    *
              FROM      INFORMATION_SCHEMA.TABLES
              WHERE     TABLE_NAME = 'ContactComment' ) )
    BEGIN
        TRUNCATE TABLE ContactComment;
        DROP TABLE ContactComment;
    END;
GO -- Run the previous command and begins new batch


--2. Create Table
CREATE TABLE ContactComment 
(
   Id INT PRIMARY KEY
             IDENTITY(1, 1)
             NOT NULL ,
   [Name] NVARCHAR(100) NULL ,
   CommentText NVARCHAR(500) NULL
) 


--3. Insert Data
INSERT  ContactComment
VALUES  ( N'Name1', N'The comment text from Name1' );
INSERT  ContactComment
VALUES  ( N'Name2', N'The comment text from Name2' );
INSERT  ContactComment
VALUES  ( N'Name3', N'The comment text from Name3' );


--EXEC spGetGamers
--GO -- Run the previous command and begins new batch