﻿using System.Web.Mvc;
namespace OnlineGame.Web.Areas.Gamer.Controllers
{
    public class HomeController : Controller
    {
        // GET: Gamer/Home
        [HttpGet]
        public ActionResult Index()
        {
            return View();
        }
    }
}