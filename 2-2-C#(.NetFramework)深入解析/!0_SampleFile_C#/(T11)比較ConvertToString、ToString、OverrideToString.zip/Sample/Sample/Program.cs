﻿using System;
using OnLineGame;

namespace Sample
{
    class Program
    {
        static void Main(string[] args)
        {
            // 1. -----------------------------
            int i1 = 1;
            Console.WriteLine(i1.ToString());
            //1

            // 2. -----------------------------
            // reason to override ToString()
            GamerA gA1 = new GamerA();
            gA1.FirstName = "F01";
            gA1.LastName = "L01";
            Console.WriteLine(gA1.ToString());
            // OnLineGame.GamerA

            // 3. -----------------------------
            Gamer g1 = new Gamer();
            g1.FirstName = "F01";
            g1.LastName = "L01";
            Console.WriteLine(g1.ToString());
            //F01 L02
            g1 = null;
            try
            {
                Console.WriteLine(g1.ToString());
            }
            catch (Exception ex)
            {
                Console.WriteLine("Exception : {0} \nMessage : {1} \nStackTrace : {2} \n", ex.GetType().Name, ex.Message, ex.StackTrace);
            }
            //Exception: NullReferenceException
            //Message : Object reference not set to an instance of an object.
            //StackTrace :    at Sample.Program.Main(String[] args) in d:\0_mydocument\documents\visual studio 2017\Projects\Sample\Sample\Program.cs:line 36


            // 4. -----------------------------
            //Convert.ToString(variable) return string.Empty when variable== null;
            //variable.ToString throws a NULL Reference exception when variable== null;
            Gamer g2 = new Gamer();
            g2.FirstName = "F02";
            g2.LastName = "L02";
            Console.WriteLine(Convert.ToString(g2));
            //F02 L02
            g2 = null;
            Console.WriteLine(Convert.ToString(g2) == string.Empty ? 
                "NULL" : 
                Convert.ToString(g2));
            //NULL


            Console.ReadLine();
        }
    }
}

namespace OnLineGame
{
    public class GamerA
    {
        public string FirstName { get; set; }
        public string LastName { get; set; }
    }

    public class Gamer
    {
        public string FirstName { get; set; }
        public string LastName { get; set; }

        public override string ToString()
        {
            return $"{FirstName} {LastName}";
        }
    }
}

/*
Convert.ToString(variable) return string.Empty when variable==null;
variable.ToString throws a NULL Reference exception when variable==null;
*/
