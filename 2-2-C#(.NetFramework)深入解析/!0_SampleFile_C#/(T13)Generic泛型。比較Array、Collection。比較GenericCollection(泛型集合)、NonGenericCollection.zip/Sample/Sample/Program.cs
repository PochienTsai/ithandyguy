﻿using System;
using System.Collections;
using System.Collections.Generic;

namespace Sample
{
    class Program
    {
        static void Main(string[] args)
        {
            // 1. ------------------------------------
            Console.WriteLine("AreEqual(int i1, int i2) ===================================");
            Console.WriteLine($"GenericSample.AreEqual(1,1)  :  {GenericSample.AreEqual(1, 1)}");
            Console.WriteLine("AreEqual(double d1, double d2) ===================================");
            Console.WriteLine($"GenericSample.AreEqual(2.0, 2.0)  :  {GenericSample.AreEqual(2.0, 2.0)}");
            Console.WriteLine("AreEqual(string obj1, string obj2) ===================================");
            Console.WriteLine($"GenericSample.AreEqual(\"AA\", \"AA\")  :  {GenericSample.AreEqual("AA", "AA")}");
            // It need different AreEqual() methods to handle different type of inputs.
            // The logic of AreEqual() method are not reusable.

            // 2. ------------------------------------
            Console.WriteLine("AreEqualObj(object obj1, object obj2) ===================================");
            Console.WriteLine($"GenericSample.AreEqualObj(\"AA\", \"AA\")  :  {GenericSample.AreEqualObj("AA", "AA")}");
            // Using "object" type can reuse the logic of AreEqualObj(object obj1, object obj2) method,
            // but it allows users to pass int to obj1 and string to obj2.
            // Thus, AreEqualObj() method is not type safe.
            // In addition, AreEqualObj() reduce the performance,
            // because it needs an extra action 
            // that coverting object type to other type in order to do comparation.

            // 3. ------------------------------------
            Console.WriteLine(@"AreEqualGeneric<T>(T obj1, T obj2) ===================================");
            Console.WriteLine($"GenericSample.AreEqualGeneric(\"AA\", \"AA\")  :  " +
                              $"{GenericSample.AreEqualGeneric("AA", "AA")}");
            Console.WriteLine($"GenericSample.AreEqualGeneric<string>(\"AA\", \"AA\")  :  " +
                              $"{GenericSample.AreEqualGeneric<string>("AA", "AA")}");
            Console.WriteLine($"GenericSample.AreEqualGeneric(1,1)  :  " +
                              $"{GenericSample.AreEqualGeneric(1, 1)}");
            Console.WriteLine($"GenericSample.AreEqualGeneric<int>(1,1)  :  " +
                              $"{GenericSample.AreEqualGeneric<int>(1, 1)}");
            Console.WriteLine($"GenericSample.AreEqualGeneric(2.0, 2.0)  :  " +
                              $"{GenericSample.AreEqualGeneric(2.0, 2.0)}");
            Console.WriteLine($"GenericSample.AreEqualGeneric<double>(2.0, 2.0)  :  " +
                              $"{GenericSample.AreEqualGeneric<double>(2.0, 2.0)}");
            // Using Generic type can reuse the logic of AreEqualGeneric<T>(T obj1, T obj2) method,
            // The users have to pass the type to T in order to use generic method.
            // It makes parameters become type safe, 
            // and also doesn't need to an extra converting.
            // T can be Class type or Interface type.

            // 4. ------------------------------------
            Console.WriteLine(@"ArraySample() ===================================");
            GenericSample.ArraySample();

            // 5. ------------------------------------
            Console.WriteLine(@"ArrayListSample() ===================================");
            GenericSample.ArrayListSample();

            // 6. ------------------------------------
            Console.WriteLine(@"GenericListSample() ===================================");
            GenericSample.GenericListSample();

            Console.ReadLine();
        }
    }

    public class GenericSample
    {
        // 1. ------------------------------------
        public static bool AreEqual(int i1, int i2)
        {
            return i1 == i2;
        }

        public static bool AreEqual(double d1, double d2)
        {
            return d1.Equals(d2);
        }

        public static bool AreEqual(string str1, string str2)
        {
            return str1.Equals(str2);
        }

        // 2. ------------------------------------
        public static bool AreEqualObj(object obj1, object obj2)
        {
            return obj1.Equals(obj2);
        }

        // 3. ------------------------------------
        public static bool AreEqualGeneric<T>(T obj1, T obj2)
        {
            return obj1.Equals(obj2);
        }

        // 4. ------------------------------------
        public static void ArraySample()
        {
            int[] intArr = new int[3];
            intArr[0] = 1;
            intArr[1] = 2;
            intArr[2] = 3;
            //intArr[3] = 4;  // RunTime Error

            for (int i = 0; i<intArr.Length ; i++)
            {
                Console.WriteLine($"intArr[{i}] == {intArr[i]}");
            }
            //Array is strongly typed and type safe.
            //Index starts from 0 and
            //the size can not be increased once initialized.
        }

        // 5. ------------------------------------
        public static void ArrayListSample()
        {
            ArrayList arrList = new ArrayList();
            arrList.Add(1);
            arrList.Add(2);
            arrList.Add(3);
            arrList.Add(4);
            arrList.Add("AA");  // not type safe

            for (int i = 0; i < arrList.Count; i++)
            {
                Console.WriteLine($"arrList[{i}] == {arrList[i]}");
            }
            //Collection is not Strongly Type and not Type safe.
            //But the size can be increased by using Add()
            //or can be decreased by using Remove().
        }

        // 6. ------------------------------------
        public static void GenericListSample()
        {
            List<int> list = new List<int>();
            list.Add(1);
            list.Add(2);
            list.Add(3);
            list.Add(4);
            //list.Add("AA"); // compiler error, generic is type safe.

            for (int i = 0; i < list.Count; i++)
            {
                Console.WriteLine($"list[{i}] == {list[i]}");
            }
            //Generic Collections is always better.
            //Generic Collections is type safe, 
            //and the size can be changeable by using Add(), Remove...etc.
        }
    }
}

/*
1.
Array V.S. Collection(E.g. ArrayList, Hashtable ...etc.)
1.1.
Array is strongly typed and type safe.  
Index starts from 0 and 
the size can not be increased once initialized.
1.2.
Collection is not Strongly Type and not Type safe.
But the size can be increased by using Add()
or can be decreased by using Remove().

--------------------------------------------------
2.
Generic Collection V.S. Non-Generic Collection.
2.1.
Generic Collections (System.Collections.Generic)
includes List<T>, Dictionary<TKey, TValue>, Stack<T>, Queue<T>
2.2.
Non-Generic Collection (System.Collections)
includes ArrayList, Hashtable, Stack, Queue.
2.3.
Generic Collections is always better.
Generic Collections is type safe, 
and the size can be changeable by using Add(), Remove ...etc.
*/
