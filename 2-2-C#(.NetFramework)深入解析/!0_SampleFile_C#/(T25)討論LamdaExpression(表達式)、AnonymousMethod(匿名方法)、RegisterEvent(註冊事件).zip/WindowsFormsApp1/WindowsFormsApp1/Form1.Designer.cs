﻿namespace WindowsFormsApp1
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.btnClickMe = new System.Windows.Forms.Button();
            this.btnClickMe2 = new System.Windows.Forms.Button();
            this.btnClickMe3 = new System.Windows.Forms.Button();
            this.btnClickMe4 = new System.Windows.Forms.Button();
            this.btnClickMe5 = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // btnClickMe
            // 
            this.btnClickMe.Location = new System.Drawing.Point(12, 12);
            this.btnClickMe.Name = "btnClickMe";
            this.btnClickMe.Size = new System.Drawing.Size(140, 35);
            this.btnClickMe.TabIndex = 0;
            this.btnClickMe.Text = "Btn";
            this.btnClickMe.UseVisualStyleBackColor = true;
            // 
            // btnClickMe2
            // 
            this.btnClickMe2.Location = new System.Drawing.Point(170, 12);
            this.btnClickMe2.Name = "btnClickMe2";
            this.btnClickMe2.Size = new System.Drawing.Size(168, 35);
            this.btnClickMe2.TabIndex = 1;
            this.btnClickMe2.Text = "Btn";
            this.btnClickMe2.UseVisualStyleBackColor = true;
            // 
            // btnClickMe3
            // 
            this.btnClickMe3.Location = new System.Drawing.Point(356, 12);
            this.btnClickMe3.Name = "btnClickMe3";
            this.btnClickMe3.Size = new System.Drawing.Size(168, 35);
            this.btnClickMe3.TabIndex = 2;
            this.btnClickMe3.Text = "Btn";
            this.btnClickMe3.UseVisualStyleBackColor = true;
            // 
            // btnClickMe4
            // 
            this.btnClickMe4.Location = new System.Drawing.Point(12, 70);
            this.btnClickMe4.Name = "btnClickMe4";
            this.btnClickMe4.Size = new System.Drawing.Size(140, 35);
            this.btnClickMe4.TabIndex = 3;
            this.btnClickMe4.Text = "Btn";
            this.btnClickMe4.UseVisualStyleBackColor = true;
            // 
            // btnClickMe5
            // 
            this.btnClickMe5.Location = new System.Drawing.Point(170, 70);
            this.btnClickMe5.Name = "btnClickMe5";
            this.btnClickMe5.Size = new System.Drawing.Size(140, 35);
            this.btnClickMe5.TabIndex = 4;
            this.btnClickMe5.Text = "Btn";
            this.btnClickMe5.UseVisualStyleBackColor = true;
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(9F, 20F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(577, 413);
            this.Controls.Add(this.btnClickMe5);
            this.Controls.Add(this.btnClickMe4);
            this.Controls.Add(this.btnClickMe3);
            this.Controls.Add(this.btnClickMe2);
            this.Controls.Add(this.btnClickMe);
            this.Name = "Form1";
            this.Text = "Form1";
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Button btnClickMe;
        private System.Windows.Forms.Button btnClickMe2;
        private System.Windows.Forms.Button btnClickMe3;
        private System.Windows.Forms.Button btnClickMe4;
        private System.Windows.Forms.Button btnClickMe5;
    }
}

