﻿using System;
using System.Windows.Forms;

namespace WindowsFormsApp1
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();

            btnClickMe.Text = "btnClickMe";
            btnClickMe.Click += new EventHandler(btnClickMe_Click);

            btnClickMe2.Text = "btnClickMe2";
            btnClickMe2.Click += btnClickMe2_Click;

            btnClickMe3.Text = "btnClickMe3";
            btnClickMe3.Click += delegate (object obj, EventArgs eventArgs)
            {
                MessageBox.Show("btnClickMe3 Clicked");
            };

            //This sample of anonymous method omit parameters
            //because the body does not use these parameters.
            btnClickMe4.Text = "btnClickMe4";
            btnClickMe4.Click += delegate {
                MessageBox.Show("btnClickMe4 Clicked");
            };

            //Lambda expression can never omit parameters
            //no matter the body use these parameters or not.
            btnClickMe5.Text = "btnClickMe5";
            btnClickMe5.Click += (sender, args) => MessageBox.Show("btnClickMe5 Clicked");
        }

        void btnClickMe_Click(object sender, EventArgs e)
        {
            MessageBox.Show("btnClickMe Clicked");
        }

        void btnClickMe2_Click(object sender, EventArgs e)
        {
            MessageBox.Show("btnClickMe2 Clicked");
        }

    }
}
