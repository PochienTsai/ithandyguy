﻿namespace OnLineGameA
{
    public class GamerA
    {
        // private field means only available in current class.
        private int _gameScore = 500;
        // protected field means available in current class and its sub class.
        protected internal int _level = 2;

        // public property means available every where.
        public int GameScore
        {
            get
            {
                return _gameScore;
            }
            set
            {
                _gameScore = value;
            }
        }
    }

    //Internal means only available in current assembly.
    public class GamerASub : GamerA
    {
        // public property means available every where.
        public int Level
        {
            get
            {
                return _level;
                // Sub Class can access the protected field from base class.
            }
            set
            {
                _level = value;
            }
        }

        // Protected internal method means only available in current assembly, and its sub class. 
        protected internal int GetGameScore()
        {
            ////return base._gameScore;
            //  base._gameScore is private, thus, not available in its sub class.
            return GameScore;
        }
    }
}

