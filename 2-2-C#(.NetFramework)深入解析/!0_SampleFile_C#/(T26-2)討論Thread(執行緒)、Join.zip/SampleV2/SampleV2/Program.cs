﻿using System;
using System.Threading;

namespace SampleV2
{
    class Program
    {
        static void Main(string[] args)
        {
            //5. =========================================================
            //Thread Join()
            ////5.1. -----------------------------------------------------
            Console.WriteLine("5.1. ThreadJoin1(); A.Start();A.Join();B.Start();B.Join(); =================");
            ThreadJoin1();
            //5.2. -----------------------------------------------------
            Console.WriteLine("5.2. ThreadJoin2(); A.Start();B.Start();A.Join();B.Join(); =================");
            ThreadJoin2();
            Console.ReadLine();
        }


        //1. =========================================================
        //No Task, No Thread
        static void slowMethodA()
        {
            Console.WriteLine("beginning of slowMethodA()");
            // Sleep for N million seconds.
            Thread.Sleep(1999);
            Console.WriteLine("End of slowMethodA()");
        }
        static void slowMethodB()
        {
            Console.WriteLine("beginning of slowMethodB()");
            // Sleep for N million seconds.
            Thread.Sleep(2000);
            Console.WriteLine("End of slowMethodB()");
        }


        //5. =========================================================
        //Thread Join()
        static void ThreadJoin1()
        {
            Console.WriteLine("Beginning of ThreadJoin1() ----------------- ");
            Thread slowMethodAThread = new Thread(slowMethodA);
            Thread slowMethodBThread = new Thread(slowMethodB);
            slowMethodAThread.Start();
            slowMethodAThread.Join();
            slowMethodBThread.Start();
            slowMethodBThread.Join();
            Console.WriteLine("End of ThreadJoin1() ----------------- ");
        }


        static void ThreadJoin2()
        {
            Console.WriteLine("Beginning of ThreadJoin2() ----------------- ");
            Thread slowMethodAThread = new Thread(slowMethodA);
            Thread slowMethodBThread = new Thread(slowMethodB);
            slowMethodAThread.Start();
            slowMethodBThread.Start();
            slowMethodAThread.Join();
            slowMethodBThread.Join();
            Console.WriteLine("End of ThreadJoin2() ----------------- ");
        }
    }
}

/*
5.1. ThreadJoin1(); A.Start();A.Join();B.Start();B.Join(); =================
Beginning of ThreadJoin1() -----------------
beginning of slowMethodA()
End of slowMethodA()
beginning of slowMethodB()
End of slowMethodB()
End of ThreadJoin1() -----------------
5.2. ThreadJoin2(); A.Start();B.Start();A.Join();B.Join(); =================
Beginning of ThreadJoin2() -----------------
beginning of slowMethodA()
beginning of slowMethodB()
End of slowMethodB()
End of slowMethodA()
End of ThreadJoin2() -----------------
*/


/*
5.1. ThreadJoin1(); A.Start();A.Join();B.Start();B.Join(); =================
Beginning of ThreadJoin1() -----------------
beginning of slowMethodA()
End of slowMethodA()
beginning of slowMethodB()
End of slowMethodB()
End of ThreadJoin1() -----------------
5.2. ThreadJoin2(); A.Start();B.Start();A.Join();B.Join(); =================
Beginning of ThreadJoin2() -----------------
beginning of slowMethodA()
beginning of slowMethodB()
End of slowMethodA()
End of slowMethodB()
End of ThreadJoin2() -----------------
*/


/*
1.
//static void ThreadJoin1()
//{
//    Console.WriteLine("Beginning of ThreadJoin1() ----------------- ");
//    Thread slowMethodAThread = new Thread(slowMethodA);
//    Thread slowMethodBThread = new Thread(slowMethodB);
//    slowMethodAThread.Start();
//    slowMethodAThread.Join();
//    slowMethodBThread.Start();
//    slowMethodBThread.Join();
//    Console.WriteLine("End of ThreadJoin1() ----------------- ");
//}
-----------------------------------------
"ThreadJoin1" is "CurrentThread"
"slowMethodAThread" is "ChildThread" of the "CurrentThread"
"slowMethodBThread" is "ChildThread" of the "CurrentThread"
----------------
//slowMethodAThread.Start();
"CurrentThread" has started first, and then "slowMethodAThread" started.
----------------
//slowMethodAThread.Join();
"slowMethodAThread" join the "CurrentThread".
It means "slowMethodAThread" has to be finished,
and then "CurrentThread" can continue.
----------------
//slowMethodBThread.Start();
While "CurrentThread" is still runing, and then "slowMethodBThread" started,
----------------
//slowMethodAThread.Join();
"slowMethodBThread" join the "CurrentThread".
It means "slowMethodBThread" has to be finished,
and then "CurrentThread" can continue.
---------------------------------
"ThreadJoin1"是"CurrentThread"(目前Thread)
"slowMethodAThread"是"CurrentThread"(目前Thread)的"ChildThread"(子Thread)
"slowMethodBThread"是"CurrentThread"(目前Thread)的"ChildThread"(子Thread)
----------------
//slowMethodAThread.Start();
"CurrentThread"先開始跑,然後"slowMethodAThread"才開始跑
----------------
//slowMethodAThread.Join();
"slowMethodAThread" join the "CurrentThread".
這意思是"slowMethodAThread"必須先結束
"CurrentThread"才可以繼續跑
----------------
//slowMethodBThread.Start();
當"CurrentThread"還在繼續跑,然後"slowMethodBThread"才開始跑
----------------
//slowMethodBThread.Join();
"slowMethodBThread" join the "CurrentThread".
這意思是"slowMethodBThread"必須先結束
"CurrentThread"才可以繼續跑
-------------------------------------------------------------------
2.
static void ThreadJoin2()
//{
//    Console.WriteLine("Beginning of ThreadJoin2() ----------------- ");
//    Thread slowMethodAThread = new Thread(slowMethodA);
//    Thread slowMethodBThread = new Thread(slowMethodB);
//    slowMethodAThread.Start();
//    slowMethodBThread.Start();
//    slowMethodAThread.Join();
//    slowMethodBThread.Join();
//    Console.WriteLine("End of ThreadJoin2() ----------------- ");
//}
-----------------------------------------
"ThreadJoin1" is "CurrentThread"
"slowMethodAThread" is "ChildThread" of the "CurrentThread"
"slowMethodBThread" is "ChildThread" of the "CurrentThread"
----------------
//slowMethodAThread.Start();
"CurrentThread" has started first, and then "slowMethodAThread" started.
----------------
//slowMethodBThread.Start();
While "CurrentThread" is still runing, and then "slowMethodBThread" started,
----------------
//slowMethodAThread.Join();
"slowMethodAThread" join the "CurrentThread".
It means "slowMethodAThread" has to be finished,
and then "CurrentThread" can continue.
However, the "slowMethodBThread" is still runing.
Therefore, "slowMethodBThread" might be finished first.
----------------
//slowMethodAThread.Join();
"slowMethodBThread" join the "CurrentThread".
It means "slowMethodBThread" has to be finished,
and then "CurrentThread" can continue.
---------------------------------
"ThreadJoin1"是"CurrentThread"(目前Thread)
"slowMethodAThread"是"CurrentThread"(目前Thread)的"ChildThread"(子Thread)
"slowMethodBThread"是"CurrentThread"(目前Thread)的"ChildThread"(子Thread)
----------------
//slowMethodAThread.Start();
"CurrentThread"先開始跑,然後"slowMethodAThread"才開始跑
----------------
//slowMethodBThread.Start();
當"CurrentThread"還在繼續跑,然後"slowMethodBThread"才開始跑
----------------
//slowMethodAThread.Join();
"slowMethodAThread" join the "CurrentThread".
這意思是"slowMethodAThread"必須先結束
"CurrentThread"才可以繼續跑
但是其實"slowMethodBThread"還在繼續跑
所以"slowMethodBThread"有可能會先結束(看運氣)
----------------
//slowMethodBThread.Join();
"slowMethodBThread" join the "CurrentThread".
這意思是"slowMethodBThread"必須先結束
"CurrentThread"才可以繼續跑
*/



