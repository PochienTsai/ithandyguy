﻿//Please set the break point at the line which contains "return" or "yield return".

using System.Collections.Generic;

namespace OnlineGame.Library
{
    public class S01IntCollection
    {
        public static List<int> intList = new List<int> { 100, 99, 98, 97, 96, 95 };

        //=======================================
        //1. GetMoreThanOrEqual

        public static IEnumerable<int> GetMoreThanOrEqual(int number)
        {
            var tempList = new List<int>();
            foreach (int i in intList)
            {
                if (i >= number)
                    tempList.Add(i);
            }
            return tempList;
        }


        public static IEnumerable<int> GetMoreThanOrEqualYied(int number)
        {
            foreach (int i in intList)
            {
                if (i >= number)
                    yield return i;
            }
        }


        //=======================================
        //2. Total

        public static int GetTotal()
        {
            int total = 0;
            foreach (var i in intList)
                total += i;
            return total;
        }


        public static IEnumerable<int> GetRunningTotal()
        {
            var tempList = new List<int>();
            int total = 0;
            foreach (var i in intList)
            {
                total += i;
                tempList.Add(total);
            }
            return tempList;
        }



        public static IEnumerable<int> GetRunningTotalYield()
        {
            //Inspect "total" variable and find out
            //the value is always preserved from the last run.
            int total = 0; 
            foreach (var i in intList)
            {
                total += i;
                yield return total;
            }
        }

    }
}

/*
1.
Yield Return
1.1.
Reference:
http://limitedcode.blogspot.com/2014/07/c-yeild.html
https://www.kenneth-truyers.net/2016/05/12/yield-return-in-c/
https://docs.microsoft.com/en-us/dotnet/csharp/language-reference/keywords/yield
https://docs.microsoft.com/zh-tw/dotnet/csharp/language-reference/keywords/yield
https://youtu.be/4fju3xcm21M
https://youtu.be/F7L9seU_mak
------------------------
1.2.
"yield return" can do custom stateful iteration over the collection.
"yield return" will return a collection. E.g. IEnumerable<T> 
-->
我們針對某個collection可以做客製化的stateful iteration
通常回傳一個collection。E.g. IEnumerable<T> 
------------------------
1.3.
Normal iteration WITHOUT yield return :
when I traverse each element in the loop, 
if I encounter an element that meets the criteria,
We usually create a temp collection 
and then add the matching elements to that temp collection.
Then we will return that temp collection.
-->
如果沒有yield return，我們通常如下作法。
我們先做一個空的temp collection
當我們iterate每個element的時候，如果哪個element有符合條件，
就加入我們的temp collection。
當loop結束後，就直接return這個temp collection。
------------------------
1.4.
iteration WITH yield return :
when I traverse each element in the loop, 
if I encounter an element that meets the criteria,
we return that ONE element back to the previous layer which is its caller.
when previous layer has done what it needs to do,
then jump back the loop and then get the next element.
有yield return的時候，我們可以如下做法。
我們"不必"做一個空的temp collection
當我們iterate每個element的時候，如果哪個element有符合條件，
我們直接"yield return"到上一層，也就是他的caller。
然後它的caller解決他該做的事情的時候，
它又jump回原本的loop然後再去看看下一個element。
-->
We repeatedly to check if the next element that meets the criteria,
then repeatedly return that ONE element back to the previous layer which is its caller.
and then repeatedly jump back to the loop to get the next element 
over and over again until the loop ends.
我們"重複地"去找下一個有符合條件的element，
然後"重複地"回傳有符合條件的element到上一層也就是它的caller。
然後"重複的"jump回原本的loop再繼續看下一個element直到該loop結束。
*/
