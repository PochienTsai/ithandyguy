﻿//Please set the break point at the line which contains "Console.WriteLine" or "S01IntCollection.GetTotal()".

using System;
using OnlineGame.Library;

namespace OnlineGame.ConsoleApp
{
    class Program
    {
        static void Main(string[] args)
        {
            //=======================================
            //1. GetMoreThanOrEqual

            //1.1.
            //Normal IEnumerable<int>
            Console.WriteLine("1.1. Normal IEnumerable<int> ============");
            foreach (int intA in S01IntCollection.GetMoreThanOrEqual(98))
            {
                Console.WriteLine(intA);
            }

            //1.2.
            //IEnumerable<int> with "yield return"
            Console.WriteLine("1.2. IEnumerable<int> with yield return ===========");
            foreach (int intB in S01IntCollection.GetMoreThanOrEqualYied(98))
            {
                Console.WriteLine(intB);
            }


            //=======================================
            //2. Total

            //2.1.
            //Normal IEnumerable<int>
            Console.WriteLine("2.1. GetTotal ============");
            int total = S01IntCollection.GetTotal();
            Console.WriteLine(total);

            Console.WriteLine("2.2. GetRunningTotal ============");
            foreach (int intA in S01IntCollection.GetRunningTotal())
            {
                Console.WriteLine(intA);
            }

            Console.WriteLine("2.3. GetRunningTotalYield ============");
            foreach (int intB in S01IntCollection.GetRunningTotalYield())
            {
                Console.WriteLine(intB);
            }

            Console.ReadLine();
        }
    }
}
