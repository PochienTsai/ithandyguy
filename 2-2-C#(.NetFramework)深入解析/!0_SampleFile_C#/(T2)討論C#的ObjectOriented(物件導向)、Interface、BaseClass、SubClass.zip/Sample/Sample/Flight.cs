﻿// Namespace is like a folder which contains some classes.
namespace Sample
{
    // a class can exten only one class and implement many Interface.
    // E.g.
    // public class ClassA : ClassB, InterfaceA, InterfaceB
    public class Flight : IAircraft, IVehicle
    {
        //--------------------------------------------------------------
        // This can be called as Class Member, Field, global variable.  
        // Most people called this as "Field".
        // Field is like a Database Table Column to store the data of the object.
        private string _type;
        private string _year;

        //--------------------------------------------------------------
        //The constructor is a special method.
        //Whenever a class or struct is created, its constructor is called
        /// <summary>
        /// The constructor of Flight. 
        /// </summary>
        /// <param name="type"></param>
        /// <param name="year"></param>
        /// <param name="currentValue"></param>
        public Flight(string type, string year, double currentValue)
        {
            _type = type;
            _year = year;   // set value dirrectly to the field
            CurrentValue = currentValue;    // set the field value by its property.
        }

        //--------------------------------------------------------------
        // Properties is special method to replace get and set.
        // Year Property can replace GetYear() and SetYear()
        public string Year
        {
            get { return _year; }
            // this is the keyword, means current object
            set { this._year = value; }
        }
        // CurrentValue Property can replace GetValue() and SetValue()
        public double CurrentValue { get; set; }
        // Make Property can replace GetMake()
        public string Type { get { return _type; } }

        //--------------------------------------------------------------
        //1.
        //Method is a set of logic processes.
        //Method is like an action which this object can do.
        //E.g. Flight can take off and land.
        //2.
        //Only virtual method can be overrided in the sub-class.

        /// <summary>
        /// IAircraft is taking off.
        /// </summary>
        /// <returns></returns>
        public virtual string TakingOff()
        {
            return "Flight is taking off.";
        }

        /// <summary>
        /// IAircraft is landing.
        /// </summary>
        /// <returns></returns>
        public virtual string Landing()
        {
            return "Flight is landing.";
        }

        /// <summary>
        /// IVehicle is moving
        /// </summary>
        /// <returns></returns>
        public string Moving()
        {
            return "Flight is moving.";
        }

        /// <summary>
        /// IVehicle has stopped.
        /// </summary>
        /// <returns></returns>
        public string Stop()
        {
            return "Flight has stopped.";
        }
    }
}
