﻿// Namespace is like a folder which contains some classes.
namespace Sample
{
    // 1.
    // class is like a blueprint or template.
    // object is a single instance of the class.
    // 2.
    // Toyota : Car
    // means Toyota extend or implement Car.
    // We can say Car is the parent class of Toyota.
    // Toyota is a sub-Class of Car.
    // Toyota succeed all members, properties, methods 
    // from its parent class, Car.
    public class Toyota : Car
    {
        //--------------------------------------------------------------
        //The constructor is a special method.
        //Whenever a class or struct is created, its constructor is called

        public Toyota(string type, string registration, string year, double currentValue) : base("Toyota", type, registration, year, currentValue)
        {
        }


        //--------------------------------------------------------------
        // 1.
        //Method is a set of logic processes.
        //Method is like an action which this object can do.
        //E.g. Car can move and stop.
        //2.
        //Only virtual method can be overrided in the sub-class.

        /// <summary>
        /// An action or method which ONLY Toyota can do.
        /// </summary>
        /// <returns></returns>
        public string OnlyToyotaCanDo()
        {
            return "This is an action or method which ONLY " + this.Make + " can do.";
        }

        /// <summary>
        /// IVehicle is moving
        /// </summary>
        /// <returns></returns>
        public override string Moving()
        {
            return this.Make + " Car is moving.";
        }
    }
}
