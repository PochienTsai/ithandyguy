﻿using System;

// Namespace is like a folder which contains some classes.
namespace Sample
{
    class Program
    {
        static void Main(string[] args)
        {
            //1.
            //Create a detail for Honda CRV and print its detail.
            Console.WriteLine("CarA ----------------------------------");
            Car carA = new Car("Honda", "Crv", "RegistrationA", "2014", 21000);
            Console.WriteLine(carA);
            Console.WriteLine(carA.Moving());
            Console.WriteLine(carA.Stop());

            //2.
            //Create a detail for Toyota Corolla and print its detail.
            Console.WriteLine("CarB ----------------------------------");
            // Class ObjectName = new Class
            // E.g.
            // Use Toyota class as the blueprint and create an instance object of Toyota.
            // The instance object name is carB.
            Toyota carB = new Toyota("Prius", "RegistrationB", "2014", 23000);
            Console.WriteLine(carB);
            Console.WriteLine(carB.Moving());
            Console.WriteLine(carB.Stop());
            Console.WriteLine(carB.OnlyToyotaCanDo());

            //3.
            //Create a detail for Toyota Corolla and print its detail.
            Console.WriteLine("CarC ----------------------------------");
            // We can also use Toyota's parents class, Car, to create Toyota instance object.
            Car carC = new Toyota("Corolla", "RegistrationC", "2017", 25000);
            Console.WriteLine(carC);
            Console.WriteLine(carC.Moving());
            Console.WriteLine(carC.Stop());

            //// Error! Because we already cast Toyota to Car type variable, carC.
            //// Thus, carC has no "OnlyToyotaCanDo()" method.
            //Console.WriteLine(carC.OnlyToyotaCanDo());   

            Console.WriteLine(((Toyota)carC).OnlyToyotaCanDo());


            //4.
            Console.WriteLine("CarD ----------------------------------");
            // We can also use Toyota's parents Interface, IVehicle, to create Toyota instance object.
            IVehicle carD = new Toyota("Camry", "RegistrationD", "2017", 28000);
            Console.WriteLine(carD);
            Console.WriteLine(carD.Moving());
            Console.WriteLine(carD.Stop());

            //// Error! Because we already cast Toyota to Car type variable, carD.
            //// Thus, carD has no "OnlyToyotaCanDo()" method.
            //Console.WriteLine(carD.OnlyToyotaCanDo());   

            Console.WriteLine(((Toyota)carD).OnlyToyotaCanDo());

            //5.
            Console.WriteLine("CarE ----------------------------------");
            // We can also use "var" to create Toyota instance object.
            var carE = new Toyota("Prius C", "RegistrationE", "2016", 20000);
            Console.WriteLine(carE);

            Console.WriteLine(carE.Moving());
            Console.WriteLine(carE.Stop());
            Console.WriteLine(carE.OnlyToyotaCanDo());

            //6.
            Console.WriteLine("CarF ----------------------------------");
            // We can also use "var" to create Toyota instance object.
            var carF = new Mazda("Three", "RegistrationF", "2016", 25000);
            Console.WriteLine(carF);

            Console.WriteLine(carF.Moving());
            Console.WriteLine(carF.Stop());
            Console.WriteLine(carF.OnlyMazdaCanDo());

            //7.
            Console.WriteLine("CarG ----------------------------------");
            // We can also use "var" to create Toyota instance object.
            Mazda carG = new Mazda("Six", "RegistrationG", "2016", 29000);
            Console.WriteLine(carG);

            Console.WriteLine(carG.Moving());
            Console.WriteLine(carG.Stop());
            Console.WriteLine(carG.OnlyMazdaCanDo());

            //8.
            Console.WriteLine("CarFleet ==================================");
            // Add cars to CarFleet object.
            CarFleet carFleet = new CarFleet();
            carFleet.Add(carA);
            carFleet.Add(carB);
            carFleet.Add(carC);
            carFleet.Add((Car)carD);
            carFleet.Add(carE);
            carFleet.Add(carF);
            carFleet.Add(carG);

            // Print the sum value.
            Console.WriteLine("Total sum value : {0}", carFleet.SumFleetValue());

            // print the max and min value.
            double max, min;
            carFleet.Statistics(out min, out max);
            Console.WriteLine("The most expensive car value : {0}", max);
            Console.WriteLine("The cheapest car value : {0}", min);

            // print the cars by its year.
            Car[] carYears = carFleet.GetCars("2016");
            foreach (Car car in carYears)
            {
                Console.WriteLine("CarFleet {0}, {1} ----------------------", car.Make, car.Type);
                Console.WriteLine(car);
            }

            Console.ReadLine();
        }
    }
}
