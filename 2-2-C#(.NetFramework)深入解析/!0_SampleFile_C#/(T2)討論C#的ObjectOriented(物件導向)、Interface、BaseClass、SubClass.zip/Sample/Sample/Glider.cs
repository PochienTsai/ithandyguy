﻿// Namespace is like a folder which contains some classes.
namespace Sample
{
    public class Glider : Flight
    {
        //--------------------------------------------------------------
        //The constructor is a special method.
        //Whenever a class or struct is created, its constructor is called

        public Glider(string year, double currentValue) : base("Glider", year, currentValue)
        {
        }

        //--------------------------------------------------------------
        // 1.
        //Method is a set of logic processes.
        //Method is like an action which this object can do.
        //E.g. Car can move and stop.
        //2.
        //Only virtual method can be overrided in the sub-class.

        /// <summary>
        /// An action or method which ONLY Glider can do.
        /// </summary>
        /// <returns></returns>
        public string OnlyGliderCanDo()
        {
            return "This is an action or method which ONLY " + this.Type + " can do.";
        }
    }
}
