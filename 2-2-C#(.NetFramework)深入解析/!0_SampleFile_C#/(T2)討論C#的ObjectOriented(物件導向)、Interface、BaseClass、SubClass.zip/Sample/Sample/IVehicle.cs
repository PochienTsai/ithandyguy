﻿// Namespace is like a folder which contains some classes.
namespace Sample
{
    // 1.
    // Interface is like an product booklet which contains
    // the standard actions that this product must be able to do. 
    // Interface only contains the method signature without its body.
    // E.g.
    // IAircraft must be able to take off and land.
    // 2.
    // Interface can not contain fields.
    // 3.
    // The prefix of interface is "I"
    // 4.
    // a class can exten only one class and implement many Interface.
    // E.g.
    // public class ClassA : ClassB, InterfaceA, InterfaceB

    /// <summary>
    /// IVehicle must be able to move and stop
    /// </summary>
    public interface IVehicle
    {
        //string _interfaceName = "IVehicle";  // Interface can not contain fields.

        /// <summary>
        /// IVehicle is moving
        /// </summary>
        /// <returns></returns>
        string Moving();

        /// <summary>
        /// IVehicle has stopped.
        /// </summary>
        /// <returns></returns>
        string Stop();
    }
}
