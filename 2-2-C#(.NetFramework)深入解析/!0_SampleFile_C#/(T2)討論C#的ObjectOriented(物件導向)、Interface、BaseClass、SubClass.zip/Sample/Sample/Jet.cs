﻿// Namespace is like a folder which contains some classes.
namespace Sample
{
    public class Jet : Flight
    {
        //--------------------------------------------------------------
        //The constructor is a special method.
        //Whenever a class or struct is created, its constructor is called

        public Jet(string year, double currentValue) : base("Jet", year, currentValue)
        {
        }

        //--------------------------------------------------------------
        // 1.
        //Method is a set of logic processes.
        //Method is like an action which this object can do.
        //E.g. Car can move and stop.
        //2.
        //Only virtual method can be overrided in the sub-class.

        /// <summary>
        /// An action or method which ONLY Jet can do.
        /// </summary>
        /// <returns></returns>
        public string OnlyJetCanDo()
        {
            return "This is an action or method which ONLY " + this.Type + " can do.";
        }

        /// <summary>
        /// IAircraft is taking off.
        /// </summary>
        /// <returns></returns>
        public override string TakingOff()
        {
            return "Flight is taking off.";
        }

        /// <summary>
        /// IAircraft is landing.
        /// </summary>
        /// <returns></returns>
        public override string Landing()
        {
            return "Flight is landing.";
        }
    }
}
