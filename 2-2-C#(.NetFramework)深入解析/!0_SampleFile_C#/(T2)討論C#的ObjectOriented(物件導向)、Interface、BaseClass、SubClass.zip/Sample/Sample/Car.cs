﻿// Namespace is like a folder which contains some classes.
namespace Sample
{
    // 1.
    // public / protected / private
    // Reference:
    // https://docs.microsoft.com/en-us/dotnet/csharp/language-reference/keywords/accessibility-levels
    // Accessibility Levels includes several levels.
    // Here, we only discuss, public, protected, and private.
    // public means access is not restricted.
    // protected means access is limited to the containing class or types derived from the containing class.
    // private means access is limited to the containing type.
    // 2.
    // class is like a blueprint or template.
    // object is a single instance of the class.
    public class Car : IVehicle
    {
        //--------------------------------------------------------------
        // This can be called as Class Member, Field, global variable.  
        // Most people called this as "Field".
        // Field is like a Database Table Column to store the data of the object.
        private string _make;
        private string _type;
        private string _registration;
        private string _year;

        //--------------------------------------------------------------
        //The constructor is a special method.
        //Whenever a class or struct is created, its constructor is called
        /// <summary>
        /// The constructor of car. 
        /// </summary>
        /// <param name="make"></param>
        /// <param name="type"></param>
        /// <param name="registration"></param>
        /// <param name="year"></param>
        /// <param name="currentValue"></param>
        public Car(string make, string type, string registration, string year, double currentValue)
        {
            _make = make;
            _type = type;
            _registration = registration;   // set value dirrectly to the field.
            _year = year;   // set value dirrectly to the field.
            CurrentValue = currentValue;    // set the field value by its property.
        }

        //--------------------------------------------------------------
        // Properties is special method to replace get and set.
        // Year Property can replace GetYear() and SetYear()
        public string Year
        {
            get { return _year; }
            // this is the keyword, means current object
            set { this._year = value; }
        }
        // CurrentValue Property can replace GetValue() and SetValue()
        public double CurrentValue { get; set; }
        // Make Property can replace GetMake()
        public string Make { get { return _make; } }
        // Type Property can replace GetType()
        public string Type { get { return _type; } }

        //--------------------------------------------------------------
        // 1.
        //Method is a set of logic processes.
        //Method is like an action which this object can do.
        //E.g. Car can move and stop.
        //2.
        //Only virtual method can be overrided in the sub-class.

        /// <summary>
        /// Get the _registration
        /// </summary>
        /// <returns>_registration</returns>
        public string GetRegistration()
        {
            return _registration;
        }

        /// <summary>
        /// Set the _registration
        /// </summary>
        /// <param name="registration">registration string</param>
        public void SetRegistration(string registration)
        {
            _registration = registration;
        }


        /// <summary>
        /// Return full car information
        /// </summary>
        /// <returns>full car information</returns>
        public override string ToString()
        {
            //return String.Format("Car Make: {0}\n" +
            //                     "Car Type: {1}\n" +
            //                     "Car Registration: {2}\n" +
            //                     "Car Year: {3}\n" +
            //                     "Current Value: {4}", _make, _type, _registration, _year, CurrentValue);

            return $"Car Make: {_make}\n" + 
                $"Car Type: {_type}\n" + 
                $"Car Registration: {_registration}\n" + 
                $"Car Year: {_year}\n" + 
                $"Current Value: {CurrentValue}";
        }

        /// <summary>
        /// IVehicle is moving
        /// </summary>
        /// <returns></returns>
        public virtual string Moving()
        {
            return "Car is moving.";
        }

        /// <summary>
        /// IVehicle has stopped.
        /// </summary>
        /// <returns></returns>
        public string Stop()
        {
            return "Car has stopped.";
        }
    }
}
