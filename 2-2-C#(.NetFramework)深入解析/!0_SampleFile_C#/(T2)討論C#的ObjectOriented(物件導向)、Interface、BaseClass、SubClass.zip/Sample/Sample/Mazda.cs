﻿// Namespace is like a folder which contains some classes.
namespace Sample
{
    // 1.
    // class is like a blueprint or template.
    // object is a single instance of the class.
    // 2.
    // Mazda : Car
    // means Mazda extend or implement Car.
    // We can say Car is the parent class of Mazda.
    // Mazda is a sub-Class of Car.
    // Mazda succeed all members, properties, methods 
    // from its parent class, Car.
    public class Mazda : Car
    {
        //--------------------------------------------------------------
        //The constructor is a special method.
        //Whenever a class or struct is created, its constructor is called

        public Mazda(string type, string registration, string year, double currentValue) : base("Mazda", type, registration, year, currentValue)
        {
        }


        //--------------------------------------------------------------
        // 1.
        //Method is a set of logic processes.
        //Method is like an action which this object can do.
        //E.g. Car can move and stop.
        //2.
        //Only virtual method can be overrided in the sub-class.

        /// <summary>
        /// An action or method which ONLY Mazda can do.
        /// </summary>
        /// <returns></returns>
        public string OnlyMazdaCanDo()
        {
            return "This is an action or method which ONLY " + this.Make + " can do.";
        }
    }
}
