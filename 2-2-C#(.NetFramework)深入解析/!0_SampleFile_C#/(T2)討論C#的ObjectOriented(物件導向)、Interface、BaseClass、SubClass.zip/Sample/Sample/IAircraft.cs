﻿namespace Sample
{
    // 1.
    // Interface is like an product booklet which contains
    // the standard actions that this product must be able to do. 
    // Interface only contains the method signature without its body.
    // E.g.
    // IAircraft must be able to take off and land.
    // 2.
    // Interface can not contain fields.
    // 3.
    // The prefix of interface is "I"
    // 4.
    // a class can exten only one class and implement many Interface.
    // E.g.
    // public class ClassA : ClassB, InterfaceA, InterfaceB

    /// <summary>
    /// IAircraft must be able to take off and land.
    /// </summary>
    public interface IAircraft
    {
        //string _interfaceName = "IAircraft";  // Interface can not contain fields.

        /// <summary>
        /// IAircraft is taking off.
        /// </summary>
        /// <returns></returns>
        string TakingOff();

        /// <summary>
        /// IAircraft is landing.
        /// </summary>
        /// <returns></returns>
        string Landing();
    }
}
