﻿namespace Sample
{
    public class CarFleet
    {
        //--------------------------------------------------------------
        // This can be called as Class Member, Field, global variable.  
        // Most people called this as "Field".
        // Field is like a Database Table Column to store the data of the object.

        // an array of _cars which can contain 100 car objects.
        //Max number of car quanty is 100.
        private Car[] _cars;

        // The current index of car array represents the current car quantity in array.
        // In the biginning, it should be 0.
        private int _qtyOfCarInArray;    

        //--------------------------------------------------------------
        //The constructor is a special method.
        //Whenever a class or struct is created, its constructor is called

        /// <summary>
        /// The constructor. 
        /// </summary>
        public CarFleet()
        {
            // an array of _cars which can contain 100 car objects.
            //Max number of car quanty is 100.
            _cars = new Car[100];

            // The current index of car array represents the current car quantity in array.
            // In the biginning, it should be 0.
            _qtyOfCarInArray = 0;
        }


        //--------------------------------------------------------------
        // 1.
        //Method is a set of logic processes.
        //Method is like an action which this object can do.
        //E.g. Car can move and stop.
        //2.
        //Only virtual method can be overrided in the sub-class.

        /// <summary>
        /// Add the car into the next free slot in the car array. 
        /// </summary>
        /// <param name="car">The car to add</param>
        public void Add(Car car)
        {
            // _qtyOfCarInArray field tracks where 
            // the next free slot in the array is and 
            // increments it after a car has been added.
            _cars[_qtyOfCarInArray] = car;
            _qtyOfCarInArray++;
        }

        /// <summary>
        /// Summing up the value of each car in the car array.
        /// </summary>
        /// <returns>Return the Sum value of each car in the car array.</returns>
        public double SumFleetValue()
        {
            double total = 0;
            for (int i = 0; i < _qtyOfCarInArray; i++)
            {
                total += _cars[i].CurrentValue; // total = total + _cars[i].CurrentValue;
            }
            return total;
        }

        /// <summary>
        /// Output parameter for the car Min Value and 
        /// car Max Value from the car array.
        /// </summary>
        /// <param name="leastValue">Car least Value from the car array</param>
        /// <param name="highestValue">Car highest Value from the car array</param>
        public void Statistics(out double leastValue, out double highestValue)
        {
            leastValue = _cars[0].CurrentValue;
            highestValue = _cars[0].CurrentValue;
            for (int i = 0; i < _qtyOfCarInArray; i++)
            {
                if (_cars[i].CurrentValue < leastValue)
                    leastValue = _cars[i].CurrentValue;
                else if (_cars[i].CurrentValue > highestValue)
                    highestValue = _cars[i].CurrentValue;
            }
        }

        /// <summary>
        /// Get the cars by its year.
        /// </summary>
        /// <param name="year">The specific car year.</param>
        /// <returns>The cars by its year.</returns>
        public Car[] GetCars(string year)
        {
            //Count how many cars in the car array are for the specified year.
            int count = 0;
            for (int i = 0; i < _qtyOfCarInArray; i++)
            {
                if (_cars[i].Year == year)
                    count++;
            }

            // Create a new array, carsYears, with this size, count.
            Car[] carsYears = new Car[count];

            // copy in the cars for the specified year into new arrray, carsYears.
            int index = 0;
            for (int i = 0; i < _qtyOfCarInArray; i++)
            {
                if (_cars[i].Year == year)
                {
                    carsYears[index] = _cars[i];
                    index++;
                }
            }

            // return the array.
            return carsYears;
        }

    }
}
