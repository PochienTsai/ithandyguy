﻿using System;

namespace OnLineGameA
{
    // This class has 2 constructors, 2 properties, and 4 methods
    public class GamerA
    {
        // Properties ----------------------------
        public string Name { get; set; }
        public int GameScore { get; set; }

        // Constructor ----------------------------
        public GamerA(string name, int gameScore)
        {
            GameScore = gameScore;
            Name = name;
        }

        public GamerA()
        {
            GameScore = -1;
            Name = string.Empty;
        }

        // Methods ----------------------------
        public void PrintName()
        {
            Console.WriteLine($"Name == {Name}");
        }

        public void PrintGameScore()
        {
            Console.WriteLine($"GameScore == {GameScore}");
        }

        public override string ToString()
        {
            return $"Name : {Name} ; GameScore : {GameScore}";
        }

        public string SetNameAndGameScore(string name, int gameScore)
        {
            Name = name;
            GameScore = gameScore;
            return ToString();
        }
    }
}
