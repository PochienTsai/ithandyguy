﻿using System;
using OnlineGame;

namespace Sample
{
    class Program
    {
        static void Main(string[] args)
        {
            string str = @"abcdef";
            Console.WriteLine($"StringHelper.ConverToUpper1(str) : {StringHelper.ConverToUpper1(str)}");
            Console.WriteLine($"str.ConverToUpper2() : {str.ConverToUpper2()}");
            Console.WriteLine($"str.ConverToUpper2(\"123\",\"a1b2c3\") : {str.ConverToUpper2("123", "a1b2c3")}");

            Console.ReadLine();
        }
    }
}

namespace OnlineGame
{
    public class StringHelper
    {
        public static string ConverToUpper1(string intStr)
        {
            return intStr.ToUpper();
        }
    }

    public static class StringHelper2
    {
        public static string ConverToUpper2(this string intStr)
        {
            return intStr.ToUpper();
        }

        public static string ConverToUpper2(this string intStr, string intStr1, string intStr2)
        {
            return intStr.ToUpper() + intStr1 + intStr2;
        }
    }
}

/*
Extend method is a static method in a static class,
and the first parameter must use "this" keyword 
to represent the object instance which invoke this extend method.
*/
