﻿using System;
using System.Runtime.InteropServices;

namespace Sample
{
    class Program
    {
        static void Main(string[] args)
        {
            // 1. ------------------------------------------------
            // Use parameter arrays
            Console.WriteLine("1. Use parameter arrays ===================== ");
            ParamsArrSample(1, 2);
            ParamsArrSample(1, 2, 3);
            ParamsArrSample(1, 2, 3, 4, 5);
            ParamsArrSample(1, 2, new int[] { 3, 4, 5 });

            //1. Use parameter arrays =====================
            //ParamsArrSample() == { 1 , 2  }
            //ParamsArrSample() == { 1 , 2 , 3  }
            //ParamsArrSample() == { 1 , 2 , 3 , 4 , 5  }
            //ParamsArrSample() == { 1 , 2 , 3 , 4 , 5  }

            // 2. ------------------------------------------------
            // Method Overload
            Console.WriteLine("2. Method Overload ===================== ");
            OverloadSample(1, 2);
            OverloadSample(1, 2, new int[] { 3 });
            OverloadSample(1, 2, new int[] { 3, 4, 5 });
            OverloadSample(1, 2, new[] { 3, 4, 5 });

            //2. Method Overload =====================
            //OverloadSample() == { 1 , 2 }
            //OverloadSample() == { 1 , 2 , 3  }
            //OverloadSample() == { 1 , 2 , 3 , 4 , 5  }
            //OverloadSample() == { 1 , 2 , 3 , 4 , 5  }

            // 3. ------------------------------------------------
            // Parameter default value
            Console.WriteLine("3. Parameter default value ===================== ");
            ParameterDefaultValueSample(1, 2);
            ParameterDefaultValueSample(1, 2, new int[] { 3 });
            ParameterDefaultValueSample(1, 2, new int[] { 3, 4, 5 });
            ParameterDefaultValueSample(1, 2, new[] { 3, 4, 5 });
            ParameterDefaultValueSample(1);   //{ 1 , 100  }
            ParameterDefaultValueSample(1, intArr: new[] { 101, 102, 103 });  //{ 1 , 100 , 101 , 102 , 103  }

            //3.Parameter default value =====================
            //ParameterDefaultValueSample() == { 1 , 2  }
            //ParameterDefaultValueSample() == { 1 , 2 , 3  }
            //ParameterDefaultValueSample() == { 1 , 2 , 3 , 4 , 5  }
            //ParameterDefaultValueSample() == { 1 , 2 , 3 , 4 , 5  }
            //ParameterDefaultValueSample() == { 1 , 100  }
            //ParameterDefaultValueSample() == { 1 , 100 , 101 , 102 , 103  }

            // 4. ------------------------------------------------
            // OptionalAttribute Sample
            Console.WriteLine("4. OptionalAttributeSample ===================== ");
            OptionalAttributeSample(1, 2);
            OptionalAttributeSample(1, 2, new int[] { 3 });
            OptionalAttributeSample(1, 2, new int[] { 3, 4, 5 });
            OptionalAttributeSample(1, 2, new[] { 3, 4, 5 });

            //4. OptionalAttributeSample ===================== 
            //OptionalAttributeSample() == { 1 , 2  }
            //OptionalAttributeSample() == { 1 , 2 , 3  }
            //OptionalAttributeSample() == { 1 , 2 , 3 , 4 , 5  }
            //OptionalAttributeSample() == { 1 , 2 , 3 , 4 , 5  }

            Console.ReadLine();
        }

        // 1. ------------------------------------------------
        // Use parameter arrays
        // static void PrintAll2(int i1, params int[] intArr, int i2)   //Error
        static void ParamsArrSample(int i1, int i2, params int[] intArr)
        {
            Console.Write("ParamsArrSample() == {{ {0} , {1} ", i1, i2);
            if (intArr != null)
            {
                foreach (int i in intArr)
                {
                    Console.Write($", {i} ");
                }
            }
            Console.WriteLine(" }");
        }
        //params int[] intArr, parameter array must be the last parameter.


        // 2. ------------------------------------------------
        // Method Overload
        static void OverloadSample(int i1, int i2)
        {
            Console.WriteLine("OverloadSample() == {{ {0} , {1} }}", i1, i2);
        }

        static void OverloadSample(int i1, int i2, int[] intArr)
        {
            Console.Write("OverloadSample() == {{ {0} , {1} ", i1, i2);
            if (intArr != null)
            {
                foreach (int i in intArr)
                {
                    Console.Write($", {i} ");
                }
            }
            Console.WriteLine(" }");
        }

        // 3. ------------------------------------------------
        // Parameter default value
        static void ParameterDefaultValueSample(int i1, int i2 = 100, int[] intArr = null)
        {
            Console.Write("ParameterDefaultValueSample() == {{ {0} , {1} ", i1, i2);
            if (intArr != null)
            {
                foreach (int i in intArr)
                {
                    Console.Write($", {i} ");
                }
            }
            Console.WriteLine(" }");
        }

        // 4. ------------------------------------------------
        // OptionalAttribute Sample
        static void OptionalAttributeSample(int i1, int i2, [Optional] int[] intArr)
        {
            Console.Write("OptionalAttributeSample() == {{ {0} , {1} ", i1, i2);
            if (intArr != null)
            {
                foreach (int i in intArr)
                {
                    Console.Write($", {i} ");
                }
            }
            Console.WriteLine(" }");
        }
    }
}

/*
1.
4 popular ways to make method parameters optional.
1.1.
Use parameter arrays
1.2.
Overload Method
1.3.
Parameter default value
1.4.
OptionalAttribute from System.Runtime.InteropServices namespace 
*/
