﻿using System;
namespace SampleWebForm
{
    public partial class WebForm1 : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            // Using the string indexer to store session data
            Session["Session1"] = "Session1 Data";
            Session["Session2"] = "Session2 Data";
            Session["Session2"] = "Session2New Data";   // Change data
            //Session[2] = "Session3 Data";   // Error! can not use int index to set session data
            Session["Session3"] = new Gamer
            {
                Id = 1,
                Name = "Name01",
                Email = "1@1.com"
            };

            // input int index indexer, output object
            Response.Write($"Session[0].ToString() ==  " +
                           $"{Session[0].ToString()} <br/>");
            // input string indexer, output object
            Response.Write($"Session[\"Session2\"].ToString()  ==  " +
                           $"{Session["Session2"].ToString()} <br/>");

            // input int index indexer, output object
            Response.Write($"Session[2].ToString() ==  " +
                           $"{Session[2].ToString()} <br/>");
            // input string indexer, output object
            Response.Write($"Session[\"Session3\"].ToString()  ==  " +
                           $"{Session["Session3"].ToString()} <br/>");

            //Session[0].ToString() == Session1 Data
            //Session["Session2"].ToString() == Session2New Data
            //Session[2].ToString() == Id == 1; Name == Name01; Email: 1@1.com
            //Session["Session3"].ToString() == Id == 1; Name == Name01; Email: 1@1.com
        }
    }

    public class Gamer
    {
        public int Id { get; set; }
        public string Name { get; set; }
        public string Email { get; set; }

        public override string ToString()
        {
            return $"Id == {Id} ; Name == {Name} ; Email : {Email}";
        }
    }
}