﻿using System;
using System.Collections.Generic;
using System.Linq;
using OnlineGame;

namespace Sample
{
    class Program
    {
        static void Main(string[] args)
        {
            // 1. =========================================================
            //Anonymous methods
            Console.WriteLine("1. AnonymousMethodsSample() ====================== ");
            AnonymousMethodsSample();

            // 2. =========================================================
            //Func<T, TResult> Delegate
            Console.WriteLine("2. FuncDelegateSample() ====================== ");
            FuncDelegateSample();

            Console.ReadLine();
        }

        //1. =========================================================
        //Anonymous methods
        static void AnonymousMethodsSample()
        {
            List<Gamer> listGamers = new List<Gamer>
            {
                new Gamer{ Id = 1, Name = "Name01"},
                new Gamer{ Id = 2, Name = "Name02"},
                new Gamer{ Id = 3, Name = "Name03"},
                new Gamer{ Id = 4, Name = "Name04"}
            };

            //Step 2: Create a Predicate<Gamer> delegate object 
            //with GetGamerId1 method as parameter.
            Predicate<Gamer> predicateGetGamerId1 = new Predicate<Gamer>(GetGamerId1);
            //Step 3: pass the delegate instance as parameter of Find()
            Gamer gamerId1 = listGamers.Find(g => predicateGetGamerId1(g));
            Console.WriteLine($"predicateGetGamerId1 : gamerId1.Id=={gamerId1.Id}, gamerId1.Name=={gamerId1.Name}.");

            // "new Predicate<Gamer> " can be omitted.
            Predicate<Gamer> predicateGetGamerId2 = GetGamerId2;
            Gamer gamerId2 = listGamers.Find(g => predicateGetGamerId2(g));
            Console.WriteLine($"predicateGetGamerId2 : gamerId2.Id=={gamerId2.Id}, gamerId2.Name=={gamerId2.Name}.");

            // Anonymous method is being passed as an argument to
            // the Find() method. This anonymous method replaces
            // the need for Step 1, 2 and 3
            Gamer gamerId3 = listGamers.Find(delegate (Gamer g) { return g.Id == 3; });
            Console.WriteLine($"predicateGetGamerId3 : gamerId3.Id=={gamerId3.Id}, gamerId3.Name=={gamerId3.Name}.");

            //using lambda expression
            //=> is called lambda operator and read as GOES TO
            Gamer gamerId3V2 = listGamers.Find(g => g.Id == 3);
            Console.WriteLine($"predicateGetgamerId3V2 : gamerId3V2.Id=={gamerId3V2.Id}, gamerId3V2.Name=={gamerId3V2.Name}.");

            //using lambda expression
            Gamer gamerId3V3 = listGamers.Find((Gamer g) => g.Id == 3);
            Console.WriteLine($"predicateGetgamerId3V2 : gamerId3V3.Id=={gamerId3V3.Id}, gamerId3V3.Name=={gamerId3V3.Name}.");
        }

        // Step 1: Create a method whose signature matches Predicate<Gamer> delegate.
        private static bool GetGamerId1(Gamer g)
        {
            return g.Id == 1;
        }

        private static bool GetGamerId2(Gamer g)
        {
            return g.Id == 2;
        }

        //2. =========================================================
        //Func<T, TResult> Delegate
        static void FuncDelegateSample()
        {
            List<Gamer> listGamers = new List<Gamer>
            {
                new Gamer{ Id = 1, Name = "Name01"},
                new Gamer{ Id = 2, Name = "Name02"},
                new Gamer{ Id = 3, Name = "Name03"},
                new Gamer{ Id = 4, Name = "Name04"}
            };

            //2.1. -------------------------------------
            // Create Func<T, TResult> Delegate
            // and pass it to the Select() LINQ function,
            // ListObject.Select(funcDelegate) 
            Console.WriteLine("2.1. Func<T, TResult> Delegate ---------------------");
            Func<Gamer, string> funcDelegateSelector =
            employee => $"Name == {employee.Name}";
            IEnumerable<string> names = listGamers.Select(funcDelegateSelector);
            foreach (string nameItem in names)
            {
                Console.WriteLine(nameItem);
            }

            // 2.2. -------------------------------------------
            // lambda expression
            Console.WriteLine("2.2. lambda expression ---------------------");
            IEnumerable<string> names2 =
            listGamers.Select(employee => "Name == " + employee.Name);
            foreach (string nameItem in names2)
            {
                Console.WriteLine(nameItem);
            }

            // 2.3. -------------------------------------------
            // Create Func<T, T, TResult> Delegate
            Console.WriteLine("2.3. Func<T, T, TResult> Delegate ---------------------");
            Func<int, int, string> funcDelegateSelector2 =
                (i1, i2) =>
                "Sum == " + (i1 + i2).ToString();
            string result = funcDelegateSelector2(10, 20);
            Console.WriteLine(result);
        }

    }
}


namespace OnlineGame
{
    public class Gamer
    {
        public int Id { get; set; }
        public string Name { get; set; }

        public override string ToString()
        {
            return $"Id=={Id} ; Name=={Name}";
        }
    }
}