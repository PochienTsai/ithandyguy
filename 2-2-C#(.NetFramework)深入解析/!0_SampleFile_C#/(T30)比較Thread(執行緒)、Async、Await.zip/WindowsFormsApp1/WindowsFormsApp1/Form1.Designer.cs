﻿namespace WindowsFormsApp1
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.btnThread1 = new System.Windows.Forms.Button();
            this.lbl1 = new System.Windows.Forms.Label();
            this.btnThread2 = new System.Windows.Forms.Button();
            this.btnThread3 = new System.Windows.Forms.Button();
            this.btnThread4 = new System.Windows.Forms.Button();
            this.btnThread5 = new System.Windows.Forms.Button();
            this.btnThread6 = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // btnThread1
            // 
            this.btnThread1.Location = new System.Drawing.Point(12, 88);
            this.btnThread1.Name = "btnThread1";
            this.btnThread1.Size = new System.Drawing.Size(158, 61);
            this.btnThread1.TabIndex = 0;
            this.btnThread1.Text = "button1";
            this.btnThread1.UseVisualStyleBackColor = true;
            // 
            // lbl1
            // 
            this.lbl1.AutoSize = true;
            this.lbl1.Location = new System.Drawing.Point(12, 9);
            this.lbl1.Name = "lbl1";
            this.lbl1.Size = new System.Drawing.Size(51, 20);
            this.lbl1.TabIndex = 1;
            this.lbl1.Text = "label1";
            // 
            // btnThread2
            // 
            this.btnThread2.Location = new System.Drawing.Point(176, 88);
            this.btnThread2.Name = "btnThread2";
            this.btnThread2.Size = new System.Drawing.Size(158, 61);
            this.btnThread2.TabIndex = 2;
            this.btnThread2.Text = "button1";
            this.btnThread2.UseVisualStyleBackColor = true;
            // 
            // btnThread3
            // 
            this.btnThread3.Location = new System.Drawing.Point(340, 88);
            this.btnThread3.Name = "btnThread3";
            this.btnThread3.Size = new System.Drawing.Size(158, 61);
            this.btnThread3.TabIndex = 3;
            this.btnThread3.Text = "button1";
            this.btnThread3.UseVisualStyleBackColor = true;
            // 
            // btnThread4
            // 
            this.btnThread4.Location = new System.Drawing.Point(504, 88);
            this.btnThread4.Name = "btnThread4";
            this.btnThread4.Size = new System.Drawing.Size(158, 61);
            this.btnThread4.TabIndex = 4;
            this.btnThread4.Text = "button1";
            this.btnThread4.UseVisualStyleBackColor = true;
            // 
            // btnThread5
            // 
            this.btnThread5.Location = new System.Drawing.Point(12, 155);
            this.btnThread5.Name = "btnThread5";
            this.btnThread5.Size = new System.Drawing.Size(158, 61);
            this.btnThread5.TabIndex = 5;
            this.btnThread5.Text = "button1";
            this.btnThread5.UseVisualStyleBackColor = true;
            // 
            // btnThread6
            // 
            this.btnThread6.Location = new System.Drawing.Point(176, 155);
            this.btnThread6.Name = "btnThread6";
            this.btnThread6.Size = new System.Drawing.Size(158, 61);
            this.btnThread6.TabIndex = 6;
            this.btnThread6.Text = "button1";
            this.btnThread6.UseVisualStyleBackColor = true;
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(9F, 20F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(693, 439);
            this.Controls.Add(this.btnThread6);
            this.Controls.Add(this.btnThread5);
            this.Controls.Add(this.btnThread4);
            this.Controls.Add(this.btnThread3);
            this.Controls.Add(this.btnThread2);
            this.Controls.Add(this.lbl1);
            this.Controls.Add(this.btnThread1);
            this.Name = "Form1";
            this.Text = "Form1";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button btnThread1;
        private System.Windows.Forms.Label lbl1;
        private System.Windows.Forms.Button btnThread2;
        private System.Windows.Forms.Button btnThread3;
        private System.Windows.Forms.Button btnThread4;
        private System.Windows.Forms.Button btnThread5;
        private System.Windows.Forms.Button btnThread6;
    }
}

